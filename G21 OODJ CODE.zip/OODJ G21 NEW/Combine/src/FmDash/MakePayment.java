/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FmDash;


import Login.PurchaseData;
import java.util.ArrayList;

/**
 *
 * @author Yen Hau
 */
public class MakePayment {    
     
    boolean statusCheck(int index,ArrayList<PurchaseData> purchaseData) {
        if (purchaseData.get(index).getStatus().equals("Approved")) {
            return true;
        }
        return false;
    }
    
    // Its a method
    String[][] getPurchaseData(ArrayList<PurchaseData> purchaseData) {
        String[][] data = new String[purchaseData.size()][10];

        for (int i = 0; i < purchaseData.size(); i++) {
            data[i][0] = purchaseData.get(i).getPoID();
            data[i][1] = purchaseData.get(i).getDate();
            data[i][2] = purchaseData.get(i).getRequisitionID();
            data[i][3] = purchaseData.get(i).getPmID();
            data[i][4] = purchaseData.get(i).getSupplierID();
            data[i][5] = purchaseData.get(i).getItemID();
            data[i][6] = String.valueOf(purchaseData.get(i).getUnitPrice());
            data[i][7] = String.valueOf(purchaseData.get(i).getQuantity());
            data[i][8] = String.valueOf(purchaseData.get(i).getTotalPrice());
            data[i][9] = purchaseData.get(i).getStatus();
        }
        return data;
    }
}
