package SmDash;

import static Login.FileHandling.salesFilePath;
import Login.InventoryData;
import Login.PurchaseData;
import Login.RequisitionData;
import Login.SalesData;
import Login.SupItemData;
import Login.UserData;
import java.util.ArrayList;

public class Sales_Entry extends javax.swing.JFrame{
    private ArrayList<InventoryData> inventoryData;
    private ArrayList<SupItemData> supitemData;
    private ArrayList<RequisitionData> requisitionData;
    private ArrayList<PurchaseData> purchaseData;
    private ArrayList<SalesData> salesData;
    private ArrayList<UserData> userData;
    private SalesEntryFunction salesEntry;
      
    public Sales_Entry(ArrayList<InventoryData> inventoryData, ArrayList<SupItemData> supitemData, ArrayList<RequisitionData> requisitionData, ArrayList<PurchaseData> purchaseData, ArrayList<SalesData> salesData, ArrayList<UserData> userData) {
        this.inventoryData = inventoryData;
        this.supitemData = supitemData;
        this.requisitionData = requisitionData;
        this.purchaseData = purchaseData;
        this.salesData= salesData;
        this.userData = userData;
        salesEntry = new SalesEntryFunction(this.inventoryData, this.supitemData, this.requisitionData, this.purchaseData, this.salesData, this.userData);
        
        initComponents();
        salesEntry.updateTable(salesentrytable);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jRadioButton1 = new javax.swing.JRadioButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        salesentrytable = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        header1 = new javax.swing.JLabel();
        home = new javax.swing.JButton();
        editbtn = new javax.swing.JButton();
        savebtn = new javax.swing.JButton();
        addbtn = new javax.swing.JButton();
        deletebtn = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();

        jRadioButton1.setText("jRadioButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        salesentrytable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Date", "Sales ID", "Sales Manager ID", "Item ID", "Item Name", "Unit Price", "Quantity", "Total Amount"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(salesentrytable);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 114, 788, 380));

        jPanel1.setBackground(new java.awt.Color(51, 51, 41));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 100));

        header1.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        header1.setForeground(new java.awt.Color(255, 255, 255));
        header1.setText("Sales Entry");

        home.setBackground(new java.awt.Color(51, 51, 51));
        home.setIcon(new javax.swing.ImageIcon(getClass().getResource("/SmImage/home.jpg"))); // NOI18N
        home.setBorderPainted(false);
        home.setContentAreaFilled(false);
        home.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        home.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                homeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(337, Short.MAX_VALUE)
                .addComponent(header1)
                .addGap(261, 261, 261)
                .addComponent(home, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(header1)
                        .addGap(14, 14, 14))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(home, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 63));

        editbtn.setText("Edit");
        editbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editbtnActionPerformed(evt);
            }
        });
        getContentPane().add(editbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 71, -1, -1));

        savebtn.setText("Save");
        savebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                savebtnActionPerformed(evt);
            }
        });
        getContentPane().add(savebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(258, 71, -1, -1));

        addbtn.setText("Add");
        addbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addbtnActionPerformed(evt);
            }
        });
        getContentPane().add(addbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 71, -1, -1));

        deletebtn.setText("Delete");
        deletebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletebtnActionPerformed(evt);
            }
        });
        getContentPane().add(deletebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(174, 71, -1, -1));
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 100, 788, 8));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    
    private void homeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_homeActionPerformed
        SmDashboard dashboard = new SmDashboard(inventoryData, supitemData, requisitionData, purchaseData, salesData, userData);
        dashboard.show();
        this.dispose();
    }//GEN-LAST:event_homeActionPerformed

    private void editbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editbtnActionPerformed
        salesEntry.Edit(salesentrytable);
    }//GEN-LAST:event_editbtnActionPerformed

    private void savebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_savebtnActionPerformed
        salesEntry.SaveToArray(salesentrytable);
        salesEntry.Save(salesData, salesFilePath);
    }//GEN-LAST:event_savebtnActionPerformed

    private void addbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addbtnActionPerformed
        salesEntry.addSalesEntry(salesentrytable);
    }//GEN-LAST:event_addbtnActionPerformed

    private void deletebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletebtnActionPerformed
        salesEntry.Delete(salesentrytable);
    }//GEN-LAST:event_deletebtnActionPerformed

    public static void main(String args[]) {
//        java.awt.EventQueue.invokeLater(() -> {
//            new Sales_Entry().setVisible(true);
//        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addbtn;
    private javax.swing.JButton deletebtn;
    private javax.swing.JButton editbtn;
    private javax.swing.JLabel header1;
    private javax.swing.JButton home;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable salesentrytable;
    private javax.swing.JButton savebtn;
    // End of variables declaration//GEN-END:variables
}
