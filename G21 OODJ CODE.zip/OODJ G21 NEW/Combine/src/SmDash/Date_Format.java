package SmDash;

public class Date_Format {
    public static String getCurrentDate() {
       return new java.text.SimpleDateFormat("dd/MM/yyyy").format(new java.util.Date());
    }
}
