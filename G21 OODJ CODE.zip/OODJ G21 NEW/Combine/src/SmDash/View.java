package SmDash;

import Login.InventoryData;
import Login.PurchaseData;
import Login.RequisitionData;
import Login.SalesData;
import Login.SupItemData;
import Login.UserData;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class View {
    private ArrayList<InventoryData> inventoryData;
    private ArrayList<SupItemData> supitemData;
    private ArrayList<RequisitionData> requisitionData;
    private ArrayList<PurchaseData> purchaseData;
    private ArrayList<SalesData> salesData;
    private ArrayList<UserData> userData;
    DefaultTableModel tblModel;
    
    public View(ArrayList<InventoryData> inventoryData, ArrayList<SupItemData> supitemData, ArrayList<RequisitionData> requisitionData, ArrayList<PurchaseData> purchaseData, ArrayList<SalesData> salesData, ArrayList<UserData> userData)
    {
        this.inventoryData = inventoryData;
        this.supitemData = supitemData;
        this.requisitionData = requisitionData;
        this.purchaseData = purchaseData;
        this.salesData= salesData;
        this.userData = userData;
    }
       
    public void ShowInventory(JTable tbl) {
        tblModel = (DefaultTableModel) tbl.getModel();
        tblModel.setRowCount(0); // Clear existing rows in the table

        // Iterate through inventoryData
        for (InventoryData item : inventoryData) {
            boolean hasSupplier = false; // Track if the item has suppliers

            for (SupItemData supItem : supitemData) {
                if (supItem.getItemID().equals(item.getItemID())) {
                    hasSupplier = true;

                    // Add a row for the item with its supplier information
                    Object[] row = {
                        item.getItemID(),
                        item.getItemName(),
                        supItem.getSupplierID(),
                        supItem.getQuantity(),
                        supItem.getUnitPrice()
                    };
                    tblModel.addRow(row);
                }
            }
        }
    }
    
    public void ShowRequisition(JTable tbl) 
    {
        tblModel = (DefaultTableModel) tbl.getModel();
        tblModel.setRowCount(0); // Clear existing rows in the table

        for (RequisitionData item : requisitionData) 
        {
            Object[] row = 
            {
                item.getRequisitionID(),
                item.getRequestDate(),
                item.getItemID(),
                item.getItemName(),
                item.getCurrentQty()
            };
            tblModel.addRow(row);
        }
    }
    
    public void ShowPO(JTable tbl) 
    {
        tblModel = (DefaultTableModel) tbl.getModel();
        tblModel.setRowCount(0); 

        for (PurchaseData item : purchaseData) 
        {
            Object[] row = 
            {
                item.getPoID(),
                item.getDate(),
                item.getRequisitionID(),
                item.getPmID(),
                item.getSupplierID(),
                item.getTotalPrice(),
                item.getStatus()
            };
            tblModel.addRow(row); 
        }
    }
    
    public void ShowStock (JTable tbl) 
    {
        tblModel = (DefaultTableModel) tbl.getModel();
        tblModel.setRowCount(0); 
        
        for (InventoryData item : inventoryData) 
        {
            if(item.getTotalQty() > 0)
            {
                Object[] row = 
                {
                    item.getItemID(),
                    item.getItemName(),
                    item.getTotalQty(),
                    item.getStockLvl()
                };         
                tblModel.addRow(row); 
            }
        } 
        
    }
    
    public void Search(JTable tbl, JTextField searchbar) 
    {
        String searchItem = searchbar.getText().trim(); // Get text from the search bar
        
        String capitalizedSearchTerm = "";
        if (!searchItem.isEmpty()) 
        {
            capitalizedSearchTerm = searchItem.substring(0, 1).toUpperCase() + searchItem.substring(1);
        }
        
        boolean itemFound = false;
        
        // Create a DefaultTableModel with the correct column names
        DefaultTableModel tableModel = (DefaultTableModel) tbl.getModel();
        tableModel.setRowCount(0); // Clear the table

        // Filter inventoryData based on the search term
        for (InventoryData item : inventoryData) {
            if (item.getItemName().contains(capitalizedSearchTerm) || item.getItemID().contains(capitalizedSearchTerm)) {
                boolean hasSuppliers = false;

                // Check all suppliers for the current item
                for (SupItemData supItem : supitemData) {
                    if (supItem.getItemID().equals(item.getItemID())) {
                        hasSuppliers = true;
                        itemFound = true;
                        // Add a row for the item with its supplier details
                        tableModel.addRow(new Object[] {
                            item.getItemID(),        // Item ID
                            item.getItemName(),      // Item Name
                            supItem.getSupplierID(), // Supplier ID
                            supItem.getQuantity(),   // Supplier Quantity
                            supItem.getUnitPrice()   // Supplier Unit Price
                        });
                    }
                }

                // If no supplier is associated with the item, show a "No Supplier" row
                if (!hasSuppliers) {
                    tableModel.addRow(new Object[] {
                        item.getItemID(),
                        item.getItemName(),
                        "No Supplier",  // Placeholder for Supplier ID
                        "-",            // Placeholder for Quantity
                        "-"             // Placeholder for Unit Price
                    });
                }
            }
        }
        
        if (!itemFound){
            JOptionPane.showMessageDialog(null,"Item does not exist!", "Search Error", JOptionPane.ERROR_MESSAGE);
        }

        // Enable sorting for the table
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(tableModel);
        tbl.setRowSorter(sorter);
    }
}
