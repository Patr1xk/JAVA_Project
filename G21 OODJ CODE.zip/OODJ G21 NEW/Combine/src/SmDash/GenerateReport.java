package SmDash;

import Login.InventoryData;
import Login.PurchaseData;
import Login.RequisitionData;
import Login.SalesData;
import Login.SupItemData;
import Login.UserData;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import javax.swing.JOptionPane;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.data.category.DefaultCategoryDataset;

public class GenerateReport extends javax.swing.JFrame {
    private ArrayList<InventoryData> inventoryData;
    private ArrayList<SupItemData> supitemData;
    private ArrayList<RequisitionData> requisitionData;
    private ArrayList<PurchaseData> purchaseData;
    private ArrayList<SalesData> salesData;
    private ArrayList<UserData> userData;

    public GenerateReport(ArrayList<InventoryData> inventoryData, ArrayList<SupItemData> supitemData, ArrayList<RequisitionData> requisitionData, ArrayList<PurchaseData> purchaseData, ArrayList<SalesData> salesData, ArrayList<UserData> userData) {
        this.inventoryData = inventoryData;
        this.supitemData = supitemData;
        this.requisitionData = requisitionData;
        this.purchaseData = purchaseData;
        this.salesData= salesData;
        this.userData = userData;
        initComponents();
        pnlReport.setVisible(false);
        fillYearComboBox();
        fillMonthComboBox();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlHeader = new javax.swing.JPanel();
        lblHeader = new javax.swing.JLabel();
        home = new javax.swing.JButton();
        yearcombobox = new javax.swing.JComboBox<>();
        monthcombobox = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel4 = new javax.swing.JLabel();
        btnChart = new javax.swing.JButton();
        pnlReport = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        yearlbl = new javax.swing.JLabel();
        monthlbl = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        salesnum = new javax.swing.JLabel();
        salesamount = new javax.swing.JLabel();
        avgamount = new javax.swing.JLabel();
        bestproduct = new javax.swing.JLabel();
        highest = new javax.swing.JLabel();
        lowest = new javax.swing.JLabel();
        topmanager = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        btnReport = new javax.swing.JButton();
        btnPrint = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pnlHeader.setBackground(new java.awt.Color(51, 51, 41));
        pnlHeader.setPreferredSize(new java.awt.Dimension(800, 100));
        pnlHeader.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblHeader.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        lblHeader.setForeground(new java.awt.Color(255, 255, 255));
        lblHeader.setText("Sales Report");
        pnlHeader.add(lblHeader, new org.netbeans.lib.awtextra.AbsoluteConstraints(321, 21, -1, -1));

        home.setBackground(new java.awt.Color(51, 51, 51));
        home.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ImImage/home.jpg"))); // NOI18N
        home.setBorderPainted(false);
        home.setContentAreaFilled(false);
        home.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        home.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                homeActionPerformed(evt);
            }
        });
        pnlHeader.add(home, new org.netbeans.lib.awtextra.AbsoluteConstraints(728, 15, 42, 42));

        getContentPane().add(pnlHeader, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 63));

        yearcombobox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                yearcomboboxActionPerformed(evt);
            }
        });
        getContentPane().add(yearcombobox, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 80, -1, -1));

        monthcombobox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        monthcombobox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                monthcomboboxActionPerformed(evt);
            }
        });
        getContentPane().add(monthcombobox, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 80, -1, -1));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setText("Generate Sales Report: ");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 120, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Year:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Month:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 80, -1, -1));
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 109, -1, 56));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("View Bar Chart for Sales per Month:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 80, -1, -1));

        btnChart.setText("Chart");
        btnChart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChartActionPerformed(evt);
            }
        });
        getContentPane().add(btnChart, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 80, -1, -1));

        pnlReport.setBackground(new java.awt.Color(255, 255, 255));
        pnlReport.setMaximumSize(new java.awt.Dimension(537, 400));
        pnlReport.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setFont(new java.awt.Font("Segoe UI", 3, 26)); // NOI18N
        jLabel6.setText("Sales Report");
        pnlReport.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 130, -1, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 2, 16)); // NOI18N
        jLabel7.setText("Year:");
        pnlReport.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 170, -1, 30));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 2, 16)); // NOI18N
        jLabel8.setText("Month:");
        pnlReport.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 200, -1, 30));

        yearlbl.setText("year");
        pnlReport.add(yearlbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 170, -1, 30));

        monthlbl.setText("month");
        pnlReport.add(monthlbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 200, -1, 30));

        jLabel9.setText("Total Sales Amount:");
        pnlReport.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 300, -1, 20));

        jLabel10.setText("Best-Selling Product:");
        pnlReport.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 380, -1, 20));

        jLabel11.setText("Top Sales Manager:");
        pnlReport.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 340, -1, 20));

        jLabel12.setText("Average Sales Amount:");
        pnlReport.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 340, -1, 20));

        jLabel13.setText("Total Number of Sales:");
        pnlReport.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 260, -1, 20));
        pnlReport.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 115, -1, -1));

        jLabel15.setText("Highest Sales Amount:");
        pnlReport.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 260, -1, 20));

        jLabel16.setText("Lowest Sales Amount:");
        pnlReport.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 300, -1, 20));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 30)); // NOI18N
        jLabel17.setText("NEXUS SDN. BHD.");
        pnlReport.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 20, -1, -1));

        jLabel18.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel18.setText("Tel: 03 - 95295882");
        pnlReport.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 70, 129, -1));

        jLabel19.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel19.setText("Address: Jln Teknologi, 52000, Kuala Lumpur");
        pnlReport.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 100, -1, -1));

        salesnum.setText("jLabel4");
        pnlReport.add(salesnum, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 260, 60, 20));

        salesamount.setText("jLabel4");
        pnlReport.add(salesamount, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 300, 60, 20));

        avgamount.setText("jLabel4");
        pnlReport.add(avgamount, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 340, 60, 20));

        bestproduct.setText("jLabel4");
        pnlReport.add(bestproduct, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 380, 120, 20));

        highest.setText("jLabel4");
        pnlReport.add(highest, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 260, 80, 20));

        lowest.setText("jLabel4");
        pnlReport.add(lowest, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 300, 50, 20));

        topmanager.setText("jLabel4");
        pnlReport.add(topmanager, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 340, 60, 20));

        getContentPane().add(pnlReport, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 190, 640, 430));
        getContentPane().add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 800, 10));

        btnReport.setText("Report");
        btnReport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReportActionPerformed(evt);
            }
        });
        getContentPane().add(btnReport, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 120, -1, -1));

        btnPrint.setText("Print");
        btnPrint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrintActionPerformed(evt);
            }
        });
        getContentPane().add(btnPrint, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 160, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void homeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_homeActionPerformed
        SmDashboard dashboard = new SmDashboard(inventoryData, supitemData, requisitionData, purchaseData, salesData, userData);
        dashboard.show();
        this.dispose();
    }//GEN-LAST:event_homeActionPerformed

        private int getSalesCountForMonth(int year, int month) {
        // Calculate the sales count for the selected year and month
        // This is just an example, you should filter the data based on the selected year and month
        int count = 0;
        for (SalesData data : salesData) {
            String date = data.getDate(); // Assuming date format is "dd/MM/yyyy"
            int dataYear = Integer.parseInt(date.substring(6, 10)); // Extract year
            int dataMonth = Integer.parseInt(date.substring(3, 5)); // Extract month
            if (dataYear == year && dataMonth == month) {
                count++;
            }
        }
        return count;
    }

    private double getTotalSalesAmountForMonth(int year, int month) {
        double totalAmount = 0.0;
        for (SalesData data : salesData) {
            String date = data.getDate();
            int dataYear = Integer.parseInt(date.substring(6, 10));
            int dataMonth = Integer.parseInt(date.substring(3, 5));
            if (dataYear == year && dataMonth == month) {
                totalAmount += data.getTotalAmount(); // Assuming getTotalAmount() is defined in SalesItem
            }
        }
        return totalAmount;
    }

    private double getHighestSaleAmountForMonth(int year, int month) {
        double highestAmount = 0.0;
        for (SalesData data : salesData) {
            String date = data.getDate();
            int dataYear = Integer.parseInt(date.substring(6, 10));
            int dataMonth = Integer.parseInt(date.substring(3, 5));
            if (dataYear == year && dataMonth == month) {
                double totalAmount = data.getTotalAmount();
                if (totalAmount > highestAmount) {
                    highestAmount = totalAmount;
                }
            }
        }
        return highestAmount;
    }
    
    private double getLowestSaleAmountForMonth(int year, int month) {
        double lowestAmount = Double.MAX_VALUE;
        for (SalesData data : salesData) {
            String date = data.getDate();
            int dataYear = Integer.parseInt(date.substring(6, 10));
            int dataMonth = Integer.parseInt(date.substring(3, 5));
            if (dataYear == year && dataMonth == month) {
                double totalAmount = data.getTotalAmount();
                if (totalAmount < lowestAmount) {
                    lowestAmount = totalAmount;
                }
            }
        }
        return lowestAmount == Double.MAX_VALUE ? 0.0 : lowestAmount;  // Handle no sales case
    }
    
    private String getBestSellingProductForMonth(int year, int month) {
        Map<String, Integer> productSales = new HashMap<>();

        for (SalesData data : salesData) {
            String date = data.getDate();
            int dataYear = Integer.parseInt(date.substring(6, 10));
            int dataMonth = Integer.parseInt(date.substring(3, 5));
            if (dataYear == year && dataMonth == month) {
                String product = data.getItemName();
                int quantity = data.getQty();
                productSales.put(product, productSales.getOrDefault(product, 0) + quantity);
            }
        }

        String bestProduct = null;
        int maxSales = 0;
        for (Map.Entry<String, Integer> entry : productSales.entrySet()) {
            if (entry.getValue() > maxSales) {
                maxSales = entry.getValue();
                bestProduct = entry.getKey();
            }
        }

        return bestProduct == null ? "No Sales" : bestProduct;
    }

    private String getTopSalesManagerForMonth(int year, int month) {
        Map<String, Double> managerSales = new HashMap<>();

        for (SalesData data : salesData) {
            String date = data.getDate();
            int dataYear = Integer.parseInt(date.substring(6, 10));
            int dataMonth = Integer.parseInt(date.substring(3, 5));
            if (dataYear == year && dataMonth == month) {
                String managerId = data.getSalesManagerID();
                double totalAmount = data.getTotalAmount();
                managerSales.put(managerId, managerSales.getOrDefault(managerId, 0.0) + totalAmount);
            }
        }

        String topManager = null;
        double maxSales = 0.0;
        for (Map.Entry<String, Double> entry : managerSales.entrySet()) {
            if (entry.getValue() > maxSales) {
                maxSales = entry.getValue();
                topManager = entry.getKey();
            }
        }

        return topManager == null ? "No Sales" : topManager;
    }

    
    
    private void fillYearComboBox() {
        Set<String> uniqueYears = new HashSet<>();
        
        // Clear the combo box before adding new data
        yearcombobox.removeAllItems();
        
        // Loop through salesData to extract unique years
        for (SalesData data : salesData) {
            System.out.println(data.getDate());
            String date = data.getDate();  // Assuming date format is "dd/MM/yyyy"
            String year = date.substring(6, 10);  // Extract year from the date
            uniqueYears.add(year);  // Add the year to the set (duplicates will be ignored)
        }



        // Add the unique years to the combo box
        for (String year : uniqueYears) {
            yearcombobox.addItem(year);
        }

    }
    
    private void fillMonthComboBox() {
        Set<String> uniqueMonths = new TreeSet<>();
        
        // Clear the combo box before adding new data
        monthcombobox.removeAllItems();
        
        // Loop through salesData to extract unique years
        for (SalesData data : salesData) {
            System.out.println(data.getDate());
            String date = data.getDate();  // Assuming date format is "dd/MM/yyyy"
            String month = date.substring(3,5);  // Extract year from the date
            System.out.println("Extracted Month: " + month);
            uniqueMonths.add(month);  // Add the year to the set (duplicates will be ignored)
        }

        // Add the unique years to the combo box
        for (String month : uniqueMonths) {
            monthcombobox.addItem(month);
        }

    }

    
    private void btnChartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChartActionPerformed
        String selectedYear = yearcombobox.getSelectedItem().toString(); 
        if (selectedYear == null || selectedYear.isEmpty()) {
            // Show error message if no year is selected
            JOptionPane.showMessageDialog(this, "Please select a year to generate the chart.", "Error", JOptionPane.ERROR_MESSAGE);
            return; 
        }

        // To store the monthly total sales
        // Initialize the monthly total sales map with all months
        Map<String, Double> monthlySales = new LinkedHashMap<>();
        monthlySales.put("01", 0.0);
        monthlySales.put("02", 0.0);
        monthlySales.put("03", 0.0);
        monthlySales.put("04", 0.0);
        monthlySales.put("05", 0.0);
        monthlySales.put("06", 0.0);
        monthlySales.put("07", 0.0);
        monthlySales.put("08", 0.0);
        monthlySales.put("09", 0.0);
        monthlySales.put("10", 0.0);
        monthlySales.put("11", 0.0);
        monthlySales.put("12", 0.0);

        for (SalesData data : salesData) {
            String date = data.getDate();
            double totalAmount = data.getTotalAmount();
            // Extract month/year from date
            String month = date.substring(3, 5);  // Assumes date is in format "dd/MM/yyyy"
            String year = date.substring(6, 10);  // Assumes date is in format "dd/MM/yyyy"

            // Only accumulate the sales amount for the selected year
            if (year.equals(selectedYear)) {
                monthlySales.put(month, monthlySales.getOrDefault(month, 0.0) + totalAmount);
            }
        }

        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        for (Map.Entry<String, Double> entry : monthlySales.entrySet()) {
            String month = entry.getKey();
            Double totalSales = entry.getValue();
            dataset.setValue(totalSales, "Sales", month);
        }

        JFreeChart chart = ChartFactory.createBarChart("Total Sales per Month", "Month", "Sales", dataset);
        CategoryPlot p = chart.getCategoryPlot();
        p.setRangeGridlinePaint(Color.black);
        ChartFrame frame = new ChartFrame("Chart for Total Sales per Month", chart);
        frame.setVisible(true);
        frame.setSize(800, 500);
    }//GEN-LAST:event_btnChartActionPerformed

    private void btnReportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReportActionPerformed
        String selectedYear = yearcombobox.getSelectedItem().toString();
        String selectedMonth = monthcombobox.getSelectedItem().toString();

        // Check if either year or month is not selected
        if (selectedYear.isEmpty() || selectedMonth.isEmpty())
        {
            // Show error message if either is not selected
            JOptionPane.showMessageDialog(this, "Please select both year and month.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        else
        {
            // Parse selected year and month
            int year = Integer.parseInt(selectedYear);
            int month = Integer.parseInt(selectedMonth);

            yearlbl.setText(String.valueOf(year));
            monthlbl.setText(String.valueOf(month));
            int totalSalesCount = getSalesCountForMonth(year, month);  // Example method to get the count
            double totalSalesAmount = getTotalSalesAmountForMonth(year, month);  // Example method to get total sales amount
            double averageSalesAmount = totalSalesCount > 0 ? totalSalesAmount / totalSalesCount : 0.0;
            double highestSaleAmount = getHighestSaleAmountForMonth(year, month);  // Example method to get highest sale amoun
            double lowestSaleAmount = getLowestSaleAmountForMonth(year, month);
            String bestSellingProduct = getBestSellingProductForMonth(year, month);
            String topSalesManager = getTopSalesManagerForMonth(year, month);

            salesnum.setText(String.valueOf(totalSalesCount));
            salesamount.setText(String.valueOf(totalSalesAmount));
            avgamount.setText(String.valueOf(averageSalesAmount));
            highest.setText(String.valueOf(highestSaleAmount));
            lowest.setText(String.valueOf(lowestSaleAmount));
            bestproduct.setText(bestSellingProduct);
            topmanager.setText(topSalesManager);

            pnlReport.setVisible(true);
            // Show success message
            JOptionPane.showMessageDialog(this, "Report generated successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_btnReportActionPerformed

    private void btnPrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrintActionPerformed
        try {
            // Capture the JPanel 
            BufferedImage originalImage = new BufferedImage(
                    pnlReport.getWidth(),
                    pnlReport.getHeight(),
                    BufferedImage.TYPE_INT_RGB);
            Graphics2D g2d = originalImage.createGraphics();
            pnlReport.paint(g2d);
            g2d.dispose();

            // Resize the BufferedImage to make it shorter
            int targetHeight = 500; // Set the desired height for the PDF content
            int targetWidth = pnlReport.getWidth(); // Maintain the original width
            BufferedImage resizedImage = new BufferedImage(targetWidth, targetHeight, BufferedImage.TYPE_INT_RGB);
            Graphics2D g2dResized = resizedImage.createGraphics();
            g2dResized.drawImage(originalImage, 0, 0, targetWidth, targetHeight, null);
            g2dResized.dispose();

            // Create PDF file
            String filePath = "NEXUS SDN BHD Sales Report.pdf"; //name
            com.itextpdf.text.Document document = new com.itextpdf.text.Document();
            com.itextpdf.text.pdf.PdfWriter.getInstance(document, new FileOutputStream(filePath));
            document.open();

            // Convert resized BufferedImage to iText Image
            com.itextpdf.text.Image pdfImage = com.itextpdf.text.Image.getInstance(resizedImage, null);
            pdfImage.scaleToFit(document.getPageSize().getWidth() - 50, document.getPageSize().getHeight() - 50);
            pdfImage.setAlignment(com.itextpdf.text.Image.ALIGN_CENTER);

            // Add resized image to PDF document
            document.add(pdfImage);
            document.close();

            JOptionPane.showMessageDialog(null, "PDF generated successfully at: " + filePath);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error generating PDF: " + e.getMessage());
        }
    }//GEN-LAST:event_btnPrintActionPerformed

    private void monthcomboboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_monthcomboboxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_monthcomboboxActionPerformed

    private void yearcomboboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_yearcomboboxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_yearcomboboxActionPerformed


    public static void main(String args[]) {
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new GenerateReport().setVisible(true);
//            }
//        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel avgamount;
    private javax.swing.JLabel bestproduct;
    private javax.swing.JButton btnChart;
    private javax.swing.JButton btnPrint;
    private javax.swing.JButton btnReport;
    private javax.swing.JLabel highest;
    private javax.swing.JButton home;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JLabel lblHeader;
    private javax.swing.JLabel lowest;
    private javax.swing.JComboBox<String> monthcombobox;
    private javax.swing.JLabel monthlbl;
    private javax.swing.JPanel pnlHeader;
    private javax.swing.JPanel pnlReport;
    private javax.swing.JLabel salesamount;
    private javax.swing.JLabel salesnum;
    private javax.swing.JLabel topmanager;
    private javax.swing.JComboBox<String> yearcombobox;
    private javax.swing.JLabel yearlbl;
    // End of variables declaration//GEN-END:variables
}
