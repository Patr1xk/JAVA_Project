package SmDash;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

public class StockRenderer extends DefaultTableCellRenderer
{
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) 
    {
        Component cell = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        if (column == 3)
        {
            Object rowData = table.getValueAt(row, column);
            
            // Change rowData to String and compare it to "Low"
            if (rowData != null && "Low".equalsIgnoreCase(rowData.toString())) 
            {
                // Set background red and text white if stock level is "Low"
                cell.setBackground(Color.RED);
                cell.setForeground(Color.WHITE);
            } else 
            {
                // Set default white background and black text
                cell.setBackground(Color.WHITE);
                cell.setForeground(Color.BLACK);
            }
        } else 
        {
            // For other columns, use default coloring
            cell.setBackground(Color.WHITE);
            cell.setForeground(Color.BLACK);
        }
        return cell;
    }
}


