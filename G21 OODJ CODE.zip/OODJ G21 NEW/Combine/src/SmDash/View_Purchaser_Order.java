package SmDash;

import Login.InventoryData;
import Login.PurchaseData;
import Login.RequisitionData;
import Login.SalesData;
import Login.SupItemData;
import Login.UserData;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

public class View_Purchaser_Order extends javax.swing.JFrame {
    private ArrayList<InventoryData> inventoryData;
    private ArrayList<SupItemData> supitemData;
    private ArrayList<RequisitionData> requisitionData;
    private ArrayList<PurchaseData> purchaseData;
    private ArrayList<SalesData> salesData;
    private ArrayList<UserData> userData;
    private View view;
    
    public View_Purchaser_Order(ArrayList<InventoryData> inventoryData, ArrayList<SupItemData> supitemData, ArrayList<RequisitionData> requisitionData, ArrayList<PurchaseData> purchaseData, ArrayList<SalesData> salesData, ArrayList<UserData> userData) {
        this.inventoryData = inventoryData;
        this.supitemData = supitemData;
        this.requisitionData = requisitionData;
        this.purchaseData = purchaseData;
        this.salesData= salesData;
        this.userData = userData;
        view = new View(this.inventoryData, this.supitemData, this.requisitionData, this.purchaseData, this.salesData, this.userData);
        initComponents();

        view.ShowPO(potable);
        potable.setDefaultRenderer(Object.class, new StatusRenderer());
    }
      
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblHeader = new javax.swing.JLabel();
        btnHome = new javax.swing.JButton();
        statuscombobox = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        potable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(51, 51, 41));

        lblHeader.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        lblHeader.setForeground(new java.awt.Color(255, 255, 255));
        lblHeader.setText("Purchaser Order");

        btnHome.setBackground(new java.awt.Color(51, 51, 51));
        btnHome.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ImImage/home.jpg"))); // NOI18N
        btnHome.setBorderPainted(false);
        btnHome.setContentAreaFilled(false);
        btnHome.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnHome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHomeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(319, Short.MAX_VALUE)
                .addComponent(lblHeader)
                .addGap(222, 222, 222)
                .addComponent(btnHome, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(lblHeader)
                .addGap(15, 15, 15))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnHome, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 60));

        statuscombobox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "PO Status", "Approved", "Pending" }));
        statuscombobox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                statuscomboboxActionPerformed(evt);
            }
        });
        getContentPane().add(statuscombobox, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 80, -1, -1));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setText("View:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, -1, -1));

        potable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "PO ID", "PO Date", "Requisition ID", "PM ID", "Supplier ID", "Total Amount", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(potable);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 780, 380));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void statuscomboboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_statuscomboboxActionPerformed
        DefaultTableModel poTblModel = (DefaultTableModel) potable.getModel();
        String selectedstatus = (String) statuscombobox.getSelectedItem();

        poTblModel.setRowCount(0);
        for (PurchaseData purchase : purchaseData)
        {
            if(selectedstatus.equalsIgnoreCase("PO Status"))
            {
                view.ShowPO(potable);
            }
            else if(selectedstatus.equalsIgnoreCase("Approved") && purchase.getStatus().equalsIgnoreCase("Approved"))
            {
                String poID = purchase.getPoID();
                String date = purchase.getDate();
                String reqID = purchase.getRequisitionID();
                String pmID = purchase.getPmID();
                String supID = purchase.getSupplierID();
                double total = purchase.getTotalPrice();
                String status = purchase.getStatus();

                poTblModel.addRow(new Object[]{poID, date, reqID, pmID, supID, total, status});
            }
            else if(selectedstatus.equalsIgnoreCase("Pending") && purchase.getStatus().equalsIgnoreCase("Pending"))
            {
                String poID = purchase.getPoID();
                String date = purchase.getDate();
                String reqID = purchase.getRequisitionID();
                String pmID = purchase.getPmID();
                String supID = purchase.getSupplierID();
                double total = purchase.getTotalPrice();
                String status = purchase.getStatus();

                poTblModel.addRow(new Object[]{poID, date, reqID, pmID, supID, total, status});
            }

        }

    }//GEN-LAST:event_statuscomboboxActionPerformed

    private void btnHomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHomeActionPerformed
        // TODO add your handling code here:
        SmDashboard dashboard = new SmDashboard(inventoryData, supitemData, requisitionData, purchaseData, salesData, userData);

        dashboard.show();
        this.dispose();
    }//GEN-LAST:event_btnHomeActionPerformed

    public static void main(String args[]) {
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new View_Purchaser_Order().setVisible(true);
//            }
//        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnHome;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblHeader;
    private javax.swing.JTable potable;
    private javax.swing.JComboBox<String> statuscombobox;
    // End of variables declaration//GEN-END:variables
}
