package SmDash;

import Login.InventoryData;
import Login.LoginPage;
import Login.PurchaseData;
import Login.RequisitionData;
import Login.ResetPasswordPage;
import Login.SalesData;
import Login.SupItemData;
import Login.UserData;
import java.util.ArrayList;

public class SmDashboard extends javax.swing.JFrame {
    private ArrayList<InventoryData> inventoryData;
    private ArrayList<SupItemData> supitemData;
    private ArrayList<RequisitionData> requisitionData;
    private ArrayList<PurchaseData> purchaseData;
    private ArrayList<SalesData> salesData;
    private ArrayList<UserData> userData;

    
    public SmDashboard(ArrayList<InventoryData> inventoryData, ArrayList<SupItemData> supitemData, ArrayList<RequisitionData> requisitionData, ArrayList<PurchaseData> purchaseData, ArrayList<SalesData> salesData, ArrayList<UserData> userData) {
        this.inventoryData = inventoryData;
        this.supitemData = supitemData;
        this.requisitionData = requisitionData;
        this.purchaseData = purchaseData;
        this.salesData= salesData;
        this.userData = userData;
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        btnLogOut = new javax.swing.JButton();
        resetpassword = new javax.swing.JButton();
        lblSalesEntry = new javax.swing.JLabel();
        viewstocklevel = new javax.swing.JButton();
        lblGenerate = new javax.swing.JLabel();
        lblViewStock = new javax.swing.JLabel();
        lblViewPurchase = new javax.swing.JLabel();
        lblRequisiton = new javax.swing.JLabel();
        lblViewItem = new javax.swing.JLabel();
        btnSalesEntry = new javax.swing.JButton();
        btnViewPO = new javax.swing.JButton();
        btnRequisition = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        btnViewItem = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 80));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Sales Manager Dashboard");

        btnLogOut.setBackground(new java.awt.Color(51, 51, 51));
        btnLogOut.setIcon(new javax.swing.ImageIcon(getClass().getResource("/LoginImage/logout.png"))); // NOI18N
        btnLogOut.setBorder(null);
        btnLogOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogOutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(72, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 582, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addComponent(btnLogOut, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(24, 24, 24))
            .addComponent(btnLogOut, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 78));

        resetpassword.setBackground(new java.awt.Color(242, 242, 242));
        resetpassword.setFont(new java.awt.Font("Arial", 1, 13)); // NOI18N
        resetpassword.setText("Reset Password");
        resetpassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetpasswordActionPerformed(evt);
            }
        });
        getContentPane().add(resetpassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(664, 465, -1, -1));

        lblSalesEntry.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblSalesEntry.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblSalesEntry.setText("Sales Entry");
        getContentPane().add(lblSalesEntry, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 260, 110, 39));

        viewstocklevel.setBackground(new java.awt.Color(242, 242, 242));
        viewstocklevel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/SmImage/view_stock.png"))); // NOI18N
        viewstocklevel.setBorderPainted(false);
        viewstocklevel.setContentAreaFilled(false);
        viewstocklevel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewstocklevelActionPerformed(evt);
            }
        });
        getContentPane().add(viewstocklevel, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 310, 175, 140));

        lblGenerate.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblGenerate.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblGenerate.setText("Generate Sales Report");
        getContentPane().add(lblGenerate, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 260, 143, 39));

        lblViewStock.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblViewStock.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblViewStock.setText("View Stock Level");
        getContentPane().add(lblViewStock, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 460, 144, -1));

        lblViewPurchase.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblViewPurchase.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblViewPurchase.setText("View Purchaser Order");
        getContentPane().add(lblViewPurchase, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 460, 161, -1));

        lblRequisiton.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblRequisiton.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblRequisiton.setText("Requisition");
        getContentPane().add(lblRequisiton, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 460, 88, -1));

        lblViewItem.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblViewItem.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblViewItem.setText("View Item List");
        getContentPane().add(lblViewItem, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 260, 110, 39));

        btnSalesEntry.setBackground(new java.awt.Color(242, 242, 242));
        btnSalesEntry.setIcon(new javax.swing.ImageIcon(getClass().getResource("/SmImage/sales_entry.png"))); // NOI18N
        btnSalesEntry.setBorderPainted(false);
        btnSalesEntry.setContentAreaFilled(false);
        btnSalesEntry.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalesEntryActionPerformed(evt);
            }
        });
        getContentPane().add(btnSalesEntry, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 110, 162, 155));

        btnViewPO.setBackground(new java.awt.Color(242, 242, 242));
        btnViewPO.setIcon(new javax.swing.ImageIcon(getClass().getResource("/SmImage/purchaser_icon.jpg"))); // NOI18N
        btnViewPO.setBorderPainted(false);
        btnViewPO.setContentAreaFilled(false);
        btnViewPO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewPOActionPerformed(evt);
            }
        });
        getContentPane().add(btnViewPO, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 300, 162, 155));

        btnRequisition.setBackground(new java.awt.Color(242, 242, 242));
        btnRequisition.setIcon(new javax.swing.ImageIcon(getClass().getResource("/SmImage/requisition_icon.jpg"))); // NOI18N
        btnRequisition.setBorderPainted(false);
        btnRequisition.setContentAreaFilled(false);
        btnRequisition.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRequisitionActionPerformed(evt);
            }
        });
        getContentPane().add(btnRequisition, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 300, 162, 155));

        jButton1.setBackground(new java.awt.Color(242, 242, 242));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/SmImage/PO_icon.jpg"))); // NOI18N
        jButton1.setBorder(null);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 120, 160, 140));

        btnViewItem.setBackground(new java.awt.Color(242, 242, 242));
        btnViewItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/SmImage/item_icon.jpg"))); // NOI18N
        btnViewItem.setBorder(null);
        btnViewItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewItemActionPerformed(evt);
            }
        });
        getContentPane().add(btnViewItem, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 120, 160, 140));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void resetpasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetpasswordActionPerformed
        // TODO add your handling code here:
        ResetPasswordPage resetPass = new ResetPasswordPage(userData);
        resetPass.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_resetpasswordActionPerformed

    private void viewstocklevelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewstocklevelActionPerformed
        View_Stock_Level viewstock = new View_Stock_Level(inventoryData, supitemData, requisitionData, purchaseData, salesData, userData);
    
        viewstock.show();
        this.dispose();
    }//GEN-LAST:event_viewstocklevelActionPerformed

    private void btnSalesEntryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalesEntryActionPerformed
        // TODO add your handling code here:
        Sales_Entry entry = new Sales_Entry(inventoryData, supitemData, requisitionData, purchaseData, salesData, userData);

        entry.show();
        this.dispose();
    }//GEN-LAST:event_btnSalesEntryActionPerformed

    private void btnViewPOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewPOActionPerformed
        // TODO add your handling code here:
        View_Purchaser_Order viewpo = new View_Purchaser_Order(inventoryData, supitemData, requisitionData, purchaseData, salesData, userData);
        
        viewpo.show();
        this.dispose();
    }//GEN-LAST:event_btnViewPOActionPerformed

    private void btnRequisitionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRequisitionActionPerformed
        // TODO add your handling code here:
        Requisition rq = new Requisition(inventoryData, supitemData, requisitionData, purchaseData, salesData, userData);
        rq.show();
        this.dispose();
    }//GEN-LAST:event_btnRequisitionActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        GenerateReport g = new GenerateReport(inventoryData, supitemData, requisitionData, purchaseData, salesData, userData);
        g.show();
        
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnViewItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewItemActionPerformed
        // TODO add your handling code here:
        View_Item_List itemlist = new View_Item_List(inventoryData, supitemData, requisitionData, purchaseData, salesData, userData);
    
        itemlist.show();
        this.dispose();
    }//GEN-LAST:event_btnViewItemActionPerformed

    private void btnLogOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogOutActionPerformed
        // TODO add your handling code here:
        LoginPage loginPage = new LoginPage();
        loginPage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnLogOutActionPerformed

    public static void main(String args[]) {
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new SmDashboard().setVisible(true);
//            }
//        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnLogOut;
    private javax.swing.JButton btnRequisition;
    private javax.swing.JButton btnSalesEntry;
    private javax.swing.JButton btnViewItem;
    private javax.swing.JButton btnViewPO;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblGenerate;
    private javax.swing.JLabel lblRequisiton;
    private javax.swing.JLabel lblSalesEntry;
    private javax.swing.JLabel lblViewItem;
    private javax.swing.JLabel lblViewPurchase;
    private javax.swing.JLabel lblViewStock;
    private javax.swing.JButton resetpassword;
    private javax.swing.JButton viewstocklevel;
    // End of variables declaration//GEN-END:variables
}
