package SmDash;

import Login.InventoryData;
import Login.PurchaseData;
import Login.RequisitionData;
import Login.SalesData;
import Login.SupItemData;
import Login.UserData;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

public class View_Stock_Level extends javax.swing.JFrame {   
    private ArrayList<InventoryData> inventoryData;
    private ArrayList<SupItemData> supitemData;
    private ArrayList<RequisitionData> requisitionData;
    private ArrayList<PurchaseData> purchaseData;
    private ArrayList<SalesData> salesData;
    private ArrayList<UserData> userData;
    private View view;
    
    public View_Stock_Level(ArrayList<InventoryData> inventoryData, ArrayList<SupItemData> supitemData, ArrayList<RequisitionData> requisitionData, ArrayList<PurchaseData> purchaseData, ArrayList<SalesData> salesData, ArrayList<UserData> userData) {
        this.inventoryData = inventoryData;
        this.supitemData = supitemData;
        this.requisitionData = requisitionData;
        this.purchaseData = purchaseData;
        this.salesData= salesData;
        this.userData = userData;
        view = new View(this.inventoryData, this.supitemData, this.requisitionData, this.purchaseData, this.salesData, this.userData);
        initComponents();
        
        view.ShowStock(itemTbl);
        itemTbl.setDefaultRenderer(Object.class, new StockRenderer());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        header1 = new javax.swing.JLabel();
        home = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        itemTbl = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        statuscombobox = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(51, 51, 41));

        header1.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        header1.setForeground(new java.awt.Color(255, 255, 255));
        header1.setText("Stock Level");

        home.setBackground(new java.awt.Color(51, 51, 51));
        home.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ImImage/home.jpg"))); // NOI18N
        home.setBorderPainted(false);
        home.setContentAreaFilled(false);
        home.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        home.setMaximumSize(new java.awt.Dimension(42, 42));
        home.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                homeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(336, Short.MAX_VALUE)
                .addComponent(header1)
                .addGap(252, 252, 252)
                .addComponent(home, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(header1)
                .addGap(14, 14, 14))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(home, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 794, 60));

        itemTbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item ID", "Item Name", "Quantity", "Stock Level"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(itemTbl);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 782, 393));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setText("View:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, -1));

        statuscombobox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All Stock", "Low Stock" }));
        statuscombobox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                statuscomboboxActionPerformed(evt);
            }
        });
        getContentPane().add(statuscombobox, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 70, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void homeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_homeActionPerformed
        SmDashboard dashboard = new SmDashboard(inventoryData, supitemData, requisitionData, purchaseData, salesData, userData);  
        dashboard.show();
        this.dispose();
    }//GEN-LAST:event_homeActionPerformed

    private void statuscomboboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_statuscomboboxActionPerformed
        String sort = (String) statuscombobox.getSelectedItem();
        DefaultTableModel itemTblModel = (DefaultTableModel) itemTbl.getModel();
        itemTblModel.setRowCount(0);
        for(InventoryData inventory: inventoryData)
        {
            if(inventory.getTotalQty() != 0 && sort.equalsIgnoreCase("All Stock"))
            {
                String itemID = inventory.getItemID();
                String itemName = inventory.getItemName();
                int totalQty = inventory.getTotalQty();
                String stockLvl = inventory.getStockLvl();

                itemTblModel.addRow(new Object[]{itemID, itemName, totalQty, stockLvl});
            }
            else
            {
                if(inventory.getStockLvl().equalsIgnoreCase("Low"))
                {
                    String itemID = inventory.getItemID();
                    String itemName = inventory.getItemName();
                    int totalQty = inventory.getTotalQty();
                    String stockLvl = inventory.getStockLvl();

                    itemTblModel.addRow(new Object[]{itemID, itemName, totalQty, stockLvl});
                }
            }
        }     
    }//GEN-LAST:event_statuscomboboxActionPerformed

    public static void main(String args[]) {
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new View_Stock_Level().setVisible(true);
//            }
//        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel header1;
    private javax.swing.JButton home;
    private javax.swing.JTable itemTbl;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox<String> statuscombobox;
    // End of variables declaration//GEN-END:variables
}
