package SmDash;

import Login.FileHandling;
import Login.InventoryData;
import Login.PurchaseData;
import Login.RequisitionData;
import Login.SalesData;
import Login.SupItemData;
import Login.UserData;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class SalesEntryFunction implements FileHandling{
    private ArrayList<InventoryData> inventoryData;
    private ArrayList<SupItemData> supitemData;
    private ArrayList<RequisitionData> requisitionData;
    private ArrayList<PurchaseData> purchaseData;
    private ArrayList<SalesData> salesData;
    private ArrayList<UserData> userData;

    public SalesEntryFunction(ArrayList<InventoryData> inventoryData, ArrayList<SupItemData> supitemData, ArrayList<RequisitionData> requisitionData, ArrayList<PurchaseData> purchaseData, ArrayList<SalesData> salesData, ArrayList<UserData> userData) 
    {
        this.inventoryData = inventoryData;
        this.supitemData = supitemData;
        this.requisitionData = requisitionData;
        this.purchaseData = purchaseData;
        this.salesData= salesData;
        this.userData = userData;
    }    
    
    private String generateSalesID() {
        return "SA" + String.format("%03d", salesData.size() + 1);
    }

    private String getSalesManagerID(ArrayList<UserData> userData) {
        String salesManagerID;
        boolean foundManager = false;
        boolean ownID = false;

        do {
            // Ask for Sales Manager ID
            salesManagerID = JOptionPane.showInputDialog("Enter Sales Manager ID:", "SM");

            if (salesManagerID == null || salesManagerID.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Sales Manager ID cannot be empty. Please try again.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                continue;
            }

            salesManagerID = salesManagerID.trim();

            // Check if the entered ID exists in userData
            for (UserData user : userData) {
                if (user.getUserID().equalsIgnoreCase(salesManagerID)) {
                    foundManager = true;
                    return salesManagerID; // Found, return the valid ID
                    
                }
            }
           
            if (!foundManager) {
                JOptionPane.showMessageDialog(null, "Sales Manager ID not found in user database. Please try again.", "Invalid Sales Manager ID", JOptionPane.ERROR_MESSAGE);
            }

            //validate if this sm is its id or not
            for(UserData user: userData)
            {
                if(user.getUserID().equalsIgnoreCase(salesManagerID))
                {
                    
                }
            }
            
            
            
            
            
        } while (!foundManager);

        return null; 
    }

    // Function to get Item Details
    private InventoryData getItemDetails(ArrayList<InventoryData> inventoryData) {
        String itemID;
        InventoryData matchingItem = null;
        boolean isFound = false;
        
        //EXAMPLE
//        do {
//            itemName = JOptionPane.showInputDialog("Enter item name");
//            if (itemName == null)
//            {
//                return;
//            }
//            itemName = itemName.trim();
//            if (itemName.isEmpty()) {
//                JOptionPane.showMessageDialog(null, "Item Name cannot be empty! Please try again!");
//            } else {
//                itemName = itemName.substring(0, 1).toUpperCase() + itemName.substring(1);
//            }
//        } while (itemName.isEmpty());

        do {
            itemID = JOptionPane.showInputDialog("Enter Item ID:", "I");

            if(itemID == null)
            {
                break;
            }
            itemID = itemID.trim();
            if (itemID.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Item ID cannot be empty. Please try again.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                continue;
            }
            

            isFound = false;

            for (InventoryData item : inventoryData) {
                if (item.getItemID().equalsIgnoreCase(itemID)) {
                    isFound = true;
                    matchingItem = item;
                    break;
                }
            }

            if (!isFound) {
                JOptionPane.showMessageDialog(null, "Item ID not found in inventory. Please try again.", "Invalid Item ID", JOptionPane.ERROR_MESSAGE);
            }
        } while (!isFound);

        return matchingItem;
    }

    // Function to get Quantity
    private int getQuantity() {
        int qty;
        do {
            try {
                qty = Integer.parseInt(JOptionPane.showInputDialog("Enter Quantity:"));
                if (qty <= 0) {
                    JOptionPane.showMessageDialog(null, "Quantity must be a positive number. Please try again.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid number. Please enter a valid quantity.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                qty = -1;
            }
        } while (qty <= 0);

        return qty;
    }
    
    private double getUnitPriceFromSupplier(String itemID) 
    {
        String supplierID = null;
        double unitPrice = -1;  // Initialize unit price as -1 to indicate an error
        boolean validSupplier = false;

        // Ask the user for Supplier ID until a valid one is provided
        do {
            // Prompt the user for Supplier ID
            supplierID = JOptionPane.showInputDialog("Enter Supplier ID for Item ID " + itemID + ":", "S");

            // Check if the user canceled or provided an empty input
            if (supplierID == null || supplierID.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Supplier ID cannot be empty. Please try again.", 
                                              "Invalid Input", JOptionPane.ERROR_MESSAGE);
                continue;  // Continue asking for a valid Supplier ID
            }

            // Check if the entered Supplier ID exists for the given itemID
            for (SupItemData supItem : supitemData) {
                if (supItem.getItemID().equalsIgnoreCase(itemID) && supItem.getSupplierID().equalsIgnoreCase(supplierID)) {
                    validSupplier = true;  // Valid supplier found
                    unitPrice = supItem.getUnitPrice();  // Get the unit price for the item
                    break;
                }
            }

            // If the Supplier ID is invalid or not found for the given item, show an error
            if (!validSupplier) {
                JOptionPane.showMessageDialog(null, "Supplier ID not found for this item. Please try again.", 
                                              "Supplier Not Found", JOptionPane.ERROR_MESSAGE);
            }

        } while (!validSupplier);  // Continue until a valid Supplier ID is entered

        return unitPrice;  // Return the unit price or -1 if no valid supplier was found
    }

    private String getSupplierID(String itemID) 
    {
        String supplierID = null;

        // Loop through the supitemData to find the Supplier ID for the given Item ID
        for (SupItemData supItem : supitemData) 
        {
            if (supItem.getItemID().equalsIgnoreCase(itemID)) 
            {
                supplierID = supItem.getSupplierID();  // Set the Supplier ID for this Item ID
                break;
            }
        }

        // If no supplier was found for the given Item ID, show an error message
        if (supplierID == null) {
            JOptionPane.showMessageDialog(null, "No supplier found for the selected item.", 
                                          "Supplier Not Found", JOptionPane.ERROR_MESSAGE);
    }
    return supplierID;  // Return the Supplier ID (or null if not found)
}

    public void addSalesEntry(JTable salesentrytable) {
        String date = Date_Format.getCurrentDate();
        String salesID = generateSalesID();
        String salesManagerID = getSalesManagerID(userData);

        // Get Item Details
        InventoryData matchingItem = getItemDetails(inventoryData);
        if (matchingItem == null) {
            JOptionPane.showMessageDialog(null, "Error: Item not found, cannot proceed.", "Item Not Found", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String itemID = matchingItem.getItemID();
        String itemName = matchingItem.getItemName();

        // Get Supplier ID and Unit Price
        double unitPrice = getUnitPriceFromSupplier(itemID);
        if (unitPrice == -1) {
            JOptionPane.showMessageDialog(null, "Error: No supplier found for this item, cannot proceed.", "Supplier Not Found", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Get Quantity
        int qty = getQuantity();

        // Calculate Total Amount
        double totalAmount = unitPrice * qty;

        // Get Supplier ID
        String supplierID = getSupplierID(itemID);

        // Create and Add Sales Item with Supplier ID
        SalesData newItem = new SalesData(date, salesID, salesManagerID, itemID, itemName, unitPrice, qty, totalAmount);
        salesData.add(newItem);
        updateTable(salesentrytable);

        JOptionPane.showMessageDialog(null, "Sales entry added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
}

    public void updateTable(JTable salesentrytable)
    {
        DefaultTableModel model = (DefaultTableModel) salesentrytable.getModel();
        model.setRowCount(0); 
        // Loop through the salesData list to add rows to the table
        for (SalesData item : salesData) {
            model.addRow(new Object[]{
                item.getDate(),
                item.getSalesID(),
                item.getSalesManagerID(),
                item.getItemID(),
                item.getItemName(),
                item.getUnitPrice(),
                item.getQty(),
                item.getTotalAmount()
            });
        }
    }
   
    public void Edit(JTable table) {
        boolean isModified = false;
        DefaultTableModel tblModel = (DefaultTableModel) table.getModel();

        // Ensure exactly one cell is selected
        if (table.getSelectedRowCount() == 1 && table.getSelectedColumnCount() == 1) 
        {
            int colToEditIndex = table.getSelectedColumn();
            int rowToEditIndex = table.getSelectedRow();

            // Get the column name for the selected column
            String colName = table.getColumnName(colToEditIndex);

            // Get new value from input
            String newValue = JOptionPane.showInputDialog(null, "Edit value for " + colName + ":");

            // Handle Sales Manager ID validation
            if (colName.equals("Sales Manager ID")) 
            {
                boolean managerExists = false;
                if (newValue != null && !newValue.isEmpty()) 
                {
                    newValue = newValue.trim();
                }

                // Iterate through userData list to check if the Sales Manager ID exists
                for (UserData user : userData) 
                {
                    if (user.getUserID().equalsIgnoreCase(newValue)) 
                    {
                        managerExists = true;
                        break;
                    }
                }

                if (!managerExists) 
                {
                    JOptionPane.showMessageDialog(null, "Sales Manager ID not found!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Update Sales Manager ID in table and salesData
                tblModel.setValueAt(newValue, rowToEditIndex, colToEditIndex);
                salesData.get(rowToEditIndex).setSalesManagerID(newValue);
            }

            // Handle Item ID update
            if (colName.equals("Item ID")) 
            {
                newValue = newValue.trim(); // Trim the new value

                // Find the Item in inventoryData by Item ID
                InventoryData matchingItem = null;
                for (InventoryData item : inventoryData) 
                {
                    if (item.getItemID().equalsIgnoreCase(newValue)) 
                    {
                        matchingItem = item;
                        break;
                    }
                }

                if (matchingItem == null) 
                {
                    JOptionPane.showMessageDialog(null, "Item ID not found!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Ask for Supplier ID as unit price varies by supplier
                String supplierID = JOptionPane.showInputDialog(null, "Enter Supplier ID for " + matchingItem.getItemName() + ":");

                if (supplierID == null || supplierID.isEmpty()) 
                {
                    JOptionPane.showMessageDialog(null, "Supplier ID cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Search for matching Supplier ID and get the Unit Price
                double unitPrice = -1;
                for (SupItemData supItem : supitemData) 
                {
                    if (supItem.getItemID().equalsIgnoreCase(newValue) && supItem.getSupplierID().equalsIgnoreCase(supplierID)) 
                    {
                        unitPrice = supItem.getUnitPrice();
                        break;
                    }
                }

                if (unitPrice == -1) 
                {
                    JOptionPane.showMessageDialog(null, "Supplier ID or Unit Price not found for this Item ID!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Update Item ID, Item Name, Supplier ID, and Unit Price in the table
                tblModel.setValueAt(newValue, rowToEditIndex, table.getColumnModel().getColumnIndex("Item ID"));
                tblModel.setValueAt(matchingItem.getItemName(), rowToEditIndex, table.getColumnModel().getColumnIndex("Item Name"));
                tblModel.setValueAt(unitPrice, rowToEditIndex, table.getColumnModel().getColumnIndex("Unit Price"));

                // Update the SalesItem object
                SalesData itemToUpdate = salesData.get(rowToEditIndex);
                itemToUpdate.setItemID(newValue);  // Update Item ID
                itemToUpdate.setItemName(matchingItem.getItemName());  // Update Item Name
                itemToUpdate.setUnitPrice(unitPrice);  // Update Unit Price

                // Update Total Amount based on Quantity
                int qty = Integer.parseInt(tblModel.getValueAt(rowToEditIndex, table.getColumnModel().getColumnIndex("Quantity")).toString());
                double totalAmount = unitPrice * qty;
                tblModel.setValueAt(totalAmount, rowToEditIndex, table.getColumnModel().getColumnIndex("Total Amount"));
                itemToUpdate.setTotalAmount(totalAmount);
            }

            // Handle Quantity update
            if (colName.equals("Quantity")) 
            {
                int quantity;
                try 
                {
                    quantity = Integer.parseInt(newValue);

                    // Validate quantity is greater than 0
                    if (quantity <= 0) 
                    {
                        JOptionPane.showMessageDialog(null, "Quantity must be greater than 0.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                        return;  // Exit if invalid quantity
                    }
                } catch (NumberFormatException e) 
                {
                    JOptionPane.showMessageDialog(null, "Please enter a valid number for quantity.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                    return;  // Exit if input is not a number
                }

                tblModel.setValueAt(quantity, rowToEditIndex, colToEditIndex);  // Update JTable

                // Fetch Unit Price from the table
                double unitPrice = Double.parseDouble(tblModel.getValueAt(rowToEditIndex, table.getColumnModel().getColumnIndex("Unit Price")).toString());

                // Calculate and update Total Amount
                double totalAmount = unitPrice * quantity;
                tblModel.setValueAt(totalAmount, rowToEditIndex, table.getColumnModel().getColumnIndex("Total Amount"));

                // Update the SalesItem object in salesData
                SalesData itemToUpdate = salesData.get(rowToEditIndex);
                itemToUpdate.setQty(quantity);
                itemToUpdate.setTotalAmount(totalAmount);
            }

            isModified = true;
        } else {
            if (table.getRowCount() == 0) {
                JOptionPane.showMessageDialog(null, "Table is empty", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Please select a cell to edit", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
}

    public void SaveToArray(JTable salesentrytable) {
        salesData.clear();
        DefaultTableModel model = (DefaultTableModel) salesentrytable.getModel();
        
        // Iterate over each row in the table
        for (int row = 0; row < model.getRowCount(); row++) 
        {
            // Retrieve data from each cell in the row
            String date = (String) model.getValueAt(row, 0);
            String salesID = (String) model.getValueAt(row, 1);
            String salesManagerID = (String) model.getValueAt(row, 2);
            String itemID = (String) model.getValueAt(row, 3);
            String itemName = (String) model.getValueAt(row, 4);
            double unitPrice = (Double) model.getValueAt(row, 5);
            int qty = (Integer) model.getValueAt(row, 6);
            double totalAmount = (Double) model.getValueAt(row, 7);

            SalesData newSales = new SalesData(date,salesID,salesManagerID,itemID,itemName,unitPrice,qty,totalAmount);
            salesData.add(newSales);
        }
        // Show success message
        JOptionPane.showMessageDialog(null, "Data saved successfully!");
        
        for(SalesData s: salesData)
        {
            System.out.println(s+"\n");
        }
    }
    
    public void Delete(JTable table) {
        int row = table.getSelectedRow();
        if (row != -1) {
            // Remove the row from the data list
            salesData.remove(row);
            // Update the table model directly by removing the row
            ((DefaultTableModel) table.getModel()).removeRow(row);

            JOptionPane.showMessageDialog(null, "Row deleted successfully!");
        } else {
            JOptionPane.showMessageDialog(null, "Please select a row to delete");
        }
    }

}
