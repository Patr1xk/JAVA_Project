package SmDash;

import Login.FileHandling;
import static Login.FileHandling.requisitionFilePath;
import Login.InventoryData;
import Login.PurchaseData;
import Login.RequisitionData;
import Login.SalesData;
import Login.SupItemData;
import Login.UserData;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Requisition extends javax.swing.JFrame implements FileHandling{
    private ArrayList<InventoryData> inventoryData;
    private ArrayList<SupItemData> supitemData;
    private ArrayList<RequisitionData> requisitionData;
    private ArrayList<PurchaseData> purchaseData;
    private ArrayList<SalesData> salesData;
    private ArrayList<UserData> userData;
    
    public Requisition(ArrayList<InventoryData> inventoryData, ArrayList<SupItemData> supitemData, ArrayList<RequisitionData> requisitionData, ArrayList<PurchaseData> purchaseData, ArrayList<SalesData> salesData, ArrayList<UserData> userData) {
        this.inventoryData = inventoryData;
        this.supitemData = supitemData;
        this.requisitionData = requisitionData;
        this.purchaseData = purchaseData;
        this.salesData= salesData;
        this.userData = userData;
        initComponents();
        
        Show(requisitionData);
       }
    
    public void Show(ArrayList<RequisitionData> requisitionData) {
        DefaultTableModel model = (DefaultTableModel) requisitiontable.getModel();
        model.setRowCount(0); // Clear the existing rows

        // Add rows from the requisitionData array list
        for (RequisitionData item : requisitionData) 
        {
            Object[] row = 
            {
                item.getRequisitionID(),
                item.getRequestDate(),
                item.getSalesManagerID(),
                item.getItemID(),
                item.getItemName(),
                item.getCurrentQty()
            };
            model.addRow(row);
        }
    }
        
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuBar2 = new javax.swing.JMenuBar();
        jMenu3 = new javax.swing.JMenu();
        jMenu4 = new javax.swing.JMenu();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jPanel3 = new javax.swing.JPanel();
        address = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        header1 = new javax.swing.JLabel();
        home = new javax.swing.JButton();
        savebtn = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jScrollPane2 = new javax.swing.JScrollPane();
        requisitiontable = new javax.swing.JTable();
        jSeparator2 = new javax.swing.JSeparator();
        create = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();

        jMenu3.setText("File");
        jMenuBar2.add(jMenu3);

        jMenu4.setText("Edit");
        jMenuBar2.add(jMenu4);

        jMenu1.setText("jMenu1");

        jMenuItem1.setText("jMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jPanel3.setMaximumSize(new java.awt.Dimension(800, 500));
        jPanel3.setMinimumSize(new java.awt.Dimension(800, 500));
        jPanel3.setPreferredSize(new java.awt.Dimension(800, 500));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        address.setFont(new java.awt.Font("Perpetua", 3, 14)); // NOI18N
        jPanel3.add(address, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 40, -1, -1));

        jPanel1.setBackground(new java.awt.Color(51, 51, 41));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 100));

        header1.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        header1.setForeground(new java.awt.Color(255, 255, 255));
        header1.setText("Purchase Requisition");

        home.setBackground(new java.awt.Color(51, 51, 51));
        home.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ImImage/home.jpg"))); // NOI18N
        home.setBorderPainted(false);
        home.setContentAreaFilled(false);
        home.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        home.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                homeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(285, Short.MAX_VALUE)
                .addComponent(header1)
                .addGap(208, 208, 208)
                .addComponent(home, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(home, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(header1))
                .addGap(8, 8, 8))
        );

        jPanel3.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 810, 70));

        savebtn.setText("Save");
        savebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                savebtnActionPerformed(evt);
            }
        });
        jPanel3.add(savebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 80, 70, -1));
        jPanel3.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 250, -1, -1));

        requisitiontable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Rq. ID", "Request Date", "Sales Manager ID", "Item ID", "Item Name", "Current Qty"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(requisitiontable);

        jPanel3.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 780, 370));
        jPanel3.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 106, 780, 10));

        create.setText("Create");
        create.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createActionPerformed(evt);
            }
        });
        jPanel3.add(create, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 80, -1, -1));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jPanel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void savebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_savebtnActionPerformed
        Save(requisitionData, requisitionFilePath);
        JOptionPane.showMessageDialog(null, "Data saved successfully!");

    }//GEN-LAST:event_savebtnActionPerformed
   
    private void createActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createActionPerformed
        DefaultTableModel requisitionTblModel = (DefaultTableModel) requisitiontable.getModel();

        StringBuilder itemList = new StringBuilder("Low Stock Items Not in Requisition:\n");
        boolean hasLowStockItemsNotInRequisition = false;

        for (InventoryData inv : inventoryData) {
            if (inv.getStockLvl().equalsIgnoreCase("Low")) {
                boolean existsInRequisition = false;

                // Check if the item is already in the requisition table
                for (int i = 0; i < requisitionTblModel.getRowCount(); i++) {
                    String itemID = (String) requisitiontable.getValueAt(i, 3);
                    if (itemID.equalsIgnoreCase(inv.getItemID())) {
                        existsInRequisition = true;
                        break;
                    }
                }

                // add to the list if its low
                if (!existsInRequisition) {
                    hasLowStockItemsNotInRequisition = true;
                    itemList.append("Item ID: ").append(inv.getItemID())
                            .append(", Name: ").append(inv.getItemName())
                            .append(", Quantity: ").append(inv.getTotalQty())
                            .append("\n");
                }
            }
        }

        if (hasLowStockItemsNotInRequisition) {
            JOptionPane.showMessageDialog(this, itemList.toString(), "Low Stock Items", JOptionPane.INFORMATION_MESSAGE);

            // Confirm creating a requisition
            int confirm = JOptionPane.showConfirmDialog(this, "Do you want to create a requisition for these items?",
                                                        "Confirm Requisition", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                String smID;
                boolean foundManager = false;
                do {
                    smID = JOptionPane.showInputDialog("Enter Sales Manager ID:", "SM");

                    if (smID == null || smID.trim().isEmpty()) {
                        JOptionPane.showMessageDialog(this, "Sales Manager ID cannot be empty. Please try again.",
                                "Invalid Input", JOptionPane.ERROR_MESSAGE);
                        continue;
                    }
                    smID = smID.trim();
                    foundManager = false;

                    // Verify the Sales Manager ID
                    for (UserData salesmanager : userData) {
                        if (salesmanager.getUserID().equalsIgnoreCase(smID)) {
                            foundManager = true;
                            break;
                        }
                    }

                    if (!foundManager) {
                        JOptionPane.showMessageDialog(this, "Sales Manager ID not found in user database. Please try again.",
                                "Invalid Sales Manager ID", JOptionPane.ERROR_MESSAGE);
                    }
                } while (!foundManager);

                for (InventoryData inv : inventoryData) {
                    if (inv.getStockLvl().equalsIgnoreCase("Low")) {
                        boolean existsInRequisition = false;

                        for (int i = 0; i < requisitionTblModel.getRowCount(); i++) {
                            String itemID = (String) requisitiontable.getValueAt(i, 3);
                            if (itemID.equalsIgnoreCase(inv.getItemID())) {
                                existsInRequisition = true;
                                break;
                            }
                        }

                        if (!existsInRequisition) {
                            String requisitionID = "R" + String.format("%03d", requisitionData.size() + 1);
                            String date = Date_Format.getCurrentDate();

                            RequisitionData requisitionItem = new RequisitionData(requisitionID, date, smID,
                                                                                  inv.getItemID(), inv.getItemName(), inv.getTotalQty());
                            requisitionData.add(requisitionItem);
                        }
                    }
                }

                Show(requisitionData); // Refresh requisition data display
                JOptionPane.showMessageDialog(this, "Requisition created successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "No low stock items are available for requisition.", "Info", JOptionPane.INFORMATION_MESSAGE);
        }    
        
    }//GEN-LAST:event_createActionPerformed

    private void homeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_homeActionPerformed
        SmDashboard dashboard = new SmDashboard(inventoryData, supitemData, requisitionData, purchaseData, salesData, userData);
        dashboard.show();
        this.dispose();
    }//GEN-LAST:event_homeActionPerformed
    
    public static void main(String args[]) {
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new Requisition().setVisible(true);
//            }
//        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel address;
    private javax.swing.JButton create;
    private javax.swing.JLabel header1;
    private javax.swing.JButton home;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTable requisitiontable;
    private javax.swing.JButton savebtn;
    // End of variables declaration//GEN-END:variables
}
