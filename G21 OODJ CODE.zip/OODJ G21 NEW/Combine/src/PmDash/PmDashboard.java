package PmDash;

import Login.InventoryData;
import Login.LoginPage;
import Login.PurchaseData;
import Login.RequisitionData;
import Login.ResetPasswordPage;
import Login.SalesData;
import Login.SupItemData;
import Login.SupplierData;
import Login.UserData;
import java.util.ArrayList;

public class PmDashboard extends javax.swing.JFrame {
    
    private ArrayList<UserData> userData;
    private ArrayList<SalesData> salesData;
    private ArrayList<SupItemData> supItemData;
    private ArrayList<SupplierData> supplierData;
    private ArrayList<PurchaseData> purchaseData;
    private ArrayList<InventoryData> inventoryData;
    private ArrayList<RequisitionData> requisitionData;
    
    public PmDashboard(ArrayList<UserData> userData, ArrayList<SalesData> salesData, ArrayList<InventoryData> inventoryData, ArrayList<SupplierData> supplierData, ArrayList<PurchaseData> purchaseData, ArrayList<RequisitionData> requisitionData, ArrayList<SupItemData> supItemData) {
        this.userData = userData;
        this.salesData = salesData;
        this.inventoryData = inventoryData;
        this.supplierData = supplierData;
        this.purchaseData = purchaseData;
        this.requisitionData = requisitionData;
        this.supItemData = supItemData;
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        btnLogOut = new javax.swing.JButton();
        btn_view_item = new javax.swing.JButton();
        btn_viewSup = new javax.swing.JButton();
        btn_viewReq = new javax.swing.JButton();
        btn_generatePO = new javax.swing.JButton();
        btn_viewPO = new javax.swing.JButton();
        btn_resetPass = new javax.swing.JButton();
        btn_viewItem_2 = new javax.swing.JButton();
        btn_viewSup_2 = new javax.swing.JButton();
        btn_viewReq_2 = new javax.swing.JButton();
        btn_generatePO_2 = new javax.swing.JButton();
        btn_viewPO_2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(204, 204, 204));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Purchase Manager Dashboard");
        jLabel6.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 30, -1, -1));

        btnLogOut.setBackground(new java.awt.Color(51, 51, 51));
        btnLogOut.setIcon(new javax.swing.ImageIcon(getClass().getResource("/LoginImage/logout.png"))); // NOI18N
        btnLogOut.setBorder(null);
        btnLogOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogOutActionPerformed(evt);
            }
        });
        jPanel1.add(btnLogOut, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 0, 96, 90));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 896, 90));

        btn_view_item.setBackground(new java.awt.Color(242, 242, 242));
        btn_view_item.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pmimages/item_icon.jpg"))); // NOI18N
        btn_view_item.setBorderPainted(false);
        btn_view_item.setContentAreaFilled(false);
        btn_view_item.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_view_itemActionPerformed(evt);
            }
        });
        getContentPane().add(btn_view_item, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 118, -1, 147));

        btn_viewSup.setBackground(new java.awt.Color(244, 244, 244));
        btn_viewSup.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pmimages/suppliers_icon.jpg"))); // NOI18N
        btn_viewSup.setBorder(null);
        btn_viewSup.setContentAreaFilled(false);
        btn_viewSup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_viewSupActionPerformed(evt);
            }
        });
        getContentPane().add(btn_viewSup, new org.netbeans.lib.awtextra.AbsoluteConstraints(386, 118, -1, 147));

        btn_viewReq.setBackground(new java.awt.Color(244, 244, 244));
        btn_viewReq.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pmimages/requisition_icon.jpg"))); // NOI18N
        btn_viewReq.setBorder(null);
        btn_viewReq.setContentAreaFilled(false);
        btn_viewReq.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_viewReqActionPerformed(evt);
            }
        });
        getContentPane().add(btn_viewReq, new org.netbeans.lib.awtextra.AbsoluteConstraints(646, 118, -1, 147));

        btn_generatePO.setBackground(new java.awt.Color(244, 244, 244));
        btn_generatePO.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pmimages/PO_icon.jpg"))); // NOI18N
        btn_generatePO.setBorder(null);
        btn_generatePO.setContentAreaFilled(false);
        btn_generatePO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_generatePOActionPerformed(evt);
            }
        });
        getContentPane().add(btn_generatePO, new org.netbeans.lib.awtextra.AbsoluteConstraints(195, 350, 165, 133));

        btn_viewPO.setBackground(new java.awt.Color(244, 244, 244));
        btn_viewPO.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pmimages/purchaser_icon.jpg"))); // NOI18N
        btn_viewPO.setBorder(null);
        btn_viewPO.setContentAreaFilled(false);
        btn_viewPO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_viewPOActionPerformed(evt);
            }
        });
        getContentPane().add(btn_viewPO, new org.netbeans.lib.awtextra.AbsoluteConstraints(555, 355, 146, 128));

        btn_resetPass.setBackground(new java.awt.Color(242, 242, 242));
        btn_resetPass.setText("Reset Password");
        btn_resetPass.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        btn_resetPass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_resetPassActionPerformed(evt);
            }
        });
        getContentPane().add(btn_resetPass, new org.netbeans.lib.awtextra.AbsoluteConstraints(769, 516, 121, 33));

        btn_viewItem_2.setBackground(new java.awt.Color(242, 242, 242));
        btn_viewItem_2.setFont(new java.awt.Font("Arial Hebrew", 0, 14)); // NOI18N
        btn_viewItem_2.setText("View Items List");
        btn_viewItem_2.setBorder(null);
        btn_viewItem_2.setContentAreaFilled(false);
        btn_viewItem_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_viewItem_2ActionPerformed(evt);
            }
        });
        getContentPane().add(btn_viewItem_2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 271, 136, -1));

        btn_viewSup_2.setBackground(new java.awt.Color(242, 242, 242));
        btn_viewSup_2.setFont(new java.awt.Font("Arial Hebrew", 0, 14)); // NOI18N
        btn_viewSup_2.setText("View Suppliers List");
        btn_viewSup_2.setBorder(null);
        btn_viewSup_2.setContentAreaFilled(false);
        getContentPane().add(btn_viewSup_2, new org.netbeans.lib.awtextra.AbsoluteConstraints(386, 271, 130, -1));

        btn_viewReq_2.setBackground(new java.awt.Color(242, 242, 242));
        btn_viewReq_2.setFont(new java.awt.Font("Arial Hebrew", 0, 14)); // NOI18N
        btn_viewReq_2.setText("View Requisition");
        btn_viewReq_2.setBorder(null);
        btn_viewReq_2.setContentAreaFilled(false);
        getContentPane().add(btn_viewReq_2, new org.netbeans.lib.awtextra.AbsoluteConstraints(646, 271, 130, -1));

        btn_generatePO_2.setBackground(new java.awt.Color(242, 242, 242));
        btn_generatePO_2.setFont(new java.awt.Font("Arial Hebrew", 0, 14)); // NOI18N
        btn_generatePO_2.setText("Generate Purchase Order");
        btn_generatePO_2.setBorder(null);
        btn_generatePO_2.setContentAreaFilled(false);
        getContentPane().add(btn_generatePO_2, new org.netbeans.lib.awtextra.AbsoluteConstraints(195, 489, -1, -1));

        btn_viewPO_2.setBackground(new java.awt.Color(242, 242, 242));
        btn_viewPO_2.setFont(new java.awt.Font("Arial Hebrew", 0, 14)); // NOI18N
        btn_viewPO_2.setText("View Purchaser Orders");
        btn_viewPO_2.setBorder(null);
        btn_viewPO_2.setContentAreaFilled(false);
        getContentPane().add(btn_viewPO_2, new org.netbeans.lib.awtextra.AbsoluteConstraints(555, 490, -1, 16));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_view_itemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_view_itemActionPerformed
        itemsList itemlist = new itemsList(userData,salesData,inventoryData,supplierData,purchaseData,requisitionData,supItemData);        
        itemlist.setVisible(true); 
        this.dispose();
    }//GEN-LAST:event_btn_view_itemActionPerformed

    private void btn_viewSupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_viewSupActionPerformed
        suppliersList supplier = new suppliersList(userData,salesData,inventoryData,supplierData,purchaseData,requisitionData,supItemData);
        
        supplier.setVisible(true); 
        this.dispose();
    }//GEN-LAST:event_btn_viewSupActionPerformed

    private void btn_viewReqActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_viewReqActionPerformed
        requisitionsList Requisition = new requisitionsList(userData,salesData,inventoryData,supplierData,purchaseData,requisitionData,supItemData);
        
        Requisition.setVisible(true); 
        this.dispose();
    }//GEN-LAST:event_btn_viewReqActionPerformed

    private void btn_generatePOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_generatePOActionPerformed
        generatePO po = new generatePO(userData,salesData,inventoryData,supplierData,purchaseData,requisitionData,supItemData);
        
        po.setVisible(true); 
        this.dispose();
    }//GEN-LAST:event_btn_generatePOActionPerformed

    private void btn_viewPOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_viewPOActionPerformed
        viewPO viewpo = new viewPO(userData,salesData,inventoryData,supplierData,purchaseData,requisitionData,supItemData);
        
        viewpo.setVisible(true); 
        this.dispose();
    }//GEN-LAST:event_btn_viewPOActionPerformed

    private void btn_viewItem_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_viewItem_2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_viewItem_2ActionPerformed

    private void btnLogOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogOutActionPerformed
        // TODO add your handling code here:
        LoginPage loginPage = new LoginPage();
        loginPage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnLogOutActionPerformed

    private void btn_resetPassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_resetPassActionPerformed
        // TODO add your handling code here:
        ResetPasswordPage resetPass = new ResetPasswordPage(userData);
        resetPass.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btn_resetPassActionPerformed

    
//    public static void main(String args[]) {
//        /* Set the Nimbus look and feel */
//        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
//        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
//         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
//         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(PmDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(PmDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(PmDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(PmDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
//        //</editor-fold>
//        //</editor-fold>
//
//        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new PmDashboard().setVisible(true);
//            }
//            
//        });
//    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnLogOut;
    private javax.swing.JButton btn_generatePO;
    private javax.swing.JButton btn_generatePO_2;
    private javax.swing.JButton btn_resetPass;
    private javax.swing.JButton btn_viewItem_2;
    private javax.swing.JButton btn_viewPO;
    private javax.swing.JButton btn_viewPO_2;
    private javax.swing.JButton btn_viewReq;
    private javax.swing.JButton btn_viewReq_2;
    private javax.swing.JButton btn_viewSup;
    private javax.swing.JButton btn_viewSup_2;
    private javax.swing.JButton btn_view_item;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
