package PmDash;

import static Login.FileHandling.requisitionFilePath;
import Login.FileHandling;
import Login.InventoryData;
import Login.PurchaseData;
import Login.RequisitionData;
import Login.SalesData;
import Login.SupItemData;
import Login.SupplierData;
import Login.UserData;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class generatePO extends javax.swing.JFrame implements FileHandling{
        
    private ArrayList<UserData> userData;
    private ArrayList<SalesData> salesData;
    private ArrayList<SupItemData> supItemData;
    private ArrayList<SupplierData> supplierData;
    private ArrayList<PurchaseData> purchaseData;
    private ArrayList<InventoryData> inventoryData;
    private ArrayList<RequisitionData> requisitionData;
        
    public generatePO(ArrayList<UserData> userData, ArrayList<SalesData> salesData, ArrayList<InventoryData> inventoryData, ArrayList<SupplierData> supplierData, ArrayList<PurchaseData> purchaseData, ArrayList<RequisitionData> requisitionData, ArrayList<SupItemData> supItemData){
        this.userData = userData;
        this.salesData = salesData;
        this.inventoryData = inventoryData;
        this.supplierData = supplierData;
        this.purchaseData = purchaseData;
        this.requisitionData = requisitionData;
        this.supItemData = supItemData;
        
        initComponents();
        
        ShowInTable(requisitionTbl);
        ShowInTable2(purchaseTbl);        
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        lblRequisitionTable = new javax.swing.JLabel();
        lblPOtable = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        purchaseTbl = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        requisitionTbl = new javax.swing.JTable();
        buttonSave = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtpoid = new javax.swing.JTextField();
        txtpmid = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        combostatus = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        combosupplierid = new javax.swing.JComboBox<>();
        validateprice = new javax.swing.JLabel();
        validateqty = new javax.swing.JLabel();
        validatepmid = new javax.swing.JLabel();
        txtunitprice = new javax.swing.JTextField();
        txtquantity = new javax.swing.JTextField();
        txttotalprice = new javax.swing.JTextField();
        buttonadd = new javax.swing.JButton();
        buttonDelete = new javax.swing.JButton();
        buttonUpdate = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        itemid = new javax.swing.JLabel();
        lblrequisitionid = new javax.swing.JLabel();
        lblitemid = new javax.swing.JLabel();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        btnclear = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(800, 500));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 80));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Generate Purchase Order");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 20, -1, 59));

        jButton1.setBackground(new java.awt.Color(51, 51, 51));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pmimages/home.jpg"))); // NOI18N
        jButton1.setBorder(null);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 20, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1170, 92));

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(1447, 309, -1, -1));
        jPanel2.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(1601, 321, -1, -1));
        jPanel2.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(1607, 59, -1, -1));
        jPanel2.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(1607, 142, -1, -1));
        jPanel2.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(1607, 401, -1, -1));

        lblRequisitionTable.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        lblRequisitionTable.setText("List of Requisitions");
        jPanel2.add(lblRequisitionTable, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, -1));

        lblPOtable.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        lblPOtable.setText("List of Purchase Orders");
        jPanel2.add(lblPOtable, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, -1, -1));

        purchaseTbl.setBackground(new java.awt.Color(240, 240, 240));
        purchaseTbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "PO ID", "PO Date", "Req ID", "PM ID", "Supplier ID", "Item ID", "Unit Price (RM)", "Qty", "Total Price (RM)", "PO Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        purchaseTbl.setSelectionBackground(new java.awt.Color(0, 102, 153));
        purchaseTbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                purchaseTblMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(purchaseTbl);

        jPanel2.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, 740, 200));

        requisitionTbl.setBackground(new java.awt.Color(240, 240, 240));
        requisitionTbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Requisition ID", "Request Date", "SM ID", "Item ID", "Item Name", "Current Qty"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        requisitionTbl.setSelectionBackground(new java.awt.Color(0, 102, 153));
        requisitionTbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                requisitionTblMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(requisitionTbl);

        jPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 740, 200));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 770, 480));

        buttonSave.setBackground(new java.awt.Color(0, 153, 0));
        buttonSave.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        buttonSave.setForeground(new java.awt.Color(255, 255, 255));
        buttonSave.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pmimages/save_icon.jpg"))); // NOI18N
        buttonSave.setText("  SAVE     ");
        buttonSave.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        buttonSave.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                buttonSaveMouseClicked(evt);
            }
        });
        getContentPane().add(buttonSave, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 110, 106, -1));

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 153, -1, 650));

        jPanel4.setBackground(new java.awt.Color(240, 240, 240));
        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setText("Supplier ID:");
        jPanel4.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 260, -1, -1));

        jLabel2.setText("PO ID:");
        jPanel4.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(38, 129, 76, -1));

        jLabel4.setText("PM ID:");
        jPanel4.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 212, 60, -1));

        txtpoid.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtpoidMouseClicked(evt);
            }
        });
        jPanel4.add(txtpoid, new org.netbeans.lib.awtextra.AbsoluteConstraints(153, 126, 92, -1));

        txtpmid.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtpmidFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtpmidFocusLost(evt);
            }
        });
        jPanel4.add(txtpmid, new org.netbeans.lib.awtextra.AbsoluteConstraints(151, 209, 92, -1));

        jLabel11.setText("PO Status:");
        jPanel4.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 435, 102, -1));

        combostatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pending", "Approved" }));
        jPanel4.add(combostatus, new org.netbeans.lib.awtextra.AbsoluteConstraints(154, 432, 96, -1));

        jLabel3.setText("PO Date:");
        jPanel4.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 171, 60, 18));

        jLabel12.setText("Total Price (RM):");
        jPanel4.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 395, 102, -1));

        jLabel9.setText("Unit Price (RM): ");
        jPanel4.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 305, 95, -1));

        jLabel10.setText("Quantity: ");
        jPanel4.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(38, 350, 101, -1));

        combosupplierid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combosupplieridActionPerformed(evt);
            }
        });
        jPanel4.add(combosupplierid, new org.netbeans.lib.awtextra.AbsoluteConstraints(151, 257, 92, -1));

        validateprice.setForeground(new java.awt.Color(255, 0, 51));
        jPanel4.add(validateprice, new org.netbeans.lib.awtextra.AbsoluteConstraints(267, 302, 88, 23));

        validateqty.setForeground(new java.awt.Color(255, 0, 51));
        jPanel4.add(validateqty, new org.netbeans.lib.awtextra.AbsoluteConstraints(267, 347, 88, 23));

        validatepmid.setForeground(new java.awt.Color(255, 0, 51));
        jPanel4.add(validatepmid, new org.netbeans.lib.awtextra.AbsoluteConstraints(267, 209, 88, 23));

        txtunitprice.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtunitpriceKeyPressed(evt);
            }
        });
        jPanel4.add(txtunitprice, new org.netbeans.lib.awtextra.AbsoluteConstraints(151, 302, 98, -1));

        txtquantity.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtquantityKeyPressed(evt);
            }
        });
        jPanel4.add(txtquantity, new org.netbeans.lib.awtextra.AbsoluteConstraints(151, 347, 98, -1));

        txttotalprice.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txttotalpriceMouseClicked(evt);
            }
        });
        jPanel4.add(txttotalprice, new org.netbeans.lib.awtextra.AbsoluteConstraints(154, 392, 96, -1));

        buttonadd.setBackground(new java.awt.Color(0, 153, 0));
        buttonadd.setFont(new java.awt.Font("Arial Hebrew", 1, 13)); // NOI18N
        buttonadd.setForeground(new java.awt.Color(255, 255, 255));
        buttonadd.setText("ADD");
        buttonadd.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        buttonadd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonaddActionPerformed(evt);
            }
        });
        jPanel4.add(buttonadd, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 470, 95, 28));

        buttonDelete.setBackground(new java.awt.Color(204, 0, 0));
        buttonDelete.setFont(new java.awt.Font("Arial Hebrew", 1, 13)); // NOI18N
        buttonDelete.setForeground(new java.awt.Color(255, 255, 255));
        buttonDelete.setText("DELETE");
        buttonDelete.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        buttonDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonDeleteActionPerformed(evt);
            }
        });
        jPanel4.add(buttonDelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 470, 95, 28));

        buttonUpdate.setBackground(new java.awt.Color(0, 0, 204));
        buttonUpdate.setFont(new java.awt.Font("Arial Hebrew", 1, 13)); // NOI18N
        buttonUpdate.setForeground(new java.awt.Color(255, 255, 255));
        buttonUpdate.setText("UPDATE");
        buttonUpdate.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        buttonUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonUpdateActionPerformed(evt);
            }
        });
        jPanel4.add(buttonUpdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 470, 95, 28));

        jPanel5.setBackground(new java.awt.Color(0, 68, 137));
        jPanel5.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel14.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Requisition ID:");
        jPanel5.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 25, -1, -1));

        itemid.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        itemid.setForeground(new java.awt.Color(255, 255, 255));
        itemid.setText("Item ID:");
        jPanel5.add(itemid, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 55, 91, -1));

        lblrequisitionid.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        lblrequisitionid.setForeground(new java.awt.Color(255, 255, 255));
        jPanel5.add(lblrequisitionid, new org.netbeans.lib.awtextra.AbsoluteConstraints(136, 26, 220, 17));

        lblitemid.setForeground(new java.awt.Color(255, 255, 255));
        jPanel5.add(lblitemid, new org.netbeans.lib.awtextra.AbsoluteConstraints(136, 55, 100, 18));

        jPanel4.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 100));
        jPanel4.add(jDateChooser1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 170, 110, -1));

        btnclear.setBackground(new java.awt.Color(218, 218, 218));
        btnclear.setFont(new java.awt.Font("Helvetica Neue", 1, 12)); // NOI18N
        btnclear.setText("CLEAR");
        btnclear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnclearActionPerformed(evt);
            }
        });
        jPanel4.add(btnclear, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 510, 327, 28));

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 110, -1, 570));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void buttonaddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonaddActionPerformed
       
        String poid = txtpoid.getText().trim();
        Date podate = jDateChooser1.getDate();
        String requisitionid = lblrequisitionid.getText().trim();
        String pmid = txtpmid.getText().trim();
        String supplierID = (String) combosupplierid.getSelectedItem();
        String itemID = (String) lblitemid.getText().trim();
        String price = txtunitprice.getText().trim();
        String qty = txtquantity.getText().trim();
        String totalprice = txttotalprice.getText().trim();
        String postatus = (String) combostatus.getSelectedItem();
               
        String formattedPoDate = "";
            
        if (podate != null) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");  // Adjust date format as needed
            formattedPoDate = dateFormat.format(podate);  // Convert date to string
        } else {
            // Handle case where no date is selected, if necessary
            formattedPoDate = "No date selected";
        }

        // Check if any of the required data is empty
        if (podate == null || requisitionid.equals("")||poid.equals("") || formattedPoDate.equals("") || pmid.equals("") || 
            supplierID.isEmpty() || price.equals("") || 
            qty.equals("") || totalprice.equals("") || postatus == null || itemID.equals("") ) {

            JOptionPane.showMessageDialog(this, "Please Enter All Data!", "Warning", JOptionPane.WARNING_MESSAGE);

        } else {
            if ("pending".equalsIgnoreCase(postatus)){
                if (purchaseData == null) {
                    purchaseData = new ArrayList<>();
                }

                PurchaseData newPO = new PurchaseData(poid,formattedPoDate,requisitionid,pmid,supplierID,itemID,Double.valueOf(price),
                                                      Integer.valueOf(qty),Double.valueOf(totalprice),postatus);

                purchaseData.add(newPO);

                JOptionPane.showMessageDialog(this, "Data added successfully!");            

                // Increment the counter for the next POID
                poidCounter++;

                ShowInTable2(purchaseTbl);
                clearData();           
            }  else {
                if (purchaseData == null) {
                    purchaseData = new ArrayList<>();
                }
                PurchaseData newPO = new PurchaseData(poid,formattedPoDate,requisitionid,pmid,supplierID,itemID,Double.parseDouble(price),
                                                  Integer.parseInt(qty),Double.parseDouble(totalprice),postatus);
                purchaseData.add(newPO);
                
                JOptionPane.showMessageDialog(this, "Data added successfully!");            

                // Increment the counter for the next POID
                poidCounter++;
                
                ShowInTable2(purchaseTbl);
                
                try {
                    deleteApprovedRequisition();
                } catch (IOException ex){
                    Logger.getLogger(generatePO.class.getName()).log(Level.SEVERE, null, ex);
                }
                clearData();
            }
        }     
    }//GEN-LAST:event_buttonaddActionPerformed

    private void buttonDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonDeleteActionPerformed

        DefaultTableModel tblModel = (DefaultTableModel)purchaseTbl.getModel();

        if(purchaseTbl.getSelectedRowCount() == 1){
            int selectedRow = purchaseTbl.getSelectedRow();
            tblModel.removeRow(selectedRow);

            purchaseData.remove(selectedRow);
            
            for(int i = 0; i < tblModel.getRowCount(); i++){
                String poid = (String) tblModel.getValueAt(i, 0).toString();
                String podate = (String) tblModel.getValueAt(i, 1).toString();
                String requisitionid = (String) tblModel.getValueAt(i, 2).toString();
                String pmid = (String) tblModel.getValueAt(i, 3).toString();
                String supplierid = (String) tblModel.getValueAt(i, 4).toString();
                String itemID = (String) tblModel.getValueAt(i, 5).toString();
                String unitprice = (String) tblModel.getValueAt(i, 6).toString();
                String quantity = (String) tblModel.getValueAt(i, 7).toString();
                String total = (String) tblModel.getValueAt(i, 8).toString();
                String postatus = (String) tblModel.getValueAt(i, 9).toString();

                PurchaseData data = new PurchaseData(poid,podate,requisitionid,pmid,supplierid,itemID,Double.parseDouble(unitprice),
                                                      Integer.parseInt(quantity),Double.parseDouble(total),postatus);
                purchaseData.add(data);

            }

            JOptionPane.showMessageDialog(this, "Row deleted successfully!");
            clearData();
            
        } else {
            JOptionPane.showMessageDialog(this, "Please select a single row to delete.");  
        }   
    }//GEN-LAST:event_buttonDeleteActionPerformed

    private void buttonUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonUpdateActionPerformed
       
        DefaultTableModel tblModel = (DefaultTableModel) purchaseTbl.getModel();
       
        if(purchaseTbl.getSelectedRowCount()==1){
            String requisitionid = lblrequisitionid.getText();
            String poid = txtpoid.getText();  
            String pmid = txtpmid.getText();
            String supplierid = (String) combosupplierid.getSelectedItem();
            String itemID = lblitemid.getText();
            String unitprice = txtunitprice.getText();
            String quantity = txtquantity.getText();
            String totalprice = txttotalprice.getText();
            String postatus = (String) combostatus.getSelectedItem();
            String formattedPoDate = "";
            
            Date podate = jDateChooser1.getDate();
            if (podate != null) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");  // Adjust date format as needed
                formattedPoDate = dateFormat.format(podate);  // Convert date to string
            }

            tblModel.setValueAt(poid,purchaseTbl.getSelectedRow(),0);
            tblModel.setValueAt(formattedPoDate,purchaseTbl.getSelectedRow(),1);
            tblModel.setValueAt(requisitionid,purchaseTbl.getSelectedRow(),2);
            tblModel.setValueAt(pmid,purchaseTbl.getSelectedRow(),3);
            tblModel.setValueAt(supplierid,purchaseTbl.getSelectedRow(),4);
            tblModel.setValueAt(itemID,purchaseTbl.getSelectedRow(),5);
            tblModel.setValueAt(unitprice,purchaseTbl.getSelectedRow(),6);
            tblModel.setValueAt(quantity,purchaseTbl.getSelectedRow(),7);
            tblModel.setValueAt(totalprice,purchaseTbl.getSelectedRow(),8);
            tblModel.setValueAt(postatus,purchaseTbl.getSelectedRow(),9);            
            
            JOptionPane.showMessageDialog(this, "Update Sucessfully!"); 
            txtpoid.setEnabled(true);
            
            if("approved".equalsIgnoreCase(postatus)){
                
                String requisitionID = lblrequisitionid.getText().trim();

                Iterator<RequisitionData> iterator = requisitionData.iterator();
                while (iterator.hasNext()) {
                    RequisitionData reqData = iterator.next();

                    // Check if requisitionID matches
                    if (reqData.getRequisitionID().equals(requisitionID)) { // Requisition ID should be at index 0 in reqData array
                        iterator.remove(); // Remove the matching requisition
                        break; // Exit the iterator after deleting the matching requisition
                    }
                    
                }            
                ShowInTable(requisitionTbl);

                try {
                    saveToRequisitionArray(requisitionTbl);
                } catch (IOException ex) {
                    Logger.getLogger(generatePO.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
    
            
        } else{
            
            if(purchaseTbl.getRowCount()==0){
                JOptionPane.showMessageDialog(this,"Table is Empty");
            } else {
                JOptionPane.showMessageDialog(this,"Please select single row");
            }
        }
        
        clearData();  
        
        purchaseData.clear();
        for(int i = 0; i < tblModel.getRowCount(); i++){
                                  
            String poid = (String) tblModel.getValueAt(i, 0).toString();
            String podate = (String) tblModel.getValueAt(i, 1).toString();
            String requisitionid = (String) tblModel.getValueAt(i, 2).toString();
            String pmid = (String) tblModel.getValueAt(i, 3).toString();
            String supplierid = (String) tblModel.getValueAt(i, 4).toString();
            String itemID = (String) tblModel.getValueAt(i, 5).toString();
            String unitprice = (String) tblModel.getValueAt(i, 6).toString();          
            String quantity = (String) tblModel.getValueAt(i, 7).toString();
            String total = (String) tblModel.getValueAt(i, 8).toString();
            String postatus = (String) tblModel.getValueAt(i, 9).toString();
            
            PurchaseData data = new PurchaseData(poid,podate,requisitionid,pmid,supplierid,itemID,Double.valueOf(unitprice),
                                                      Integer.valueOf(quantity),Double.valueOf(total),postatus);

            purchaseData.add(data);
        }
    }//GEN-LAST:event_buttonUpdateActionPerformed
   
    private void txtpoidMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtpoidMouseClicked
        String poid = String.format("P%03d", poidCounter);

        txtpoid.setText(poid);        
        
    }//GEN-LAST:event_txtpoidMouseClicked

    private void txtpmidFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtpmidFocusLost
        String pmid = txtpmid.getText().trim().toUpperCase();
        boolean foundpmid = false;
        
        for (UserData user : userData) {
            if (pmid.equals(user.getUserID().toUpperCase())) { 
                foundpmid = true;
                txtpmid.setText(pmid.toUpperCase());
                validatepmid.setText(""); 
                break;
            }
        }

        if (!foundpmid) {
            validatepmid.setText("Invalid ID");
            txtpmid.setText("");
        }
    }//GEN-LAST:event_txtpmidFocusLost

    private void txtpmidFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtpmidFocusGained
        if (txtpmid.getText().trim().isEmpty()) {
            txtpmid.setText("PM"); 
            txtpmid.setCaretPosition(txtpmid.getText().length());
        }
    }//GEN-LAST:event_txtpmidFocusGained

    private void buttonSaveMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonSaveMouseClicked
        try {
            saveToPOFile(purchaseTbl);
             JOptionPane.showMessageDialog(this, "Data saved successfully!");
            //saveToRequisitionFile(jTable1);
        } catch (IOException e) {
           e.printStackTrace();        
        }
    }//GEN-LAST:event_buttonSaveMouseClicked

    private void combosupplieridActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combosupplieridActionPerformed
        
        if (isComboInitializing || combosupplierid.getSelectedIndex() == 0) {
            return;
        }
        
        String requisitionId = lblrequisitionid.getText().trim();
        String itemId = null;
        int selectedIndex = combosupplierid.getSelectedIndex();
    
        // Proceed if a valid supplier is selected
        if (selectedIndex > 0) {
            // Get the supplier name from the selected supplier's details
            String supplierId = combosupplierid.getSelectedItem().toString();
            SupplierData selectedSupplier = supplierData.get(selectedIndex - 1);            
            
            // Find the item ID linked to the requisition ID
            for (RequisitionData req : requisitionData) {
                if (req.getRequisitionID().equals(requisitionId)) {
                    itemId = req.getItemID(); 
                    break;
                }
            }
            
            // If item ID is found, check for matching supplier ID in item array
            if (itemId != null) {
                for (SupItemData sid : supItemData) {
                    if (sid.getItemID().equals(itemId) && sid.getSupplierID().equals(supplierId)) { // Check both item and supplier ID
                        String unitPrice = String.valueOf(sid.getUnitPrice()); // Assuming unit price is at index 4
                        txtunitprice.setText(unitPrice);
                        break;
                    }
                }
            }
        }
    }//GEN-LAST:event_combosupplieridActionPerformed

    private void txtunitpriceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtunitpriceKeyPressed
        char c = evt.getKeyChar();
        
        if(Character.isLetter(c) || c == '.' || c == ',' || c == '/'){
//          cannot enter letters in textfield
            txtunitprice.setEditable(false);
            validateprice.setText("Invalid number");
        } else {
            txtunitprice.setEditable(true);
            validateprice.setText("");
        }
    }//GEN-LAST:event_txtunitpriceKeyPressed

    private void txtquantityKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtquantityKeyPressed
        char c = evt.getKeyChar();
        
        if(Character.isLetter(c) || c == '.' || c == ',' || c == '/'){
//          cannot enter letters in textfield
            txtquantity.setEditable(false);
            validateqty.setText("Invalid number");
        } else {
            txtquantity.setEditable(true);
            validateqty.setText("");
        }
    }//GEN-LAST:event_txtquantityKeyPressed

    private void txttotalpriceMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txttotalpriceMouseClicked
        String unitprice = txtunitprice.getText();
        String quantity = txtquantity.getText();
        
        float unitPrice = Float.parseFloat(unitprice);
        int qty = Integer.parseInt(quantity);
        
        float total = unitPrice*qty;
        txttotalprice.setText(String.valueOf(total));

    }//GEN-LAST:event_txttotalpriceMouseClicked

    private void btnclearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnclearActionPerformed
        clearData();
        purchaseTbl.clearSelection();
        requisitionTbl.clearSelection();
    }//GEN-LAST:event_btnclearActionPerformed

    private void purchaseTblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_purchaseTblMouseClicked
        DefaultTableModel tblModel = (DefaultTableModel)purchaseTbl.getModel();
        
        for (SupplierData supplierData : supplierData) {
            combosupplierid.addItem(supplierData.getSupplierID());
        }

        String poid = tblModel.getValueAt(purchaseTbl.getSelectedRow(), 0).toString();
        String podate = tblModel.getValueAt(purchaseTbl.getSelectedRow(), 1).toString();
        String requisitionid = tblModel.getValueAt(purchaseTbl.getSelectedRow(), 2).toString();
        String pmid = tblModel.getValueAt(purchaseTbl.getSelectedRow(), 3).toString();
        String supplierid = tblModel.getValueAt(purchaseTbl.getSelectedRow(), 4).toString();
        String itemID = tblModel.getValueAt(purchaseTbl.getSelectedRow(), 5).toString();
        String unitprice = tblModel.getValueAt(purchaseTbl.getSelectedRow(), 6).toString();
        String quantity = tblModel.getValueAt(purchaseTbl.getSelectedRow(), 7).toString();
        String total = tblModel.getValueAt(purchaseTbl.getSelectedRow(), 8).toString();
        String postatus = tblModel.getValueAt(purchaseTbl.getSelectedRow(), 9).toString();
 
        lblrequisitionid.setText(requisitionid);
        lblitemid.setText(itemID);
        txtpoid.setText(poid);

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date date = sdf.parse(podate);
            jDateChooser1.setDate(date);
        } catch (ParseException e) {
            e.printStackTrace(); // Handle exception if date parsing fails
        }

        txtpmid.setText(pmid);
        combosupplierid.setSelectedItem(supplierid);
        String supplierName = getSupplierName(supplierid);
        txtunitprice.setText(unitprice);
        txtquantity.setText(quantity);
        txttotalprice.setText(total);
        combostatus.setSelectedItem(postatus);
        
        txtpoid.setEnabled(false);
        jDateChooser1.setEnabled(false);
        combosupplierid.setEnabled(false);
        txtunitprice.setEnabled(false);
        
    }//GEN-LAST:event_purchaseTblMouseClicked

    private void requisitionTblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_requisitionTblMouseClicked
        DefaultTableModel tblModel = (DefaultTableModel) requisitionTbl.getModel();
        String requisitionid = tblModel.getValueAt(requisitionTbl.getSelectedRow(), 0).toString();
        String itemID = tblModel.getValueAt(requisitionTbl.getSelectedRow(), 3).toString();

        // Set labels with requisition ID and item ID
        lblrequisitionid.setText(requisitionid);
        lblitemid.setText(itemID);

        // Clear supplier name and unit price fields
        txtunitprice.setText("");

        // Initialize supplier combo box
        isComboInitializing = true;
        combosupplierid.removeAllItems();
        
        if(!itemID.isEmpty()){
            combosupplierid.addItem("Select");
            // Add supplier data to combo box
            for (SupItemData supItem : supItemData) {
                if(supItem.getItemID().equals(itemID)){
                    String supplierId = supItem.getSupplierID();
                    combosupplierid.addItem(supplierId);
                }
            }
        } else {
            combosupplierid.addItem("No suppliers available.");
        }
    
        // Set default selection
        combosupplierid.setSelectedIndex(0);
        isComboInitializing = false;
    }//GEN-LAST:event_requisitionTblMouseClicked

    private void txtpmidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtpmidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtpmidActionPerformed

    private void combostatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combostatusActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_combostatusActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        PmDashboard dashboardFrame = new PmDashboard(userData,salesData,inventoryData,supplierData,purchaseData,requisitionData,supItemData);
        dashboardFrame.setVisible(true);

        // Close the current itemsList frame
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed
   
    public void ShowInTable(JTable jTable1)
    {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0); // Clear existing rows
        
        // Populate table with suppliersList data
        for (RequisitionData req : requisitionData) {
            model.addRow(new Object[] {
            req.getRequisitionID(),
            req.getRequestDate(),
            req.getSalesManagerID(),
            req.getItemID(),
            req.getItemName(),
            req.getCurrentQty() });      
        }
        
    }
        
    
    public void ShowInTable2(JTable jTable2)
    {
        DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
        model.setRowCount(0); // Clear existing rows
        
        // Populate table with suppliersList data
        for (PurchaseData podata : purchaseData) {
            model.addRow(new Object[] {
            podata.getPoID(),
            podata.getDate(),
            podata.getRequisitionID(),
            podata.getPmID(),
            podata.getSupplierID(),
            podata.getItemID(),
            podata.getUnitPrice(),
            podata.getQuantity(),
            podata.getTotalPrice(),
            podata.getStatus()
            });
        }
    }
        
    private void saveToPOFile(JTable jTable2) throws IOException {
        DefaultTableModel tblModel = (DefaultTableModel) jTable2.getModel();
        purchaseData.clear();
        
        for(int i = 0; i < tblModel.getRowCount(); i++){
            String poid = (String) tblModel.getValueAt(i, 0).toString();
            String podate = (String) tblModel.getValueAt(i, 1).toString();
            String requisitionid = (String) tblModel.getValueAt(i, 2).toString();
            String pmid = (String) tblModel.getValueAt(i, 3).toString();
            String supplierid = (String) tblModel.getValueAt(i, 4).toString();
            String itemID = (String) tblModel.getValueAt(i, 5).toString();
            String unitprice = (String) tblModel.getValueAt(i, 6).toString();          
            String quantity = (String) tblModel.getValueAt(i, 7).toString();
            String total = (String) tblModel.getValueAt(i, 8).toString();
            String postatus = (String) tblModel.getValueAt(i, 9).toString();
            
            PurchaseData data = new PurchaseData(poid,podate,requisitionid,pmid,supplierid,itemID,Double.valueOf(unitprice),
                                                      Integer.valueOf(quantity),Double.valueOf(total),postatus);
  
            purchaseData.add(data);
            
        }
        
        Save(purchaseData, purchaseFilePath);
    }
    
    private void saveToRequisitionArray(JTable jTable1) throws IOException {
        DefaultTableModel tblModel = (DefaultTableModel) jTable1.getModel();
        requisitionData.clear();
        
        for(int i = 0; i < tblModel.getRowCount(); i++){
            String requisitionid = (String) tblModel.getValueAt(i, 0);
            String requisitiondate = (String) tblModel.getValueAt(i, 1);
            String smid = (String) tblModel.getValueAt(i, 2);
            String itemID = (String) tblModel.getValueAt(i, 3);
            String itemname = (String) tblModel.getValueAt(i, 4);
            int currentqty = (Integer) tblModel.getValueAt(i, 5);
            
            System.out.println(currentqty);
            
            RequisitionData data = new RequisitionData(requisitionid, requisitiondate, smid, itemID, itemname, currentqty);
            requisitionData.add(data);
            
        }
        
        Save(requisitionData, requisitionFilePath);
    }
    
    private void clearData(){
        txtpoid.setText("");
        jDateChooser1.setDate(null);
        txtpmid.setText("");
        combosupplierid.removeAllItems();
        txtunitprice.setText("");
        txtquantity.setText("");
        txttotalprice.setText("");
        combostatus.setSelectedIndex(-1);
        lblrequisitionid.setText("");
        lblitemid.setText("");
        
        txtpoid.setEnabled(true);
        jDateChooser1.setEnabled(true);
        combosupplierid.setEnabled(true);
        txtunitprice.setEnabled(true);
    }
    
    private String getSupplierName(String supplierId) {
    // Find the supplier name from the supplier list based on supplierId
        for (SupplierData supplierData : supplierData) {
            if (supplierData.getSupplierID().equals(supplierId)) {
                return supplierData.getSupplierName(); 
            }
        }
        return ""; // Return empty if not found
    }
    
    private void deleteApprovedRequisition() throws IOException{
        DefaultTableModel tblModel = (DefaultTableModel)requisitionTbl.getModel();
        String requisitionID = tblModel.getValueAt(requisitionTbl.getSelectedRow(), 0).toString();

        for (PurchaseData poData : purchaseData) {
            String poStatus = poData.getStatus(); 
            String requisitionidInPO = poData.getRequisitionID(); 

            // If status is approved and requisitionID matches
            if ("approved".equalsIgnoreCase(poStatus) && requisitionidInPO.equals(requisitionID)) {

                // Use an iterator to remove from requisition list
                Iterator<RequisitionData> iterator = requisitionData.iterator();
                while (iterator.hasNext()) {
                    RequisitionData reqData = iterator.next();

                    // Check if requisitionID matches
                    if (reqData.getRequisitionID().equals(requisitionidInPO)) { // Requisition ID should be at index 0 in reqData array
                        iterator.remove(); // Remove the matching requisition                     
                        break; // Exit the iterator after deleting the matching requisition
                    }
                }
                break; // Exit the loop after finding and processing the approved requisition
            }
        }
        ShowInTable(requisitionTbl);
        saveToRequisitionArray(requisitionTbl);
    }
    
    private static int poidCounter = 1;
    private boolean isComboInitializing = false;
        

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnclear;
    private javax.swing.JButton buttonDelete;
    private javax.swing.JButton buttonSave;
    private javax.swing.JButton buttonUpdate;
    private javax.swing.JButton buttonadd;
    private javax.swing.JComboBox<String> combostatus;
    private javax.swing.JComboBox<String> combosupplierid;
    private javax.swing.JLabel itemid;
    private javax.swing.JButton jButton1;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel lblPOtable;
    private javax.swing.JLabel lblRequisitionTable;
    private javax.swing.JLabel lblitemid;
    private javax.swing.JLabel lblrequisitionid;
    private javax.swing.JTable purchaseTbl;
    private javax.swing.JTable requisitionTbl;
    private javax.swing.JTextField txtpmid;
    private javax.swing.JTextField txtpoid;
    private javax.swing.JTextField txtquantity;
    private javax.swing.JTextField txttotalprice;
    private javax.swing.JTextField txtunitprice;
    private javax.swing.JLabel validatepmid;
    private javax.swing.JLabel validateprice;
    private javax.swing.JLabel validateqty;
    // End of variables declaration//GEN-END:variables
}
