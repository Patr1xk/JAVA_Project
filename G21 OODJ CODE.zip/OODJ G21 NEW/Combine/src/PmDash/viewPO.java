package PmDash;

import Login.InventoryData;
import Login.PurchaseData;
import Login.RequisitionData;
import Login.SalesData;
import Login.SupItemData;
import Login.SupplierData;
import Login.UserData;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.File;
import java.io.FileOutputStream;

public class viewPO extends javax.swing.JFrame {
    
    private ArrayList<UserData> userData;
    private ArrayList<SalesData> salesData;
    private ArrayList<InventoryData> inventoryData;
    private ArrayList<SupplierData> supplierData;
    private ArrayList<PurchaseData> purchaseData;
    private ArrayList<RequisitionData> requisitionData;
    private ArrayList<SupItemData> supItemData;

    public viewPO(ArrayList<UserData> userData, ArrayList<SalesData> salesData, ArrayList<InventoryData> inventoryData, ArrayList<SupplierData> supplierData, ArrayList<PurchaseData> purchaseData, ArrayList<RequisitionData> requisitionData, ArrayList<SupItemData> supItemData) {
        this.userData = userData;
        this.salesData = salesData;
        this.inventoryData = inventoryData;
        this.supplierData = supplierData;
        this.purchaseData = purchaseData;
        this.requisitionData = requisitionData;
        this.supItemData = supItemData;
        
        initComponents();
        ShowInTable(jTable1);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        comboSort = new javax.swing.JComboBox<>();
        txtsearch = new javax.swing.JTextField();
        btnsearch = new javax.swing.JButton();
        showall = new javax.swing.JButton();
        btnpdf = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(800, 500));

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 80));

        jLabel1.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Purchase Order");

        jButton1.setBackground(new java.awt.Color(51, 51, 51));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pmimages/home.jpg"))); // NOI18N
        jButton1.setBorder(null);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(24, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(14, 14, 14))
            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "PO ID", "PO Date", "Req ID", "PM ID", "Supplier ID", "Item ID", "Unit Price (RM)", "Qty", "Total Price (RM)", "PO Status"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        comboSort.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        comboSort.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sort", "Requisition ID", "PO ID", "Date", "Status" }));
        comboSort.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboSortActionPerformed(evt);
            }
        });

        txtsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtsearchActionPerformed(evt);
            }
        });

        btnsearch.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        btnsearch.setText("Search");
        btnsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsearchActionPerformed(evt);
            }
        });

        showall.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        showall.setText("Show All");
        showall.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showallActionPerformed(evt);
            }
        });

        btnpdf.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        btnpdf.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pmimages/pdf_icon.jpg"))); // NOI18N
        btnpdf.setText("PDF");
        btnpdf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnpdfActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 740, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtsearch, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnsearch)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(comboSort, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(showall, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnpdf, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(30, 30, 30))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnpdf, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(showall, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comboSort, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtsearch, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnsearch, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 419, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       PmDashboard dashboardFrame = new PmDashboard(userData,salesData,inventoryData,supplierData,purchaseData,requisitionData,supItemData);
       dashboardFrame.setVisible(true);

       // Close the current itemsList frame
       this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void comboSortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboSortActionPerformed
        String filter = comboSort.getSelectedItem().toString();
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        
        model.setRowCount(0);
        Comparator<PurchaseData> comparator = null;
        
        if (filter.equals("Date")){
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            comparator = (o1, o2) -> {
                try {
                    return dateFormat.parse(o1.getDate()).compareTo(dateFormat.parse(o2.getDate()));
                } catch (ParseException e) {
                    e.printStackTrace();
                    return 0;
                }
            };
            
        } else if (filter.equals("PO ID")) {
            comparator = Comparator.comparing(PurchaseData::getPoID);
            
        } else if (filter.equals("Status")) {
            comparator = (o1, o2) -> {
                // Ensure "pending" comes first, regardless of alphabetical order
                if (o1.getStatus().equals("Pending") && !o2.getStatus().equals("Pending")) {
                    return -1;  // "pending" should come first
                } 
                else if (!o1.getStatus().equals("Pending") && o2.getStatus().equals("Pending")) {
                    return 1;   // "pending" should come after other statuses
                }
                else {
                    return o1.getStatus().compareTo(o2.getStatus());  // For equal statuses, do lexicographical sorting
                }
            };
        } else if (filter.equals("Requisition ID")) {
            comparator = Comparator.comparing(PurchaseData::getRequisitionID);
        }

        if (comparator != null) {
            purchaseData.sort(comparator);
        }

        for (PurchaseData data : purchaseData) {
            model.addRow(new Object[] {
                data.getPoID(),
                data.getDate(),
                data.getRequisitionID(),
                data.getPmID(),
                data.getSupplierID(),
                data.getItemID(),
                data.getUnitPrice(),
                data.getQuantity(),
                data.getTotalPrice(),
                data.getStatus(),
            });
        }
    }//GEN-LAST:event_comboSortActionPerformed

    private void btnsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsearchActionPerformed
        DefaultTableModel df = (DefaultTableModel) jTable1.getModel();
        TableRowSorter<DefaultTableModel> obj = new TableRowSorter<>(df);
        jTable1.setRowSorter(obj);
        
        // Capitalize the first character of the search text
        String searchText = txtsearch.getText();
        if (!searchText.isEmpty()) {
            searchText = searchText.substring(0, 1).toUpperCase() + searchText.substring(1);
        }
    
        obj.setRowFilter(RowFilter.regexFilter(searchText));
        txtsearch.setText("");
    }//GEN-LAST:event_btnsearchActionPerformed

    private void showallActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showallActionPerformed
        DefaultTableModel df = (DefaultTableModel) jTable1.getModel();
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(df);
        jTable1.setRowSorter(sorter);
        sorter.setRowFilter(null);  // Reset any active filters
        ShowInTable(jTable1);
    }//GEN-LAST:event_showallActionPerformed

    private void txtsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtsearchActionPerformed

    }//GEN-LAST:event_txtsearchActionPerformed

    private void btnpdfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnpdfActionPerformed
        JFileChooser j = new JFileChooser();
        j.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES); // Allow files and directories
        j.setDialogTitle("Save PDF File");

        // Set default file name suggestion
        j.setSelectedFile(new File("PurchaseOrders.pdf"));

        int x = j.showSaveDialog(this);

        if (x == JFileChooser.APPROVE_OPTION) {
            String selectedFile = j.getSelectedFile().getAbsolutePath();

            if (!selectedFile.toLowerCase().endsWith(".pdf")) {
                selectedFile += ".pdf";
            }

            Document doc = new Document();

            try{
                PdfWriter.getInstance(doc, new FileOutputStream(selectedFile));
                doc.open();

                Font headerFont = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD);
                Font boldFont = new Font(Font.FontFamily.HELVETICA, 15, Font.BOLD);
                Font italicFont = new Font(Font.FontFamily.HELVETICA, 12, Font.ITALIC);

                Paragraph header = new Paragraph();
                header.setAlignment(Element.ALIGN_CENTER);
                header.setSpacingAfter(10f); // Space after header
                header.setLeading(10f, 1.5f); // Line spacing: 1.5 times the font size

                header.add(new Phrase("NEXUS SDN. BHD.\n", headerFont));
                header.add(new Phrase("Tel: 03-95295882\n", italicFont));
                header.add(new Phrase("Address: Jln Teknologi, 52000, Kuala Lumpur\n\n", italicFont));
                header.add(new Phrase("Purchaser Orders\n", boldFont));
                doc.add(header);

                PdfPTable tbl = new PdfPTable(10);
                tbl.setWidthPercentage(100);
                float[] columnWidths = {8f, 14f, 11f, 9f, 11f, 8f, 9f, 7f, 8f, 12f};
                tbl.setWidths(columnWidths);

                tbl.addCell("PO ID");
                tbl.addCell("PO Date");
                tbl.addCell("Req ID");
                tbl.addCell("PM ID");
                tbl.addCell("Supplier ID");
                tbl.addCell("Item ID");
                tbl.addCell("Unit Price");
                tbl.addCell("Qty");
                tbl.addCell("Total Price");
                tbl.addCell("PO Status");

                for (int i = 0; i<jTable1.getRowCount();i++){
                    String poid=jTable1.getValueAt(i, 0).toString();
                    String podate=jTable1.getValueAt(i, 1).toString();
                    String requisitionid=jTable1.getValueAt(i, 2).toString();
                    String pmid=jTable1.getValueAt(i, 3).toString();
                    String supid=jTable1.getValueAt(i, 4).toString();
                    String itemid=jTable1.getValueAt(i, 5).toString();
                    String unitprice=jTable1.getValueAt(i, 6).toString();
                    String qty=jTable1.getValueAt(i, 7).toString();
                    String total=jTable1.getValueAt(i, 8).toString();
                    String status=jTable1.getValueAt(i, 9).toString();

                    tbl.addCell(poid);
                    tbl.addCell(podate);
                    tbl.addCell(requisitionid);
                    tbl.addCell(pmid);
                    tbl.addCell(supid);
                    tbl.addCell(itemid);
                    tbl.addCell(unitprice);
                    tbl.addCell(qty);
                    tbl.addCell(total);
                    tbl.addCell(status);
                }
                doc.add(tbl);
                JOptionPane.showMessageDialog(null, "PDF Saved Successfully!");

            } catch(Exception e){
                JOptionPane.showMessageDialog(null, "Something Went Wrong!");

            } finally {
                doc.close();
            }
        }
    }//GEN-LAST:event_btnpdfActionPerformed

    public void ShowInTable(JTable jTable1) {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0); // Clear existing rows
        
        // Populate table with suppliersList data
        for (PurchaseData data : purchaseData) {
            model.addRow(new Object[] {
            data.getPoID(),
            data.getDate(),
            data.getRequisitionID(),
            data.getPmID(),
            data.getSupplierID(),
            data.getItemID(),
            data.getUnitPrice(),
            data.getQuantity(),
            data.getTotalPrice(),
            data.getStatus()
            });
        }
    }

//    public static void main(String args[]) {
//        /* Set the Nimbus look and feel */
//        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
//        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
//         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
//         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(viewPO.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(viewPO.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(viewPO.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(viewPO.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
//        //</editor-fold>
//
//        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new viewPO().setVisible(true);
//            }
//        });
//    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnpdf;
    private javax.swing.JButton btnsearch;
    private javax.swing.JComboBox<String> comboSort;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton showall;
    private javax.swing.JTextField txtsearch;
    // End of variables declaration//GEN-END:variables
}
