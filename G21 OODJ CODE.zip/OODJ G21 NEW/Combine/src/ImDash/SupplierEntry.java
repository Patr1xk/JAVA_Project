/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ImDash;

import Login.InventoryData;
import Login.SupItemData;
import Login.SupplierData;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import Login.FileHandling;
/**
 *
 * @author Asus
 */
public class SupplierEntry extends Manager implements FileHandling{
    private String currentSupID = null;
    
    public SupplierEntry(ArrayList<InventoryData> inventoryData, ArrayList<SupplierData> supplierData, ArrayList<SupItemData> supItemData) 
    {
        super(inventoryData, supplierData, supItemData);
    }
    
    @Override
    public void Show(JTable supplierTable) 
    {
        DefaultTableModel supplierTblModel = (DefaultTableModel) supplierTable.getModel();
        supplierTblModel.setRowCount(0); // Clear existing rows in the table

        // Iterate over the supplierData ArrayList to gather and display supplier details
        for (SupplierData supplier : supplierData) 
        {
            // Fetch supplier information
            String supplierID = supplier.getSupplierID();
            String supplierName = supplier.getSupplierName();
            String location = supplier.getLocation();

            // Add row to the JTable
            supplierTblModel.addRow(new Object[]{supplierID, supplierName, location});
        }
    }
    
    @Override
    public void ShowDetails(JTable itemTable, String selectedSupplierID) 
    {
        DefaultTableModel itemTblModel = (DefaultTableModel) itemTable.getModel();
        // Clear the existing rows in the item table
        itemTblModel.setRowCount(0);

        // Check if the supplier exists and has items
        if (supplierItemMap.containsKey(selectedSupplierID)) 
        {
            ArrayList<InventoryData> itemList = supplierItemMap.get(selectedSupplierID);

            // Check if the item list is empty
            if (itemList.isEmpty()) 
            {
                JOptionPane.showMessageDialog(null, "Supplier ID " + selectedSupplierID + " does not have any items listed.");
            } else 
            {
                // Populate the JTable with items if the list is not empty
                for (InventoryData inventory : itemList) 
                {   
                    itemTblModel.addRow(new Object[]{
                        inventory.getItemID(),
                        inventory.getItemName(),
                        inventory.getUnitPrice()
                    });
                }
            }
        } 
    }

    @Override
    public void Add(JTable supplierTable)
    {
        DefaultTableModel supplierTblModel = (DefaultTableModel) supplierTable.getModel();

        String supplierID =  "S" + String.format("%03d", getNextSupplierID());

        //prompt sup name
        String supplierName = null;
        do
        {
            supplierName = JOptionPane.showInputDialog("Enter supplier name");
            
            if (supplierName == null) 
            {
            return; // Exit if "X" is pressed
            }
            
            supplierName = supplierName.trim();
            supplierName = supplierName.substring(0,1).toUpperCase() + supplierName.substring(1);
            if(supplierName.isEmpty())
            {
                JOptionPane.showMessageDialog(null, "Supplier Name cannot be empty! Please try again!");
            }

        }while(supplierName.isEmpty());
        
        //validation for name
        for(SupplierData supplier: supplierData)
        {
            if(supplier.getSupplierName().equalsIgnoreCase(supplierName))
            {
                JOptionPane.showMessageDialog(null, "This supplier already existed!");
                return;
            }
        }
        
        //prompt sup location
        String location = null;
        do
        {
            location = JOptionPane.showInputDialog("Enter supplier location");
            
            if (location == null) 
            {
            return; // Exit if "X" is pressed
            }
            
            location = location.trim();
            location = location.substring(0,1).toUpperCase() + location.substring(1);
            if(location.isEmpty())
            {
                JOptionPane.showMessageDialog(null, "Supplier location cannot be empty! Please try again!");
            }
        }while(location.isEmpty());

        supplierTblModel.addRow(new Object[]{supplierID,supplierName,location});
        isModified = true;
                
        //add sup id into hashmap if it not exist
        if(!supplierItemMap.containsKey(supplierID))
        {
            supplierItemMap.put(supplierID, new ArrayList<InventoryData>());
        }
    }
    
    private int getNextSupplierID() 
    {
        int maxID = 0;

        // Loop through the existing supplierData and find the highest ID
        for (SupplierData supplier : supplierData) {
            String supplierID = supplier.getSupplierID(); // Assuming getSupplierID() exists
            int idNumber = Integer.parseInt(supplierID.substring(1)); // Extract number from "S001"

            if (idNumber > maxID) {
                maxID = idNumber;
            }
        }

        // Return the next available ID (one greater than the current maximum)
        return maxID + 1;
    }
    
    public int getNextItemID()
    {
        int maxID = 0;
        
        // Loop through the existing supplierData and find the highest ID
        for (InventoryData inventory : inventoryData) {
            String itemID = inventory.getItemID(); // Assuming getSupplierID() exists
            int idNumber = Integer.parseInt(itemID.substring(1)); // Extract number from "S001"

            if (idNumber > maxID) {
                maxID = idNumber;
            }
        }

        // Return the next available ID (one greater than the current maximum)
        return maxID + 1;
    }
    
    @Override
    public void handleItemTableSelection(JTable supplierTable) {
        // Check if a row is selected in the item table
        if (supplierTable.getSelectedRowCount() == 1) 
        {
            int selectedRowIndex = supplierTable.getSelectedRow();

            // Get the Item ID from the selected row (assuming the "Item ID" column is the first column)
            currentSupID = (String) supplierTable.getValueAt(selectedRowIndex, 0);  // Adjust the column index if necessary

            // Optionally, clear the selection in the item table
            supplierTable.clearSelection();

            // Print or debug to check the stored Item ID
            System.out.println("Selected Sup ID: " + currentSupID);
        } 
        else 
        {
            // No row selected or multiple rows selected
            JOptionPane.showMessageDialog(null, "Please select one row to edit.");
        }
    }
    
    @Override
    public void Edit(JTable supplierTable, JTable itemTable)
    {
        if(supplierTable.getSelectedRowCount() == 1 && supplierTable.getSelectedColumnCount() == 1)
        {
            int colToEditIndex = supplierTable.getSelectedColumn();
            int rowToEditIndex = supplierTable.getSelectedRow();
            String supID = (String) supplierTable.getValueAt(rowToEditIndex, supplierTable.getColumnModel().getColumnIndex("Supplier ID"));

            String colName = supplierTable.getColumnName(colToEditIndex);
            if(colName.equalsIgnoreCase("Supplier ID"))
            {
                JOptionPane.showMessageDialog(null, "Supplier ID cannot be edit!");
                return;
            }
            
            String newValue = null;
            do
            {
                newValue = JOptionPane.showInputDialog(null, "Edit value for " + colName + ":");
                
                if(newValue == null)
                {
                    return;
                }
                
                newValue = newValue.trim();
                newValue = newValue.substring(0,1).toUpperCase() + newValue.substring(1);
                if(newValue.isEmpty())
                {
                    JOptionPane.showMessageDialog(null, colName + "cannot be empty! Please try again!");
                }
            }while(newValue.isEmpty());

            //validation for name
            if(colName.equalsIgnoreCase("Supplier Name"))
            {
                for(SupplierData supplier: supplierData)
                {
                    if(supplier.getSupplierName().equalsIgnoreCase(newValue))
                    {
                        JOptionPane.showMessageDialog(null, "This supplier already existed!");
                        return;
                    }
                }
            }
            
            if(newValue != null)
            {
                supplierTable.setValueAt(newValue, rowToEditIndex, colToEditIndex);
                
                //update to hashmap for checking
                ArrayList<InventoryData> inventoryList = supplierItemMap.get(supID);
                if(inventoryList != null)
                {
                    for(InventoryData inventory: inventoryList)
                    {
                        String itemID = inventory.getItemID();
                        ArrayList<SupplierData> supplierList = itemSupplierMap.get(itemID);
                        if(supplierList != null)
                        {
                            for(SupplierData supplier: supplierList)
                            {
                                if(supplier.getSupplierID().equalsIgnoreCase(supID))
                                {
                                    supplier.setSupplierName(newValue);
                                }
                            }
                        }
                        
                    }
                }
                
                isModified = true;
            }
        }
        else if(itemTable.getSelectedRowCount() == 1 && itemTable.getSelectedColumnCount() == 1)
        {
            int colToEditIndex = itemTable.getSelectedColumn();
            int rowToEditIndex = itemTable.getSelectedRow();

            String itemID = (String) itemTable.getValueAt(rowToEditIndex, itemTable.getColumnModel().getColumnIndex("Item ID"));
            String colName = itemTable.getColumnName(colToEditIndex);
            
            if(colName.equalsIgnoreCase("Item ID") || colName.equalsIgnoreCase("Item Name"))
            {
                JOptionPane.showMessageDialog(null, colName + " cannot be edited!");
                return;
            }
            
            String strUnitPrice = null;
            double newUnitPrice = 0.0;
            do
            {
                strUnitPrice = JOptionPane.showInputDialog(null, "Edit value for unit price:");
                
                if(strUnitPrice == null)
                {
                    return;
                }
                
                strUnitPrice = strUnitPrice.trim();
                if(strUnitPrice.isEmpty())
                {
                    JOptionPane.showMessageDialog(null, colName + "cannot be empty! Please try again!");
                }
            }while(strUnitPrice.isEmpty());
            
            try
            {
                newUnitPrice = Double.parseDouble(strUnitPrice);
                if(newUnitPrice <= 0)
                {
                    JOptionPane.showMessageDialog(null, "Please enter a valid amount!");
                    return;
                }
                
                itemTable.setValueAt(newUnitPrice, rowToEditIndex, colToEditIndex);
            }catch(NumberFormatException e)
            {
                JOptionPane.showMessageDialog(null, "Invalid input! Please enter a valid integer.", 
                                              "Error", JOptionPane.ERROR_MESSAGE);
            }            
            
            //upload and sync hashmap (item and sup )
            //supitemmap
            ArrayList<InventoryData> inventoryList = supplierItemMap.get(currentSupID);
            for(InventoryData inventory: inventoryList)
            {
                if(inventory.getItemID().equalsIgnoreCase(itemID))
                {
                    inventory.setUnitPrice(newUnitPrice);
                    break;
                }
            }

            //itemsupmap
            ArrayList<SupplierData> supplierList = itemSupplierMap.get(itemID);
            for(SupplierData supplier: supplierList)
            {
                if(supplier.getSupplierID().equalsIgnoreCase(currentSupID))
                {
                    supplier.setUnitPrice(newUnitPrice);
                    break;
                }
            }
            isModified = true;
        }
        else
        {
            if(supplierTable.getRowCount() == 0)
            {
                JOptionPane.showMessageDialog(null, "Table is empty"); 
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Please select A CELL for edit");
            }
        }
    }
    
    @Override
    public void Delete(JTable supplierTable, JTable itemTable)
    {
        DefaultTableModel supplierTblModel = (DefaultTableModel) supplierTable.getModel();
        DefaultTableModel itemTblModel = (DefaultTableModel) itemTable.getModel();

        if(supplierTable.getSelectedRowCount() == 1)
        {
            itemTable.clearSelection();
            int rowToDeleteIndex = supplierTable.getSelectedRow();
            String supplierID = (String) supplierTblModel.getValueAt(rowToDeleteIndex, 0);
            
            //supitemmap
            //set supplier to "unknown"            
            ArrayList<InventoryData> inventoryList = supplierItemMap.get(supplierID);
            supplierTblModel.removeRow(rowToDeleteIndex);
            
            int response = JOptionPane.showConfirmDialog(null, "Do you want to delete this supplier?", "Delete Supplier", JOptionPane.YES_NO_OPTION);
            
            if(response == JOptionPane.YES_OPTION)
            {
                if (supplierItemMap.containsKey(supplierID)) 
                {
                    supplierItemMap.remove(supplierID);
                    //assign unknown for deleted supplier if they have items
                    if(inventoryList != null)
                    {
                        supplierItemMap.put("UNKNOWN", inventoryList);
                    }
                }

                //sync to itemsupmap too
                for(InventoryData inventory: inventoryList)
                {
                    String itemID = inventory.getItemID();
                    ArrayList<SupplierData> supplierList = itemSupplierMap.get(itemID);

                    for(SupplierData supplier: supplierList)
                    {
                        if(supplier.getSupplierID().equalsIgnoreCase(supplierID))
                        {
                            supplier.setSupplierID("UNKNOWN");
                            supplier.setSupplierName("UNKNOWN");
                            supplier.setLocation("UNKNOWN");
                        }
                    }
                }
            }
            else
            {
                return;
            }

            itemTblModel.setRowCount(0);

            JOptionPane.showMessageDialog(null, "Supplier " + supplierID + " has been deleted successfully.");
            isModified = true;
        }
        else
        {
            if(supplierTable.getRowCount() == 0)
            {
                JOptionPane.showMessageDialog(null, "Table is empty"); 
            }
            else if(supplierTable.getSelectedRowCount() == 0 && itemTable.getSelectedRowCount() == 0)
            {
                JOptionPane.showMessageDialog(null, "Please select SINGLE ROW for delete");
                return;
            }
        }
       
        if(itemTable.getSelectedRowCount() == 1)
        {
            int rowToDeleteIndex = itemTable.getSelectedRow();
            String itemID = (String) itemTblModel.getValueAt(rowToDeleteIndex, 0);
            
            int response = JOptionPane.showConfirmDialog(null, "Do you want to delete this item for supplier " + currentSupID + "?","Delete Item", JOptionPane.YES_NO_OPTION);

            if(response == JOptionPane.YES_OPTION)
            {
                ArrayList<InventoryData> inventoryList = supplierItemMap.get(currentSupID);
                itemTblModel.removeRow(rowToDeleteIndex);

                //update itemsupmap
                ArrayList<SupplierData> supplierList = itemSupplierMap.get(itemID);
                for(SupplierData supplier: supplierList)
                {
                    if(supplier.getSupplierID().equalsIgnoreCase(currentSupID))
                    {
                        supplier.setSupplierID("UNKNOWN");
                        supplier.setSupplierName("UNKNOWN");
                        supplier.setLocation("UNKNOWN");
                    }
                }

                //supitemmap update
                for(InventoryData inventory: inventoryList)
                {
                    if(inventory.getItemID().equalsIgnoreCase(itemID))
                    {
                        inventoryList.remove(inventory);
                        break;
                    }
                }
                JOptionPane.showMessageDialog(null, "Item deleted successfully!");
            }
            isModified = true;
        }
    }
    
    @Override
    public void AddDetails(JTable supplierTable, JTable itemTable)
    {
        DefaultTableModel supTblModel = (DefaultTableModel) supplierTable.getModel();
        DefaultTableModel itemTblModel = (DefaultTableModel) itemTable.getModel();
        
        if(supplierTable.getSelectedRowCount() == 1)
        {
            int rowToAdd = supplierTable.getSelectedRow();
            String supID = (String) supTblModel.getValueAt(rowToAdd, supplierTable.getColumnModel().getColumnIndex("Supplier ID"));
            String supName = (String) supTblModel.getValueAt(rowToAdd, supplierTable.getColumnModel().getColumnIndex("Supplier Name"));
            String location = (String) supTblModel.getValueAt(rowToAdd, supplierTable.getColumnModel().getColumnIndex("Location"));
            
            //prompt for item name
            String itemName = null;
            do
            {
                itemName = JOptionPane.showInputDialog("Enter item name");
                if(itemName == null)
                {
                    return;
                }
                
                itemName = itemName.trim();
                itemName = itemName.substring(0,1).toUpperCase() + itemName.substring(1);
                if(itemName.isEmpty())
                {
                    JOptionPane.showMessageDialog(null, "Item name cannot be empty. Please try again.");
                }

            }while(itemName.isEmpty());
            
            //validation for name
            ArrayList<InventoryData> inventoryList = supplierItemMap.get(supID);
            if(inventoryList != null)
            {
                
                for(InventoryData inventory: inventoryList)
                {
                    if(inventory.getItemName().equalsIgnoreCase(itemName))
                    {
                        JOptionPane.showMessageDialog(null, "This item already exist for this supplier!");
                        return;
                    }
                }
            }
            
            //prompt for unit price
            String strUnitPrice = null;
            double unitPrice = 0.0;
            do
            {
                strUnitPrice = JOptionPane.showInputDialog("Enter unit price");
                if(strUnitPrice == null)
                {
                    return;
                }
                
                strUnitPrice = strUnitPrice.trim();
                if(strUnitPrice.isEmpty())
                {
                    JOptionPane.showMessageDialog(null, "Unit price cannot be empty. Please try again.");
                }

            }while(strUnitPrice.isEmpty());
            
            try
            {
                unitPrice = Double.parseDouble(strUnitPrice);
                if(unitPrice <= 0)
                {
                    JOptionPane.showMessageDialog(null, "Please enter a valid amount!");
                    return;
                }
            }catch(NumberFormatException e)
            {
                JOptionPane.showMessageDialog(null, "Invalid input! Please enter a valid integer.", 
                                              "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            //validation for item name
            //if not exists create a new item id...
            boolean itemExist = false;
            String itemID = null;
            for(InventoryData inventoryInfo: inventoryData)
            {
                if(inventoryInfo.getItemName().equalsIgnoreCase(itemName))
                {
                    itemExist = true;
                    itemID = inventoryInfo.getItemID();

                    if (inventoryList == null) 
                    {
                        inventoryList = new ArrayList<>();
                        supplierItemMap.put(supID, inventoryList); // Initialize the list
                    }
                    
                     // Add the new item for this supplier
                    InventoryData addExistingItem = new InventoryData(itemID, itemName, unitPrice);
                    inventoryList.add(addExistingItem);              

                    // Add the item row to the table
                    itemTblModel.addRow(new Object[]{itemID, itemName, unitPrice});
                    
                    //add to item sup also
                    ArrayList<SupplierData> supplierList = itemSupplierMap.get(itemID);
                    if (supplierList == null) {
                        supplierList = new ArrayList<>();
                        itemSupplierMap.put(itemID, supplierList);
                    }
                    for(SupplierData supplier: supplierList)
                    {
                        if(supplier.getSupplierID().equalsIgnoreCase(supID))
                        {
                            int qty = supplier.getQty();
                            supplierList.add(new SupplierData(supID, supName, location, qty, unitPrice));
                        }
                    }
                    break;
                }
            }
            
            if(!itemExist)
            {
                if (inventoryList == null) 
                {
                    inventoryList = new ArrayList<>();
                    supplierItemMap.put(supID, inventoryList); // Initialize the list
                }
                
                itemID = "I" + String.format("%03d", getNextItemID());
                
                // Create a new InventoryData object and add it
                InventoryData newItem = new InventoryData(itemID, itemName, unitPrice);
                inventoryList.add(newItem);
                
                // Add the item row to the table
                itemTblModel.addRow(new Object[]{itemID, itemName, unitPrice});
            }  

            // Update itemSupplierMap
            ArrayList<SupplierData> supplierList = itemSupplierMap.get(itemID);
            if (supplierList == null) {
                supplierList = new ArrayList<>();
                itemSupplierMap.put(itemID, supplierList);
            }
            boolean supplierExists = false;
            for (SupplierData supplier : supplierList) {
                if (supplier.getSupplierID().equalsIgnoreCase(supID)) {
                    supplierExists = true;
                    break;
                }
            }

            if (!supplierExists) {
                supplierList.add(new SupplierData(supID, supName, location, 0, unitPrice));
            }
            isModified = true; 
            supplierTable.clearSelection();
        }
    
    }
  
    //save to arraylist done
    //left save to file
    @Override
    public void SaveToArray(JTable supplierTable) throws IOException 
    {
        supplierData.clear();
        supItemData.clear();

        //upload to arraylist
        DefaultTableModel supplierTblModel = (DefaultTableModel) supplierTable.getModel();

        //add supplier to arraylist first
        for (int i = 0; i < supplierTblModel.getRowCount(); i++) 
        {
            String supplierID = (String) supplierTable.getValueAt(i, 0);
            String supplierName = (String) supplierTable.getValueAt(i, 1);
            String location = (String) supplierTable.getValueAt(i, 2);

            System.out.println("Processing supplier: " + supplierID); // Debug line
            System.out.println("Name: " + supplierName + ", Location: " + location); // Debug line

            SupplierData suppliers = new SupplierData(supplierID, supplierName, location);
            supplierData.add(suppliers);
           
            ArrayList<InventoryData> inventoryList = supplierItemMap.get(supplierID);
            // Check if the supplier exists in the supplierItemMap
            if (supplierItemMap.containsKey(supplierID)) 
            {
                // Iterate through each item in the map
                for (InventoryData newInventory : inventoryList) 
                {
                    String newItemID = newInventory.getItemID();

                    // Check if this item already exists in inventoryData
                    boolean exists = false;
                    for (InventoryData existingInventory : inventoryData) 
                    {
                        if (existingInventory.getItemID().equals(newItemID)) 
                        {
                            exists = true;
                            break; // Item already exists, stop checking further
                        }
                    }

                    // Append only if it doesn't exist
                    if (!exists) 
                    {
                        InventoryData newItem = new InventoryData(newInventory.getItemID(), newInventory.getItemName(), 0, "-");
                        inventoryData.add(newItem);
                    }
                }
            }
            
            
            if(inventoryList != null)
            {
                for(InventoryData inventory: inventoryList)
                {
                    String itemID = inventory.getItemID();
                    double unitPrice = inventory.getUnitPrice();
                    ArrayList<SupplierData> supplierList = itemSupplierMap.get(itemID);
                    
                    if(supplierList != null)
                    {
                        for(SupplierData supplier: supplierList)
                        {
                            int qty = supplier.getQty();
                            if (supplier.getSupplierID().equals(supplierID)) 
                            {
                            
                                // Create and add SupItemData with separate qty for each supplier-item combination
                                SupItemData supItem = new SupItemData(supplierID, itemID, qty, unitPrice);
                                supItemData.add(supItem);
                            }
                            else if(supplier.getSupplierID().equals("UNKNOWN"))
                            {                                
                                if (qty > 0) {  
                                    SupItemData supItem = new SupItemData("UNKNOWN", itemID, qty, unitPrice);
                                    supItemData.add(supItem);
                                } else {
                                    System.out.println("Skipping UNKNOWN supplier with qty = 0");
                                }
                            }
                         
                        }    
                    }          
                }
            }      
        }
        JOptionPane.showMessageDialog(null, "Data saved successfully!");
        isModified = false;
    }
}

