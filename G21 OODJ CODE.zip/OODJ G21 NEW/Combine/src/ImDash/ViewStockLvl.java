/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ImDash;

import Login.InventoryData;
import Login.SupItemData;
import Login.SupplierData;
import java.util.ArrayList;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Asus
 */
public class ViewStockLvl extends ItemEntry{
    
    public ViewStockLvl(ArrayList<InventoryData> inventoryData, ArrayList<SupplierData> supplierData, ArrayList<SupItemData> supItemData)
    {
        super(inventoryData, supplierData, supItemData);
    }
    
    public void Search(JTable itemTable, JTextField txt)
    {
        boolean itemExist = false;
        String name = txt.getText().trim();
        DefaultTableModel itemTblModel = (DefaultTableModel) itemTable.getModel();
        itemTblModel.setRowCount(0);
        for(InventoryData inventory: inventoryData)
        {
            if(inventory.getTotalQty() != 0 && inventory.getItemName().equalsIgnoreCase(name))
            {
                String itemID = inventory.getItemID();
                String itemName = inventory.getItemName();
                int totalQty = inventory.getTotalQty();
                String stockLvl = inventory.getStockLvl();

                itemTblModel.addRow(new Object[]{itemID, itemName, totalQty, stockLvl});
                itemExist = true;
            }
            
        }
        
        if(name.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Search field cannot be empty");
            Show(itemTable);
            itemExist = true; // this is neutral bc if dh this line of code it would duplicate as item not exist and execute the !item exist code
        }
        
        if(!itemExist)
        {
            JOptionPane.showMessageDialog(null, "This item does not exists in our inventory");
            Show(itemTable);
        }
    }
    
    public void Sort(JTable itemTable, JComboBox cmb)
    {
        String sort = (String) cmb.getSelectedItem();
        DefaultTableModel itemTblModel = (DefaultTableModel) itemTable.getModel();
        itemTblModel.setRowCount(0);
        for(InventoryData inventory: inventoryData)
        {
            if(inventory.getTotalQty() != 0 && sort.equalsIgnoreCase("All Stock"))
            {
                String itemID = inventory.getItemID();
                String itemName = inventory.getItemName();
                int totalQty = inventory.getTotalQty();
                String stockLvl = inventory.getStockLvl();

                itemTblModel.addRow(new Object[]{itemID, itemName, totalQty, stockLvl});
            }
            else
            {
                if(inventory.getStockLvl().equalsIgnoreCase("Low"))
                {
                    String itemID = inventory.getItemID();
                    String itemName = inventory.getItemName();
                    int totalQty = inventory.getTotalQty();
                    String stockLvl = inventory.getStockLvl();

                    itemTblModel.addRow(new Object[]{itemID, itemName, totalQty, stockLvl});
                }
            }
        }
    }
}
