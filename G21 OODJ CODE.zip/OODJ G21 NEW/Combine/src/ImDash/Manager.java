/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ImDash;
import Login.FileHandling;
import static Login.FileHandling.inventoryFilePath;
import static Login.FileHandling.supItemFilePath;
import static Login.FileHandling.supplierFilePath;
import Login.InventoryData;
import Login.SupItemData;
import Login.SupplierData;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;
import javax.swing.JOptionPane;
import javax.swing.JTable;

/**
 *
 * @author Asus
 */

//parent class for inheritance
//abstract classes
public abstract class Manager implements FileHandling{
    
    protected HashMap<String, ArrayList<SupplierData>> itemSupplierMap;
    protected HashMap<String, ArrayList<InventoryData>> supplierItemMap;
    protected TreeMap<String, Integer> itemQtyMap;
    protected ArrayList<InventoryData> inventoryData;
    protected ArrayList<SupplierData> supplierData;
    protected ArrayList<SupItemData> supItemData;
    protected boolean isModified = false;
    
    public Manager(ArrayList<InventoryData> inventoryData, ArrayList<SupplierData> supplierData, ArrayList<SupItemData> supItemData)
    {
        this.inventoryData = inventoryData;
        this.supplierData = supplierData;
        this.supItemData = supItemData;
        this.itemSupplierMap = new HashMap<>();
        this.supplierItemMap = new HashMap<>();
        //Total Qty
        //sort by key (itemID)
        this.itemQtyMap = new TreeMap<>(); 
        loadToInventoryHashMap();
        loadToSupplierHashMap();
        loadToTreeMap();
    }
    
    private void loadToSupplierHashMap()
    {
        for(SupItemData supItem: supItemData)
        {
            String supplierID = supItem.getSupplierID();
            String itemID = supItem.getItemID();
            double unitPrice = supItem.getUnitPrice();

            InventoryData matchedInventory = null;
            for(InventoryData inventory: inventoryData)
            {
                if(inventory.getItemID().equals(itemID))
                {
                    matchedInventory = inventory;
                    break;
                }
            }

            InventoryData inventoryDetails = inventoryDetails(itemID);

            if(inventoryDetails == null)
            {
                System.out.println("Inventory ID does not exist. Skipping entry.");
                supplierItemMap.putIfAbsent(supplierID, new ArrayList<>()); 
            }
            
            if(matchedInventory != null)
            {
                InventoryData inventoryInfo = new InventoryData(
                itemID,matchedInventory.getItemName(),
                unitPrice);
                
                supplierItemMap.putIfAbsent(supplierID, new ArrayList<>()); 
                supplierItemMap.get(supplierID).add(inventoryInfo);
            }
            else
            {
                System.out.println("Item ID does not exist in inventory data.");
            }
        }
    }
    
    private InventoryData inventoryDetails(String itemID)
    {
        for(InventoryData inventory: inventoryData)
        {
            if(inventory.getItemID().equals(itemID))
            {
                return new InventoryData(
                    inventory.getItemID(),
                    inventory.getItemName(),
                    inventory.getTotalQty(),
                    inventory.getStockLvl()
                );
            }
        }
        return null;
    }
    
    private void loadToInventoryHashMap() 
    {   
        itemSupplierMap = new HashMap<>();
        
        for(SupItemData supItem: supItemData)
        {
            String itemID = supItem.getItemID();
            String supplierID = supItem.getSupplierID();
            
            //itemid n supid is composite key, can determine qty and unitPrice
            double unitPrice = supItem.getUnitPrice();
            int qty = supItem.getQuantity();
            
            // Ensure the supplier exists in supplierData list
            SupplierData matchedSupplier = null;
            for (SupplierData supplier : supplierData) 
            {
                if (supplier.getSupplierID().equals(supplierID)) {
                    matchedSupplier = supplier;
                    break;
                }
            }
                
            SupplierData supplierDetails = supplierDetails(supplierID);
            
            if (supplierDetails == null) 
            {
                System.out.println("Supplier ID does not exist. Skipping entry.");
                SupplierData supplierInfo = new SupplierData(
                "UNKNOWN", "UNKNOWN",
                "UNKNOWN", qty, unitPrice
                );
                
                // Initialize the list for the itemId if not already present
                itemSupplierMap.putIfAbsent(itemID, new ArrayList<>());

                // Add the supplier information to the list
                itemSupplierMap.get(itemID).add(supplierInfo);
                continue;
            }
            
            if (matchedSupplier != null) 
            {
                // Create a new supplier entry for the item
                SupplierData supplierInfo = new SupplierData(
                supplierID, matchedSupplier.getSupplierName(),
                matchedSupplier.getLocation(), qty, unitPrice
                );

                // Initialize the list for the itemId if not already present
                itemSupplierMap.putIfAbsent(itemID, new ArrayList<>());

                // Add the supplier information to the list
                itemSupplierMap.get(itemID).add(supplierInfo);
            
            } 
        }
    }
    
    private SupplierData supplierDetails(String supplierId) 
    {
        for (SupplierData supplier : supplierData) 
        { 
            if (supplier.getSupplierID().equals(supplierId)) 
            {
                return new SupplierData(
                    supplier.getSupplierID(),
                    supplier.getSupplierName(),
                    supplier.getLocation()
                );
            }
        }
        return null; // Supplier not found
    }
    
    private void loadToTreeMap()
    {
        for(InventoryData inv: inventoryData)
        {
            itemQtyMap.put(inv.getItemID(),inv.getTotalQty());
        }
    }

    public HashMap<String, ArrayList<SupplierData>> getItemSupplierMap() {
        return itemSupplierMap;
    }

    public HashMap<String, ArrayList<InventoryData>> getSupplierItemMap() {
        return supplierItemMap;
    }

    public TreeMap<String, Integer> getItemQtyMap() {
        return itemQtyMap;
    }

    public abstract void Show(JTable table);
    
    public abstract void ShowDetails(JTable table, String selectedItemId);
    
    public abstract void Add(JTable table);
    
    public abstract void Edit(JTable table1, JTable table2);
         
    public abstract void Delete(JTable table1, JTable table2);
    
    public abstract void handleItemTableSelection(JTable table);
    
    public abstract void AddDetails(JTable table, JTable table2);
    //could be overide
    public abstract void SaveToArray(JTable table) throws IOException;

    public void checkUnsavedChanges(JTable table) throws IOException
    {
        if(isModified)
        {
            int response = JOptionPane.showConfirmDialog(null, "You have unsaved changes. Would you like to save?", 
                                                        "Unsaved changes", JOptionPane.YES_NO_OPTION);
            
            if(response == JOptionPane.YES_OPTION)
            {
                SaveToArray(table);
                Save(supplierData, supplierFilePath);
                Save(supItemData, supItemFilePath);
                Save(inventoryData, inventoryFilePath);
                isModified = false;
            }
        }
    }
    
}
