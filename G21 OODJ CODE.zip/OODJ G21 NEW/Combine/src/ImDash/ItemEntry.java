/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ImDash;

import Login.FileHandling;
import Login.InventoryData;
import Login.SupItemData;
import Login.SupplierData;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;
import java.util.TreeMap;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;


/**
 *
 * @author Asus 

 */ 

//child class for inheritance
public class ItemEntry extends Manager implements FileHandling{
    private String currentItemID = null;    

    public ItemEntry(ArrayList<InventoryData> inventoryData, ArrayList<SupplierData> supplierData, ArrayList<SupItemData> supItemData) 
    {
        super(inventoryData, supplierData, supItemData);

    }

    @Override
    public void Show(JTable itemTable) 
    {
        DefaultTableModel itemTblModel = (DefaultTableModel) itemTable.getModel();
        itemTblModel.setRowCount(0); // Clear the table before adding rows       

        for(InventoryData inventory: inventoryData)
        {
            //add one condition if that item is only from supplier entry thr but not in item entry
            //eg. new item bread from supplier, but we did not entry it so it shud not shows
            if(inventory.getTotalQty() != 0)
            {
                String itemID = inventory.getItemID();
                String itemName = inventory.getItemName();
                int totalQty = inventory.getTotalQty();
                String stockLvl = inventory.getStockLvl();

                itemTblModel.addRow(new Object[]{itemID, itemName, totalQty, stockLvl});
            }
        }  
    }
    
    @Override
    public void ShowDetails(JTable supplierTable, String selectedItemId)
    {
        DefaultTableModel supplierTblModel = (DefaultTableModel) supplierTable.getModel();
        supplierTblModel.setRowCount(0); 
        
        if(itemSupplierMap.containsKey(selectedItemId))
        {
            ArrayList<SupplierData> suppliersList = itemSupplierMap.get(selectedItemId);
            
            for(SupplierData supplier : suppliersList)
            {
                if(supplier.getQty() > 0)
                {
                    Object[] row = {
                    supplier.getSupplierID(),
                    supplier.getSupplierName(),
                    supplier.getLocation(),
                    supplier.getQty(),
                    supplier.getUnitPrice()
                    };
                    supplierTblModel.addRow(row);
                }
            } 
        }  
    }
    
    @Override
    public void Add(JTable itemTable) {
        DefaultTableModel itemTblModel = (DefaultTableModel) itemTable.getModel();

        // Prompt for item name
        String itemName;
        do {
            itemName = JOptionPane.showInputDialog("Enter item name");
            if (itemName == null)
            {
                return;
            }
            itemName = itemName.trim();
            if (itemName.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Item Name cannot be empty! Please try again!");
            } else {
                itemName = itemName.substring(0, 1).toUpperCase() + itemName.substring(1);
            }
        } while (itemName.isEmpty());

        // Find item ID or create a new one
        String itemID = null;
        for (InventoryData inventory : inventoryData) {
            if (inventory.getItemName().equalsIgnoreCase(itemName)) {
                itemID = inventory.getItemID();
                break;
            }
        }
        if (itemID == null) 
        {
            itemID = "I" + String.format("%03d", getNextItemID());
        }

        // Validate item name in the table
        for (int i = 0; i < itemTblModel.getRowCount(); i++) 
        {
            String itemTblName = (String) itemTable.getValueAt(i, 1);
            if (itemName.equalsIgnoreCase(itemTblName)) 
            {
                JOptionPane.showMessageDialog(null, "This item already exists in the table.");
                return;
            }
        }

        // Input for item quantity
        int qty;
        String strQty;
        do {
            strQty = JOptionPane.showInputDialog("Enter item quantity");
            if (strQty == null) 
            {
                return;
            }
            strQty = strQty.trim();
            if (strQty.isEmpty()) 
            {
                JOptionPane.showMessageDialog(null, "Quantity cannot be empty! Please try again!");
            }
        } while (strQty.isEmpty());

        try {
            qty = Integer.parseInt(strQty);
            if (qty <= 0) 
            {
                JOptionPane.showMessageDialog(null, "Please enter a valid quantity!");
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid input! Please enter a valid integer.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Determine stock level
        int totalQty = itemQtyMap.getOrDefault(itemID, 0) + qty;
        String stockLvl = (totalQty > 10) ? "-" : "Low";
        itemQtyMap.put(itemID, totalQty);

        // Prompt for supplier ID
        String supplierID;
        do {
            supplierID = JOptionPane.showInputDialog("Enter supplier ID");
            if (supplierID == null) 
            {
                return;
            }
            supplierID = supplierID.trim();
            if (supplierID.isEmpty()) 
            {
                JOptionPane.showMessageDialog(null, "Supplier ID cannot be empty! Please try again!");
            } else {
                supplierID = supplierID.substring(0, 1).toUpperCase() + supplierID.substring(1);
            }
        } while (supplierID.isEmpty());

        // Validate if the supplier exists
        boolean supplierExists = false;
        for (SupplierData supplier : supplierData) 
        {
            if (supplier.getSupplierID().equalsIgnoreCase(supplierID)) 
            {
                supplierExists = true;
                break;
            }
        }
        if (!supplierExists) 
        {
            JOptionPane.showMessageDialog(null, "This supplier does not exist.");
            return;
        }

        // Check if the supplier supplies the item
        ArrayList<InventoryData> inventoryList = supplierItemMap.get(supplierID);
        if (inventoryList == null)
        {
            inventoryList = new ArrayList<>(); // Initialize if null
            supplierItemMap.put(supplierID, inventoryList);
        }

        boolean gotSupply = false;
        for (InventoryData inventoryInfo : inventoryList) 
        {
            if (inventoryInfo.getItemName().equalsIgnoreCase(itemName)) {
                gotSupply = true;
                break;
            }
        }
        if (!gotSupply) 
        {
            JOptionPane.showMessageDialog(null, "This supplier does not supply this item!");
            return;
        }

        // Add item to the table
        itemTblModel.addRow(new Object[]{itemID, itemName, qty, stockLvl});
        
        //upload to itemsupmap
        if (!itemSupplierMap.containsKey(itemID)) 
        {
            itemSupplierMap.put(itemID, new ArrayList<>()); // Create a new list for suppliers if the itemID doesn't exist
        }
        
        ArrayList<SupplierData> supplierList = itemSupplierMap.get(itemID);
        for(SupplierData supplier: supplierList)
        {
            if(supplier.getSupplierID().equalsIgnoreCase(supplierID))
            {
                int currentQty = supplier.getQty();
                supplier.setQty(currentQty + qty);

                JOptionPane.showMessageDialog(null, "Supplier added successfully for item: " + itemID);
                break;
            }
        }
        
        // Mark data as modified (but not saved yet)
        isModified = true;
    }

    public int getNextItemID()
    {
        int maxID = 0;
        
        for(String itemID: itemSupplierMap.keySet())
        {
            int idNumber = Integer.parseInt(itemID.substring(1));
            
            if(idNumber > maxID)
            {
                maxID = idNumber;
            }
        }
        return maxID + 1;
    }
    
    // Method to handle selection in item table and store Item ID
    @Override
    public void handleItemTableSelection(JTable itemTable) {
        // Check if a row is selected in the item table
        if (itemTable.getSelectedRowCount() == 1) 
        {
            int selectedRowIndex = itemTable.getSelectedRow();

            // Get the Item ID from the selected row (assuming the "Item ID" column is the first column)
            currentItemID = (String) itemTable.getValueAt(selectedRowIndex, 0);  // Adjust the column index if necessary

            // Optionally, clear the selection in the item table
            itemTable.clearSelection();

            // Print or debug to check the stored Item ID
            System.out.println("Selected Item ID: " + currentItemID);
        } 
        else 
        {
            // No row selected or multiple rows selected
            JOptionPane.showMessageDialog(null, "Please select one row to edit.");
        }
    }
    
    @Override
    public void Edit(JTable itemTable, JTable supplierTable) 
    {
        // Check if the user selected one cell in itemTable for editing
        if (itemTable.getSelectedRowCount() == 1 && itemTable.getSelectedColumnCount() == 1) 
        {
            int rowToEditIndexItem = itemTable.getSelectedRow();
            int colToEditIndexItem = itemTable.getSelectedColumn();

            String colName = itemTable.getColumnName(colToEditIndexItem);
            String itemID = (String) itemTable.getValueAt(rowToEditIndexItem, itemTable.getColumnModel().getColumnIndex("Item ID"));
                        
            // Prevent editing specific columns in itemTable
            if (colName.equalsIgnoreCase("Item ID") || colName.equalsIgnoreCase("Total Qty.") || colName.equalsIgnoreCase("Stock Level")) 
            {
                JOptionPane.showMessageDialog(null, colName + " cannot be edited!");
                return;
            }

            String newItemName = null;
            do
            {
                newItemName = JOptionPane.showInputDialog(null, "Edit value for " + colName + ":");
                if(newItemName == null)
                {
                    return;
                }
                newItemName = newItemName.trim();
                newItemName = newItemName.substring(0,1).toUpperCase() + newItemName.substring(1);
                if(newItemName.isEmpty())
                {
                    JOptionPane.showMessageDialog(null, "Item Name cannot be empty! Please try again!");
                }
            }while(newItemName.isEmpty());

            if (newItemName != null) 
            {
                itemTable.setValueAt(newItemName, rowToEditIndexItem, colToEditIndexItem);
                //update to hashmap for checking
                ArrayList<SupplierData> supplierList = itemSupplierMap.get(itemID);
                if(supplierList != null)
                {
                    for(SupplierData supplier: supplierList)
                    {
                        String supID = supplier.getSupplierID();
                        ArrayList<InventoryData> inventoryList = supplierItemMap.get(supID);
                        if(inventoryList != null)
                        {
                            for(InventoryData inventory: inventoryList)
                            {
                                if(inventory.getItemID().equalsIgnoreCase(itemID))
                                {
                                    inventory.setItemName(newItemName);
                                }
                            }
                        }          
                    }
                    isModified = true; // Mark as modified
                }
                else
                {
                    return;
                }
            } 
        }
        // Check if the user selected one cell in supplierTable for editing
        else if (supplierTable.getSelectedRowCount() == 1 && supplierTable.getSelectedColumnCount() == 1) 
        {
            int rowToEditIndexSup = supplierTable.getSelectedRow();
            int colToEditIndexSup = supplierTable.getSelectedColumn();

            String colName = supplierTable.getColumnName(colToEditIndexSup);
            
            if (colName.equalsIgnoreCase("Supplier Name") || colName.equalsIgnoreCase("Location") || colName.equalsIgnoreCase("Unit Price")) 
            {
                // Prevent editing specific columns in supplierTable
                JOptionPane.showMessageDialog(null, colName + " cannot be edited!");
                return;
            }           
            // Allow edit for Supplier ID
            else if (colName.equalsIgnoreCase("Supplier ID")) 
            {
                // Get the old supplier ID and new supplier ID
                String oldSupplierID = (String) supplierTable.getValueAt(rowToEditIndexSup, colToEditIndexSup);
                String newSupplierID = JOptionPane.showInputDialog(null, "Edit value for Supplier ID:");
                
                if(newSupplierID != null && !newSupplierID.isEmpty())
                {
                    newSupplierID = newSupplierID.trim();
                    //chk if this sup exist or not
                    boolean supExist = false;
                    for(SupplierData supplier: supplierData)
                    {
                        if(supplier.getSupplierID().equalsIgnoreCase(newSupplierID))
                        {
                            supExist = true;
                            break;
                        }
                    }
                    
                    if(!supExist)
                    {
                        JOptionPane.showMessageDialog(null, "This supplier does not exist!");
                        return;
                    }
                    
                    //after chk, if exist, chk if he got supply this item or not
                    boolean supplyItem = false;
                    
                    //chk if the prompt sup id got supply this item or not
                    ArrayList<InventoryData> inventoryList = supplierItemMap.get(newSupplierID);
                    if(inventoryList != null)
                    {
                        for(InventoryData inventory: inventoryList)
                        {
                            if(inventory.getItemID().equalsIgnoreCase(currentItemID))
                            {
                                supplyItem = true;
                                break;
                            }
                        }
                    }
                    
                    
                    if(!supplyItem)
                    {
                        JOptionPane.showMessageDialog(null, "This supplier does not supply this item!");
                        return;
                    }
                    
                    //avoid duplicate entry
                    for(int i = 0; i < supplierTable.getRowCount(); i++)
                    {
                        String supID = (String) supplierTable.getValueAt(i, 0);
                        if(newSupplierID.equalsIgnoreCase(supID))
                        {
                            JOptionPane.showMessageDialog(null, "This supplier already supplying this item!");
                            return;
                        }
                    }
                    
                    //now update the value inside the table
                    if(supExist && supplyItem)
                    {
                        ArrayList<SupplierData> supplierList = itemSupplierMap.get(currentItemID);
                        for(SupplierData supplier: supplierList)
                        {
                            if(supplier.getSupplierID().equalsIgnoreCase(newSupplierID))
                            {
                                String supName = supplier.getSupplierName();
                                String location = supplier.getLocation();
                                double unitPrice = supplier.getUnitPrice();
                                
                                supplierTable.setValueAt(newSupplierID, rowToEditIndexSup, colToEditIndexSup);
                                supplierTable.setValueAt(supName , rowToEditIndexSup, supplierTable.getColumnModel().getColumnIndex("Supplier Name"));
                                supplierTable.setValueAt(location, rowToEditIndexSup, supplierTable.getColumnModel().getColumnIndex("Location"));
                                supplierTable.setValueAt(unitPrice, rowToEditIndexSup, supplierTable.getColumnModel().getColumnIndex("Unit Price"));
                            }
                        }
                    }
                    
                    //now upload to hashmap(itemsupmap)
                    ArrayList<SupplierData> oldSupplierList = itemSupplierMap.get(oldSupplierID);
                    ArrayList<SupplierData> newSupplierList = itemSupplierMap.get(newSupplierID);
                    int existingQty = 0;
                    for(SupplierData supplier: oldSupplierList)
                    {
                        if(supplier.getSupplierID().equalsIgnoreCase(oldSupplierID))
                        {
                            existingQty = supplier.getQty();
                            supplier.setQty(0);
                        }
                    }
                    
                    for(SupplierData supplier: newSupplierList)
                    {
                        if(supplier.getSupplierID().equalsIgnoreCase(newSupplierID))
                        {
                            supplier.setQty(existingQty);
                        }
                    }
   
                    // Mark as modified
                    isModified = true;
                    return;
                }
                else
                {
                    return;
                }
            } 
            else if (colName.equalsIgnoreCase("Qty.")) 
            {
                String strNewQty = JOptionPane.showInputDialog(null, "Edit value for " + colName + ":");
                if (strNewQty != null && !strNewQty.isEmpty()) 
                {
                    strNewQty = strNewQty.trim();
                    String supID = (String) supplierTable.getValueAt(rowToEditIndexSup, supplierTable.getColumnModel().getColumnIndex("Supplier ID"));
                    ArrayList<SupplierData> supplierList = itemSupplierMap.get(currentItemID);

                    int oldQty = 0;
                    int newQty = 0;
                    try
                    {
                        newQty = Integer.parseInt(strNewQty);

                        if(newQty <= 0 )
                        {
                            JOptionPane.showMessageDialog(null, "Please enter a valid quantity!");
                            return;
                        }
                    }catch (NumberFormatException e)
                    {
                        JOptionPane.showMessageDialog(null, "Invalid input! Please enter a valid integer.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    for(SupplierData supplier: supplierList)
                    {
                        if(supplier.getSupplierID().equalsIgnoreCase(supID))
                        {
                            oldQty = supplier.getQty();
                            supplier.setQty(newQty);
                            supplierTable.setValueAt(newQty, rowToEditIndexSup, colToEditIndexSup);
                            break;
                        }
                    }

                    //Update the item total qty also
                    
                    int currentTotalQty = itemQtyMap.getOrDefault(currentItemID, 0);
                    int newTotalQty = currentTotalQty - oldQty + newQty;
                    System.out.println(currentTotalQty);//test
                    itemQtyMap.put(currentItemID, newTotalQty);

                    //update the item table also
                    //if chg qty the total will chg also and will affect stockLvl too
                    for(int row = 0; row < itemTable.getRowCount(); row++)
                    {
                        String itemID = (String) itemTable.getValueAt(row, itemTable.getColumnModel().getColumnIndex("Item ID"));

                        if(currentItemID.equals(itemID))
                        {
                            itemTable.setValueAt(newTotalQty, row, itemTable.getColumnModel().getColumnIndex("Total Qty."));

                            String stockLvl = null;
                            if(newTotalQty > 10)
                            {
                                stockLvl = "-";
                            }
                            else
                            {
                                stockLvl = "Low";
                            }

                            itemTable.setValueAt(stockLvl, row, itemTable.getColumnModel().getColumnIndex("Stock Level"));
                            break;
                        }
                    }

                    //debug
                    System.out.println(currentItemID);
                    System.out.println(supID);
                    System.out.println(oldQty+","+newQty);
                    System.out.println("Updated Qty"+itemQtyMap.get(currentItemID));

                    isModified = true;
                }
                else
                {
                    return;
                }
            }
        } 
        
        if(itemTable.getSelectedRowCount() == 0 && supplierTable.getSelectedRowCount() == 0 )
        {
            JOptionPane.showMessageDialog(null, "Please select A cell in the table to edit.");
        }
    }

    @Override
    public void Delete(JTable itemTable, JTable supplierTable)
    {
        DefaultTableModel itemTblModel = (DefaultTableModel) itemTable.getModel();
        DefaultTableModel supplierTblModel = (DefaultTableModel) supplierTable.getModel();
        
        if(itemTable.getSelectedRowCount() == 1)
        {
            supplierTable.clearSelection();
            int rowToDeleteIndexItem = itemTable.getSelectedRow();
            String itemID = (String) itemTblModel.getValueAt(rowToDeleteIndexItem, itemTable.getColumnModel().getColumnIndex("Item ID"));
            
            ArrayList<SupplierData> supplierList = itemSupplierMap.get(itemID);
            
            int response = JOptionPane.showConfirmDialog(null, "Do you want to delete this item?", "Delete Item", JOptionPane.YES_NO_OPTION);
            
            if(response == JOptionPane.YES_OPTION)
            {
                if(itemQtyMap.containsKey(itemID))
                {
                    itemTblModel.removeRow(rowToDeleteIndexItem);
                    supplierTblModel.setRowCount(0);
                    itemQtyMap.remove(itemID);
                    for(SupplierData supplier: supplierList)
                    {
                        supplier.setQty(0);
                    }
                    JOptionPane.showMessageDialog(null, "Item "  + itemID + " has been deleted successfully.");
                    isModified = true;
                    return;
                }
            }
            else
            {
                return;
            }  
        }

        if(supplierTable.getSelectedRowCount() == 1)
        {
            int rowToDeleteIndexSup = supplierTable.getSelectedRow();
            String supID = (String) supplierTblModel.getValueAt(rowToDeleteIndexSup, supplierTable.getColumnModel().getColumnIndex("Supplier ID"));
            
            int rowCount = supplierTable.getRowCount();
            if(rowCount == 1)
            {
                JOptionPane.showMessageDialog(null, "Item need at least one supplier");
                return;
            }
            
            int response = JOptionPane.showConfirmDialog(null, "Do you want to delete this supplier for item " + currentItemID + "?","Delete Supplier", JOptionPane.YES_NO_OPTION);
            
            if(response == JOptionPane.YES_OPTION)
            {
                ArrayList<SupplierData> supplierList = itemSupplierMap.get(currentItemID);
                for(SupplierData supplier: supplierList)
                {
                    if(supplier.getSupplierID().equals(supID))
                    {
                        int qtyToBeRemove = supplier.getQty();
                        supplier.setQty(0);
                        
                        
                        int currentTotalQty = itemQtyMap.getOrDefault(currentItemID, 0);
                        System.out.println(currentTotalQty);
                        int newTotalQty = currentTotalQty - qtyToBeRemove;
                        itemQtyMap.put(currentItemID, newTotalQty);
                        
                        for(int row = 0; row < itemTable.getRowCount(); row++)
                        {
                            String itemID = (String) itemTable.getValueAt(row, itemTable.getColumnModel().getColumnIndex("Item ID"));

                            if(currentItemID.equals(itemID))
                            {
                                itemTable.setValueAt(newTotalQty, row, itemTable.getColumnModel().getColumnIndex("Total Qty."));
                                break;
                            }
                        }
                        
                        supplierTblModel.removeRow(rowToDeleteIndexSup);
                        JOptionPane.showMessageDialog(null, "Supplier successfully removed from item "+currentItemID);
                        isModified = true;
                        return;
                    }
                }
            }
        } 
   
        if(itemTable.getRowCount() == 0 && supplierTable.getRowCount() == 0)
        {
            JOptionPane.showMessageDialog(null, "Table is empty"); 
        }
        else if(itemTable.getSelectedRowCount() == 0 && supplierTable.getSelectedRowCount() == 0)
        {
            JOptionPane.showMessageDialog(null, "Please select SINGLE ROW for delete");
            return;
        }
    }
    
    @Override
    public void AddDetails(JTable itemTable, JTable supplierTable)
    {
        DefaultTableModel itemTblModel = (DefaultTableModel) itemTable.getModel();

        if(itemTable.getSelectedRowCount() == 1)
        {
            int rowToAdd = itemTable.getSelectedRow();
            String itemID = (String) itemTblModel.getValueAt(rowToAdd, itemTable.getColumnModel().getColumnIndex("Item ID"));
            
            //prompt sup id
            String newSupplierID = null;
            do
            {
                newSupplierID = JOptionPane.showInputDialog("Enter supplier ID");
                if(newSupplierID == null)
                {
                    return;
                }
                
                newSupplierID = newSupplierID.toUpperCase().trim();
                
                if (newSupplierID.isEmpty()) 
                {
                    // If input is empty, show an error message
                    JOptionPane.showMessageDialog(null, "Supplier ID cannot be empty. Please try again.");
                }
            }while(newSupplierID.isEmpty());
            
            //validation for sup id
            ArrayList<SupplierData> supplierList = itemSupplierMap.get(itemID);
            for(SupplierData supplier: supplierList)
            {
                if(supplier.getSupplierID().equalsIgnoreCase(newSupplierID) && supplier.getQty() > 0)
                {
                    JOptionPane.showMessageDialog(null, "This supplier already exist for this item!");
                    return;
                }
            }
            
            //validation for supplier if he got supply this item or not
            // Check if supplier supplies this item
            ArrayList<InventoryData> inventoryList = supplierItemMap.get(newSupplierID);
            // Check if the supplier supplies the item
            boolean suppliesItem = false;

            if (inventoryList != null) {
                for (InventoryData inventory : inventoryList) {
                    if (inventory.getItemID().equalsIgnoreCase(itemID)) {
                        suppliesItem = true; // Found a match
                        break; // No need to check further
                    }
                }
            }

            if (!suppliesItem) {
                JOptionPane.showMessageDialog(null, "This supplier does not supply the selected item.", 
                                              "Invalid Supplier", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            
            //chk if supplier exists or not
            boolean supplierExists = false;
            for (SupplierData suppliers : supplierData) 
            {
                if (suppliers.getSupplierID().equalsIgnoreCase(newSupplierID)) {
                    supplierExists = true;
                    break;
                }
            }

            if (!supplierExists) 
            {
                JOptionPane.showMessageDialog(null, "This supplier does not exist");
                return;
            }            
           
            //prompt qty
            String strNewQty = null;
            int newQty = 0;
            do
            {
                strNewQty = JOptionPane.showInputDialog("Enter quantity");
                
                if(strNewQty == null)
                {
                    return;
                }
                
                strNewQty = strNewQty.trim();
                
                if(strNewQty.isEmpty())
                {
                    JOptionPane.showMessageDialog(null, "Quantity cannot be empty. Please try again.");
                }
            }while(strNewQty.isEmpty());

            try
            {
                newQty = Integer.parseInt(strNewQty);
                if(newQty < 0)
                {
                    JOptionPane.showMessageDialog(null, "Please enter a valid quantity");
                    return;
                }

                //Stock Level
                String stockLvl = null;
                int totalQty = itemQtyMap.getOrDefault(itemID, 0) + newQty;

                if(totalQty > 10)
                {
                    stockLvl = "-";
                }
                else
                {
                    stockLvl = "Low";
                }

                itemQtyMap.put(itemID, totalQty);
                
                //set at table 
                itemTable.setValueAt(totalQty, rowToAdd, itemTable.getColumnModel().getColumnIndex("Total Qty."));
                itemTable.setValueAt(stockLvl, rowToAdd, itemTable.getColumnModel().getColumnIndex("Stock Level"));
            }catch (NumberFormatException e)
            {
                JOptionPane.showMessageDialog(null, "Invalid input! Please enter a valid integer.", 
                                              "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            //upload to table and sync to hashmap
            for(SupplierData supplier: supplierList)
            {
                if(supplier.getSupplierID().equalsIgnoreCase(newSupplierID))
                {
                    supplier.setQty(newQty);
                    JOptionPane.showMessageDialog(null, "Supplier added successfully for item: " + itemID);
                    break;
                }
            }
            isModified = true;
            //show the new supplier
            ShowDetails(supplierTable, currentItemID);
            itemTable.clearSelection();
        }   
    }
    
    @Override
    public void SaveToArray(JTable itemTable) throws IOException
    {
        inventoryData.clear();
        supItemData.clear();
        TreeMap<String, InventoryData> uniqueInventoryMap = new TreeMap<>();

        for(Map.Entry<String, ArrayList<SupplierData>> entry: itemSupplierMap.entrySet())
        {
            String itemID = entry.getKey();
            ArrayList<SupplierData> supplierList = entry.getValue();
            int totalQty = itemQtyMap.getOrDefault(itemID, 0);
            
            //get info for supitem arraylist
            for(SupplierData supplier: supplierList)
            {
                String supID = supplier.getSupplierID();
                int qty = supplier.getQty();
                double unitPrice = supplier.getUnitPrice();
                
                SupItemData supItem = new SupItemData(supID, itemID, qty, unitPrice);
                supItemData.add(supItem);
                
                ArrayList<InventoryData> inventoryList = supplierItemMap.get(supID);
                for(InventoryData inventory: inventoryList)
                {
                    if(inventory.getItemID().equalsIgnoreCase(itemID))
                    {
                        String itemName = inventory.getItemName();
                        String stockLvl = null;
                        
                        if(totalQty == 0)
                        {
                            stockLvl = "-";
                        }
                        else if(totalQty < 10)
                        {
                            stockLvl = "Low";
                        }
                        else
                        {
                            stockLvl = "-";
                        }
                        
                        // Check if this item has already been added to the unique map
                        if (!uniqueInventoryMap.containsKey(itemID)) 
                        {
                            InventoryData inventoryInfo = new InventoryData(itemID, itemName, totalQty, stockLvl);
                            uniqueInventoryMap.put(itemID, inventoryInfo);
                        }
                    }
                }
            } 
        }
        inventoryData.addAll(uniqueInventoryMap.values());       
        isModified = false;
        JOptionPane.showMessageDialog(null, "Data saved successfully!");
    }      
}
