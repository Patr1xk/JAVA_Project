/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ImDash;

import Login.FileHandling;
import Login.InventoryData;
import Login.PurchaseData;
import Login.SupItemData;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Asus
 */
public class UpdateStock implements FileHandling{
    
    private ArrayList<InventoryData> inventoryData;
    private ArrayList<SupItemData> supItemData;
    private ArrayList<PurchaseData> purchaseData;

    public UpdateStock(ArrayList<InventoryData> inventoryData, ArrayList<SupItemData> supItemData, ArrayList<PurchaseData> purchaseData)
    {
        this.inventoryData = inventoryData;
        this.supItemData = supItemData;
        this.purchaseData = purchaseData;
 
    }
    
    public void ShowUpdateItem(JTable updateTbl, JLabel label)
    {
        label.hide();
        DefaultTableModel updateTblModel = (DefaultTableModel) updateTbl.getModel();
        updateTblModel.setRowCount(0);
        
        for(PurchaseData purchase: purchaseData)
        {
            if(purchase.getStatus().equalsIgnoreCase("Paid"))
            {
                String supID = purchase.getSupplierID();
                String itemID = purchase.getItemID();
                int qty = purchase.getQuantity();
                double unitPrice = purchase.getUnitPrice();

                updateTblModel.addRow(new Object[]{supID, itemID, qty, unitPrice});
            } 
        }
        if(updateTblModel.getRowCount() == 0)
        {
            label.show();
        }
    }
    
    public void Update(JTable updateTbl, JLabel label)
    {
        DefaultTableModel updateTblModel = (DefaultTableModel) updateTbl.getModel();
        
        if(updateTbl.getSelectedRowCount() == 1)
        {
            int rowToUpdateIndex = updateTbl.getSelectedRow();
            
            String supID = (String) updateTbl.getValueAt(rowToUpdateIndex, updateTbl.getColumnModel().getColumnIndex("Supplier ID"));
            String itemID = (String) updateTbl.getValueAt(rowToUpdateIndex, updateTbl.getColumnModel().getColumnIndex("Item ID"));
            int qty = (Integer) updateTbl.getValueAt(rowToUpdateIndex, updateTbl.getColumnModel().getColumnIndex("Qty."));
            
            //upload to inv arraylist
            for(InventoryData inventory: inventoryData)
            {
                if(inventory.getItemID().equalsIgnoreCase(itemID))
                {
                    int newTotalQty = inventory.getTotalQty() + qty;
                    inventory.setTotalQty(newTotalQty);
                    break;
                }
            }
            
            //upload to supitem also
            for(SupItemData supItem: supItemData)
            {
                if(supItem.getItemID().equalsIgnoreCase(itemID) && supItem.getSupplierID().equalsIgnoreCase(supID))
                {
                    int newQty = supItem.getQuantity() + qty;
                    supItem.setQuantity(newQty);
                    break;
                }
            }
            
            //update the purchase order status
            for(PurchaseData purchase: purchaseData)
            {
                if(purchase.getItemID().equalsIgnoreCase(itemID) && purchase.getSupplierID().equalsIgnoreCase(supID))
                {
                    purchase.setStatus("Updated");
                    updateTblModel.removeRow(rowToUpdateIndex);
                    break;
                }
            }
            JOptionPane.showMessageDialog(null, "Üpdated successfully");
            Save(inventoryData, inventoryFilePath);
            Save(supItemData, supItemFilePath);
            Save(purchaseData, purchaseFilePath);
        }
        else
        {
            JOptionPane.showMessageDialog(null, "No item to be update");
        }
        
        if(updateTblModel.getRowCount() == 0)
        {
            label.show();
        }
    }
}
