package AdminDash;

import FmDash.FmDashboard;
import ImDash.ImDashboard;
import Login.InventoryData;
import Login.LoginPage;
import Login.PurchaseData;
import Login.RequisitionData;
import Login.SalesData;
import Login.SupItemData;
import Login.SupplierData;
import Login.UserData;
import PmDash.PmDashboard;
import SmDash.SmDashboard;
import java.util.ArrayList;

public class AdminDashboard extends javax.swing.JFrame {

    private ArrayList<UserData> userData;
    private ArrayList<SalesData> salesData;
    private ArrayList<InventoryData> inventoryData;
    private ArrayList<SupplierData> supplierData;
    private ArrayList<PurchaseData> purchaseData;
    private ArrayList<RequisitionData> requisitionData;
    private ArrayList<SupItemData> supItemData;


    public AdminDashboard(ArrayList<UserData> userData, ArrayList<SalesData> salesData, ArrayList<InventoryData> inventoryData, ArrayList<PurchaseData> purchaseData, ArrayList<RequisitionData> requisitionData, ArrayList<SupItemData> supItemData, ArrayList<SupplierData> supplierData) {
        this.userData = userData;
        this.salesData = salesData;
        this.inventoryData = inventoryData;
        this.purchaseData = purchaseData;
        this.requisitionData = requisitionData;
        this.supItemData = supItemData;
        this.supplierData = supplierData;
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        btnLogOut = new javax.swing.JButton();
        btnRegister = new javax.swing.JButton();
        btnSM = new javax.swing.JButton();
        btnPM = new javax.swing.JButton();
        btnFM = new javax.swing.JButton();
        lblSM = new javax.swing.JLabel();
        lblPM = new javax.swing.JLabel();
        lblFM = new javax.swing.JLabel();
        btnIM = new javax.swing.JButton();
        lblIM = new javax.swing.JLabel();
        lblRegister = new javax.swing.JLabel();
        resetpassword = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(800, 500));
        setPreferredSize(new java.awt.Dimension(800, 500));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 80));

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Admin Dashboard");

        btnLogOut.setBackground(new java.awt.Color(51, 51, 51));
        btnLogOut.setIcon(new javax.swing.ImageIcon(getClass().getResource("/LoginImage/logout.png"))); // NOI18N
        btnLogOut.setBorder(null);
        btnLogOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogOutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(112, Short.MAX_VALUE)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 582, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnLogOut, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(24, 24, 24))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnLogOut, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 78));

        btnRegister.setBackground(new java.awt.Color(242, 242, 242));
        btnRegister.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AdminImage/register.jpg"))); // NOI18N
        btnRegister.setBorder(null);
        btnRegister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegisterActionPerformed(evt);
            }
        });
        getContentPane().add(btnRegister, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 210, -1, -1));

        btnSM.setBackground(new java.awt.Color(242, 242, 242));
        btnSM.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AdminImage/sm.jpg"))); // NOI18N
        btnSM.setBorder(null);
        btnSM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSMActionPerformed(evt);
            }
        });
        getContentPane().add(btnSM, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 90, -1, -1));

        btnPM.setBackground(new java.awt.Color(242, 242, 242));
        btnPM.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AdminImage/pm.jpg"))); // NOI18N
        btnPM.setBorder(null);
        btnPM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPMActionPerformed(evt);
            }
        });
        getContentPane().add(btnPM, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 90, -1, -1));

        btnFM.setBackground(new java.awt.Color(242, 242, 242));
        btnFM.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AdminImage/fm.jpg"))); // NOI18N
        btnFM.setBorder(null);
        btnFM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFMActionPerformed(evt);
            }
        });
        getContentPane().add(btnFM, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 280, -1, -1));

        lblSM.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblSM.setText("Sales Manager");
        getContentPane().add(lblSM, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 250, -1, -1));

        lblPM.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblPM.setText("Purchase Manager");
        getContentPane().add(lblPM, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 250, -1, -1));

        lblFM.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblFM.setText("Finance Manager");
        getContentPane().add(lblFM, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 440, -1, -1));

        btnIM.setBackground(new java.awt.Color(242, 242, 242));
        btnIM.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AdminImage/im.jpg"))); // NOI18N
        btnIM.setBorder(null);
        btnIM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIMActionPerformed(evt);
            }
        });
        getContentPane().add(btnIM, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 270, -1, -1));

        lblIM.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblIM.setText("Inventory Manager");
        getContentPane().add(lblIM, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 430, -1, 40));

        lblRegister.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblRegister.setText("Register");
        getContentPane().add(lblRegister, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 360, -1, -1));

        resetpassword.setBackground(new java.awt.Color(242, 242, 242));
        resetpassword.setFont(new java.awt.Font("Arial", 1, 13)); // NOI18N
        resetpassword.setText("Reset Password");
        resetpassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetpasswordActionPerformed(evt);
            }
        });
        getContentPane().add(resetpassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(662, 465, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegisterActionPerformed
        // TODO add your handling code here:
        RegisterPage register = new RegisterPage(userData, salesData, inventoryData, purchaseData, requisitionData, supItemData, supplierData);
        register.setVisible(true); 
        this.dispose();
    }//GEN-LAST:event_btnRegisterActionPerformed

    private void btnSMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSMActionPerformed
        // TODO add your handling code here:
        SmDashboard sm = new SmDashboard(inventoryData, supItemData, requisitionData, purchaseData, salesData, userData);
        sm.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnSMActionPerformed

    private void btnPMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPMActionPerformed
        // TODO add your handling code here:
        PmDashboard pm = new PmDashboard(userData, salesData, inventoryData, supplierData, purchaseData, requisitionData, supItemData);
        pm.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnPMActionPerformed

    private void btnFMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFMActionPerformed
        // TODO add your handling code here:
        FmDashboard fm = new FmDashboard(purchaseData, inventoryData, userData);
        fm.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnFMActionPerformed

    private void btnIMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIMActionPerformed
        // TODO add your handling code here:
        ImDashboard im = new ImDashboard(inventoryData, supplierData, supItemData, purchaseData, userData);
        im.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnIMActionPerformed

    private void resetpasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetpasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_resetpasswordActionPerformed

    private void btnLogOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogOutActionPerformed
        // TODO add your handling code here:
        LoginPage loginPage = new LoginPage();
        loginPage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnLogOutActionPerformed

   
    public static void main(String args[]) {
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new AdminDashboard().setVisible(true);
//            }
//        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnFM;
    private javax.swing.JButton btnIM;
    private javax.swing.JButton btnLogOut;
    private javax.swing.JButton btnPM;
    private javax.swing.JButton btnRegister;
    private javax.swing.JButton btnSM;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblFM;
    private javax.swing.JLabel lblIM;
    private javax.swing.JLabel lblPM;
    private javax.swing.JLabel lblRegister;
    private javax.swing.JLabel lblSM;
    private javax.swing.JButton resetpassword;
    // End of variables declaration//GEN-END:variables
}
