/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AdminDash;

import Login.UserData;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Yen Hau
 */
public class Register {
    
    static void register(ArrayList<UserData> userData, String username, String user_id, String gender){
        // user id
        int numeric = 0;
        
        System.out.println(user_id + userData.size());
        
        for (int i = 0; i < userData.size(); i++) {
            if (userData.get(i).getUserID().substring(0,2).equals(user_id)) {
                numeric = Integer.parseInt(userData.get(i).getUserID().substring(2));
            }
        }
        
        numeric += 1;
  
        StringBuilder user_id_sb = new StringBuilder(user_id);
        user_id_sb.append("000");
        
        String fnumeric = Integer.toString(numeric);
                
        if (numeric < 10) {
            user_id_sb.setCharAt(4, Character.forDigit(numeric, 10));
        }
        else if (numeric < 100) {
            user_id_sb.setCharAt(4, fnumeric.charAt(1));
            user_id_sb.setCharAt(3, fnumeric.charAt(0));
        }
        else if (numeric < 1000) {
            user_id_sb.setCharAt(4, fnumeric.charAt(2));
            user_id_sb.setCharAt(3, fnumeric.charAt(1));
            user_id_sb.setCharAt(2, fnumeric.charAt(0));
        }
        
        // Random password generator
        char[] character = {'a','b','c','d','e','f','g','h','i','j','k','l','m',
                                'n','o','p','q','r','s','t','u','v','w','x','y','z',
                                '1','2','3','4','5','6','7','8','9','0'};
            
        String base = "xxxxxxxx";
        StringBuilder pass_sb =  new StringBuilder(base);

        for (int i = 0; i < 8; i++) {                   
            int rand = (int)(Math.random() * 36);
            pass_sb.setCharAt(i, character[rand]);
        }
        
        // file appending
        try {
            FileWriter writer = new FileWriter("src\\userdata.txt",true);

            writer.append(user_id_sb + "," + username + "," + pass_sb + "," + gender + "\n");
            writer.close();

            JOptionPane.showMessageDialog(null,"Account registered successfully");
            System.out.println("userdatatxt has been updated");   
        }
        catch (IOException e){
            System.out.println(e);
        }
        
    }
    
}
