/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Login;

/**
 *
 * @author Asus
 */
public class SupplierData {
    private String supplierID;
    private String supplierName;
    private String location;
    
    //for overloading
    private int qty;
    private double unitPrice;

    public SupplierData(String supplierID, String supplierName, String location) {
        this.supplierID = supplierID;
        this.supplierName = supplierName;
        this.location = location;
    }

    //overloading
    public SupplierData(String supplierID, String supplierName, String location, int qty, double unitPrice) {
        this.supplierID = supplierID;
        this.supplierName = supplierName;
        this.location = location;
        this.qty = qty;
        this.unitPrice = unitPrice;
    }

    public String getSupplierID() {
        return supplierID;
    }

    public void setSupplierID(String supplierID) {
        this.supplierID = supplierID;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    @Override
    public String toString() {
        return supplierID + "," + supplierName + ","+location;
    }

}
