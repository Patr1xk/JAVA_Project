/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Login;

/**
 *
 * @author Asus
 */
public class SupItemData {
    private String supplierID;
    private String itemID;
    private int quantity;
    private double unitPrice;

    public SupItemData(String supplierID, String itemID, int quantity, double unitPrice) {
        this.supplierID = supplierID;
        this.itemID = itemID;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
    }

    public String getSupplierID() {
        return supplierID;
    }

    public void setSupplierID(String supplierID) {
        this.supplierID = supplierID;
    }

    public String getItemID() {
        return itemID;
    }

    public void setItemID(String itemID) {
        this.itemID = itemID;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    @Override
    public String toString() {
        return supplierID + "," + itemID + "," + quantity + "," + unitPrice;
    }
}
