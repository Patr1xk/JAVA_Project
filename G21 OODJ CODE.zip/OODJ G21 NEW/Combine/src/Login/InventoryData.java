/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Login;

/**
 *
 * @author Asus
 */
public class InventoryData {
    private String itemID;
    private String itemName;
    private int totalQty;
    private String stockLvl;
    //for overloading
    private double unitPrice;

    public InventoryData(String itemID, String itemName, int totalQty, String stockLvl) {
        this.itemID = itemID;
        this.itemName = itemName;
        this.totalQty = totalQty;
        this.stockLvl = stockLvl;
    }

    //overloading
    public InventoryData(String itemID, String itemName, double unitPrice) {
        this.itemID = itemID;
        this.itemName = itemName;
        this.unitPrice = unitPrice;
    }

    public String getItemID() {
        return itemID;
    }

    public void setItemID(String itemID) {
        this.itemID = itemID;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getTotalQty() {
        return totalQty;
    }

    public void setTotalQty(int totalQty) {
        this.totalQty = totalQty;
    }

    public String getStockLvl() {
        return stockLvl;
    }

    public void setStockLvl(String stockLvl) {
        this.stockLvl = stockLvl;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    @Override
    public String toString() {
        return itemID + ","+ itemName + ","+ totalQty + ","+ stockLvl;
    }
    
}
