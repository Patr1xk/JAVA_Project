/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Login;

/**
 *
 * @author Asus
 */
public class PurchaseData {
    
    private String poID;
    private String date;
    private String requisitionID;
    private String pmID;
    private String supplierID;
    private String itemID;
    private double unitPrice;
    private int quantity;
    private double totalPrice;
    private String status;

    public PurchaseData(String poID, String date, String requisitionID, String pmID, String supplierID, String itemID, double unitPrice, int quantity, double totalPrice, String status) {
        this.poID = poID;
        this.date = date;
        this.requisitionID = requisitionID;
        this.pmID = pmID;
        this.supplierID = supplierID;
        this.itemID = itemID;
        this.unitPrice = unitPrice;
        this.quantity = quantity;
        this.totalPrice = totalPrice;
        this.status = status;
    }

    public String getPoID() {
        return poID;
    }

    public void setPoID(String poID) {
        this.poID = poID;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getRequisitionID() {
        return requisitionID;
    }

    public void setRequisitionID(String requisitionID) {
        this.requisitionID = requisitionID;
    }

    public String getPmID() {
        return pmID;
    }

    public void setPmID(String pmID) {
        this.pmID = pmID;
    }

    public String getSupplierID() {
        return supplierID;
    }

    public void setSupplierID(String supplierID) {
        this.supplierID = supplierID;
    }

    public String getItemID() {
        return itemID;
    }

    public void setItemID(String itemID) {
        this.itemID = itemID;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return  poID + ","+ date + ","+ requisitionID + ","+ pmID + ","+ supplierID + ","+itemID + ","+unitPrice + ","+quantity + ","+totalPrice + ","+ status;
    }
    
}
