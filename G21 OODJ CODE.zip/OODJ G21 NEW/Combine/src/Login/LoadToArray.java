package Login;

import java.util.ArrayList;

public class LoadToArray implements FileHandling{
    
    //ArrayList
    protected ArrayList<UserData> userData = new ArrayList<>();
    protected ArrayList<SalesData> salesData = new ArrayList<>();
    protected ArrayList<InventoryData> inventoryData = new ArrayList<>();
    protected ArrayList<SupplierData> supplierData = new ArrayList<>();
    protected ArrayList<PurchaseData> purchaseData = new ArrayList<>();
    protected ArrayList<RequisitionData> requisitionData = new ArrayList<>();
    protected ArrayList<SupItemData> supItemData = new ArrayList<>();
    
    
    public LoadToArray()
    {
        loadProgram();
    }   

    public void loadProgram()
    {      
        //create all file
        createAllFile();
        
        //load to Array List
        loadToArrayList(userFilePath, userData, UserData.class);
        loadToArrayList(salesFilePath, salesData, SalesData.class);
        loadToArrayList(inventoryFilePath, inventoryData, InventoryData.class);
        loadToArrayList(supplierFilePath, supplierData, SupplierData.class);
        loadToArrayList(purchaseFilePath, purchaseData, PurchaseData.class);
        loadToArrayList(requisitionFilePath, requisitionData, RequisitionData.class);
        loadToArrayList(supItemFilePath, supItemData, SupItemData.class);

    }
    
    public ArrayList<UserData> getUserData() {
        return userData;
    }

    public ArrayList<SalesData> getSalesData() {
        return salesData;
    }

    public ArrayList<InventoryData> getInventoryData() {
        return inventoryData;
    }

    public ArrayList<SupplierData> getSupplierData() {
        return supplierData;
    }

    public ArrayList<PurchaseData> getPurchaseData() {
        return purchaseData;
    }

    public ArrayList<RequisitionData> getRequisitionData() {
        return requisitionData;
    }

    public ArrayList<SupItemData> getSupItemData() {
        return supItemData;
    }
    
}
