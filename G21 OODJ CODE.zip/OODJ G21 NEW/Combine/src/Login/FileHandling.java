package Login;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.lang.reflect.Constructor;

public interface FileHandling {

    public final String userFilePath = "src\\userdata.txt";
    public final String salesFilePath = "src\\sales.txt";
    public final String inventoryFilePath = "src\\inventory.txt";
    public final String supplierFilePath = "src\\supplier.txt";
    public final String purchaseFilePath = "src\\purchase.txt";
    public final String requisitionFilePath = "src\\requisition.txt";
    public final String supItemFilePath = "src\\supitem.txt";

    //chk if file exists or not
    public default boolean checkFileExists(String fileName) 
    {
        File checkFile = new File(fileName);
        if (!checkFile.exists()) {
            return false;
        } else {
            System.out.println("File existed!");
            return true;
        }
    }

    public default void createAllFile() 
    {
        try 
        {
            //user
            if (checkFileExists(userFilePath) == false) {
                FileWriter userFile = new FileWriter(userFilePath);
                userFile.write("AM001,Admin,Admin@1234,male\nSM001,Jane,jjj,female\nPM001,Meng,mmm,female\nIM001,Pat,ppp,male\nFM001,Yen,yyy,male\n");
                userFile.close();
                System.out.println("Creating user data file...");
            }

            //sales
            if (checkFileExists(salesFilePath) == false) {
                FileWriter salesFile = new FileWriter(salesFilePath);
                salesFile.write("23/09/2024,SA001,SM001,I004,Air Conditioner,5,1200,6000\n24/09/2024,SA002,SM001,I005,Vacuum Cleaner,8,150,1200\n25/09/2024,SA003,SM001,I006,Dishwasher,6,900,5400\n26/09/2024,SA001,SM001,I007,Electric Kettle,30,50,1500\n 27/09/2024,SA005,SM001,I008,Food Processor,12,200,2400\n28/09/2024,SA006,SM001,I009,Induction Cooktop,7,350,2450\n29/09/2024,SA007,SM001,I010,Toaster,25,40,1000\n30/09/2024,SA008,SM001,I011,Blender,18,60,1080\n01/10/2024,SA009,SM001,I012,Coffee Maker,10,100,1000\n02/10/2024,SA010,SM001,I013,Steam Iron,15,45,675\n");
                salesFile.close();
                System.out.println("Creating sales data file...");
            }

            //inventory
            if (checkFileExists(inventoryFilePath) == false) {
                FileWriter inventoryFile = new FileWriter(inventoryFilePath);
                inventoryFile.write("I001,Refrigerator,85,-\nI002,Washing Machine,8,Low\nI003,Microwave Oven,0,-\nI004,Air Conditioner,12,-\nI005,Vacuum Cleaner,5,Low\nI006,Dishwasher,30,-\nI007,Electric Kettle,3,Low\nI008,Food Processor,15,-\nI009,Induction Cooktop,9,Low\nI010,Toaster,20,-\nI011,Blender,7,Low\nI012,Coffee Maker,25,-\nI013,Steam Iron,18,-\nI014,Air Purifier,10,Low\nI015,Smart Speaker,4,Low\nI016,Wi-Fi Router,22,-\nI017,LED TV,2,Low\nI018,Gaming Console,6,Low\nI019,Home Theater,14,-\nI020,Security Camera,11,-\n");
                inventoryFile.close();
                System.out.println("Creating inventory data file...");
            }

            //supplier
            if (checkFileExists(supplierFilePath) == false) {
                FileWriter supplierFile = new FileWriter(supplierFilePath);
                supplierFile.write("S001,Aegis,Johor Bahru\nS002,Blah,Kuala Lumpur\nS003,Omni,Penang\nS004,Nexus,Kuala Lumpur\nS005,Vertex,Perak\nS006,Zenith,Johor Bahru\nS007,Prime,Kuala Lumpur\nS008,Evolve,Selangor\nS009,Pinnacle,Penang\nS010,Astro,Kuala Lumpur\n");
                supplierFile.close();
                System.out.println("Creating supplier data file...");
            }

            //purchase
            if (checkFileExists(purchaseFilePath) == false) {
                FileWriter purchaseFile = new FileWriter(purchaseFilePath);
                purchaseFile.write("P001,03/09/2024,R001,PM001,S001,I002,20.0,50,1000,Pending\nP002,04/09/2024,R002,PM001,S002,I005,25.0,5,125,Pending\nP003,05/09/2024,R003,PM001,S003,I007,30.0,3,90,Pending\nP004,06/09/2024,R004,PM001,S004,I009,35.0,9,315,Pending\nP005,07/09/2024,R005,PM001,S005,I011,25.0,7,175,Pending\nP006,08/09/2024,R006,PM001,S006,I014,40.0,10,400,Pending\n");
                purchaseFile.close();
                System.out.println("Creating purchase data file...");
            }
            
            //requisition
            if (checkFileExists(requisitionFilePath) == false) {
                FileWriter requisitionFile = new FileWriter(requisitionFilePath);
                requisitionFile.write("R001,25/08/2024,SM001,I002,Washing Machine,8\nR002,26/08/2024,SM001,I005,Vacuum Cleaner,5\nR003,27/08/2024,SM001,I007,Electric Kettle,3\nR004,28/08/2024,SM001,I009,Induction Cooktop,9\nR005,29/08/2024,SM001,I011,Blender,7\nR006,30/08/2024,SM001,I014,Air Purifier,10\n");
                requisitionFile.close();
                System.out.println("Creating requisition data file...");
            }
            
            //supitem
            if (checkFileExists(supItemFilePath) == false) {
                FileWriter supItemFile = new FileWriter(supItemFilePath);
                supItemFile.write("S001,I001,50,15.5\nS001,I002,8,20.0\nS001,I003,10,45.0\nS002,I001,35,15.0\nS002,I003,0,80\nS002,I002,0,50\nS002,I004,12,120.0\nS003,I005,25,75.0\nS003,I007,18,200.0\nS004,I006,18,200.0\nS004,I008,9,45.0\nS005,I009,22,30.0\nS005,I010,5,55.0\nS006,I011,17,25.0\nS006,I012,30,99.0\nS007,I013,8,40.0\nS007,I014,6,150.0\nS008,I015,30,22.5\nS008,I016,12,65.0\nS009,I017,18,85.0\nS009,I018,7,120.0\nS010,I019,20,45.0\nS010,I020,10,80.0\n");
                supItemFile.close();
                System.out.println("Creating supitem data file...");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    //load to array
    public default <T> void loadToArrayList(String filePath, ArrayList<T> list, Class<T> clazz) 
    {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;

            // Loop through each line in the file
            while ((line = br.readLine()) != null) {
                // Split the line by commas (assuming CSV format)
                String[] parts = line.split(",");

                // Get the constructor of the class
                Constructor<T> constructor = (Constructor<T>) clazz.getConstructors()[0];
                Class<?>[] paramTypes = constructor.getParameterTypes();
                
                if((paramTypes[paramTypes.length-1] == double.class) && (paramTypes.length == 3 || paramTypes.length == 5))
                {
                    constructor = (Constructor<T>) clazz.getConstructors()[1];
                    paramTypes = constructor.getParameterTypes();
                }
                // Prepare parameters for the constructor
                Object[] params = new Object[paramTypes.length];
                
                

                // Map the parts to constructor parameters
                for (int i = 0; i < parts.length; i++) {
                    String value = parts[i].trim();
                    if (paramTypes[i] == int.class) {
                        params[i] = Integer.parseInt(value);
                    } else if (paramTypes[i] == double.class) {
                        params[i] = Double.parseDouble(value);
                    } else {
                        params[i] = value;  // For strings
                    }
                }

                // Create the object using the constructor and add it to the list
                T obj = constructor.newInstance(params);
                list.add(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //SAVE FOR EVERYONE
    public default void Save(ArrayList<?> list, String fileName) 
    {
        if (list == null || list.isEmpty()) 
        {
            System.out.println("The list is empty. Nothing to save.");
            return;
        }

        System.out.println("Saving to file: " + fileName);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) 
        {
            for (Object item : list) 
            {
                writer.write(item.toString());
                writer.newLine();
            }

            System.out.println("Data saved successfully to " + fileName);
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
