/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Login;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author Yen Hau
 */
public class ResetPassword {    
    
    public int checkUsername(ArrayList<UserData> userData,String username) {
        
        if (username.isEmpty() || username.isBlank()) {
            return -1;
        }
        
        for (int i = 0; i < userData.size(); i++) {
            if (userData.get(i).getName().equals(username)){
                return i;
            }
        }        
        return -2;
    }     
        
    public boolean resetPassword(ArrayList<UserData> userData, String pass, String pass2, int index) {
        
        if (pass.equals(pass2)) {           
            try {
                FileWriter writer = new FileWriter("src\\userdata.txt");
                
                userData.get(index).setPass(pass);
                
                for (int i = 0; i < userData.size(); i++) {                   
                    writer.write(userData.get(i).getUserID() + "," +
                                 userData.get(i).getName() + "," +
                                 userData.get(i).getPass() + "," +
                                 userData.get(i).getGender() + "\n");
                }                
                writer.close();
                
                System.out.println("userdata.txt has been modified");
            }
            catch (IOException e){
                System.out.println(e);
                return false;
            }       
            return true;
        }
        else {
            return false;
        }
    }
}
