package Login;

import java.util.ArrayList;
import ImDash.ImDashboard;
import SmDash.SmDashboard;
import AdminDash.AdminDashboard;
import FmDash.FmDashboard;
import PmDash.PmDashboard;
import javax.swing.JOptionPane;


public class LoginValidation {
    
    private LoadToArray load;
    private ArrayList<UserData> userData;
    private ArrayList<SalesData> salesData;
    private ArrayList<InventoryData> inventoryData;
    private ArrayList<SupplierData> supplierData;
    private ArrayList<PurchaseData> purchaseData;
    private ArrayList<RequisitionData> requisitionData;
    private ArrayList<SupItemData> supItemData;

    public LoginValidation() {
        load = new LoadToArray();
        this.userData = load.getUserData();
        this.salesData = load.getSalesData();
        this.inventoryData = load.getInventoryData();
        this.supplierData = load.getSupplierData();
        this.purchaseData = load.getPurchaseData();
        this.requisitionData = load.getRequisitionData();
        this.supItemData = load.getSupItemData();
   }
    
    //chk match or not
    //also can use to reset password validation(eg. validate username and pass and if success, retype new pass)
    public boolean loginMatch(String username, String password)
    {
        for(int i = 0; i < userData.size(); i++)
        {
            UserData users = userData.get(i);

            if(users.getName().equals(username) && users.getPass().equals(password))
            {
                return true;
            }
        }
        return false;
    }  
    
    public void redirectPage(String username, String password) 
    {
        for (int i = 0; i < userData.size(); i++) 
        {
            UserData users = userData.get(i);

            if (users.getName().equals(username) && users.getPass().equals(password)) 
            {
                if (users.getUserID().startsWith("AM")) //admin
                {
                    // Redirect to Admin Page
                    AdminDashboard admin = new AdminDashboard(userData, salesData, inventoryData, purchaseData, requisitionData, supItemData, supplierData);
                    admin.setVisible(true);
                } 
                else if (users.getUserID().startsWith("SM")) //sales manager
                {
                    // Redirect to Sales Manager Page
                    SmDashboard sm = new SmDashboard(inventoryData, supItemData, requisitionData, purchaseData, salesData, userData);
                    sm.setVisible(true);
                } 
                else if (users.getUserID().startsWith("PM")) //purchase manager
                {
                    // Redirect to Purchase Manager Page
                    PmDashboard pm = new PmDashboard(userData, salesData, inventoryData, supplierData, purchaseData, requisitionData, supItemData);
                    pm.setVisible(true);
                } 
                else if (users.getUserID().startsWith("IM")) //inventory manager
                {
                    // Redirect to Inventory Manager Page
                    ImDashboard im = new ImDashboard(inventoryData, supplierData, supItemData, purchaseData, userData);
                    im.setVisible(true);
                } 
                else if (users.getUserID().startsWith("FM")) //finance manager
                {
                    // Redirect to Inventory Manager Page
                    FmDashboard fm = new FmDashboard(purchaseData, inventoryData, userData);
                    fm.setVisible(true);
                } 
                else 
                {
                    JOptionPane.showMessageDialog(null, "Can't match the roles!");
                }
            }
        }
    }
} 

