/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Login;

/**
 *
 * @author Asus
 */
public class RequisitionData {
    private String requisitionID;
    private String requestDate;
    private String salesManagerID;
    private String itemID;
    private String itemName;
    private int currentQty;

    public RequisitionData(String requisitionID, String requestDate, String salesManagerID, String itemID, String itemName, int currentQty) {
        this.requisitionID = requisitionID;
        this.requestDate = requestDate;
        this.salesManagerID = salesManagerID;
        this.itemID = itemID;
        this.itemName = itemName;
        this.currentQty = currentQty;
    }

    public String getRequisitionID() {
        return requisitionID;
    }

    public void setRequisitionID(String requisitionID) {
        this.requisitionID = requisitionID;
    }

    public String getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(String requestDate) {
        this.requestDate = requestDate;
    }

    public String getSalesManagerID() {
        return salesManagerID;
    }

    public void setSalesManagerID(String salesManagerID) {
        this.salesManagerID = salesManagerID;
    }

    public String getItemID() {
        return itemID;
    }

    public void setItemID(String itemID) {
        this.itemID = itemID;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getCurrentQty() {
        return currentQty;
    }

    public void setCurrentQty(int currentQty) {
        this.currentQty = currentQty;
    }

    @Override
    public String toString() {
        return requisitionID + ","+ requestDate + ","+ salesManagerID + ","+ itemID + ","+ itemName + ","+ currentQty;
    }
    
}
